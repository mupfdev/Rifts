/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This file was modified by Symbian Ltd. on 21 March 2001.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.xml;
import org.xml.sax.ContentHandler;
import org.xml.sax.ErrorHandler;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import java.util.Stack;
import java.util.List;
import java.util.EmptyStackException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

/**
 * This class handles SAX2 events during the construction process.
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     Constructor
 */
public class ConstructorHandler implements ContentHandler {

  /**
   * The signature of the XML constructor.
   */
  private static final Class[] CONSTRUCTOR_SIGNATURE
    = new Class[] {com.dautelle.xml.Attributes.class,
                   com.dautelle.xml.Elements.class};

  /**
   * The current stack.
   */
  private Stack stack;

  /**
   * The current character data.
   */
  private CharData charData;

  /**
   * The object corresponding to the root element.
   */
  private Object root;

  /**
   * Default constructor.
   */
  public ConstructorHandler() {
    super();
  }

  protected TagMap tagMap = null;
  public ConstructorHandler(TagMap tagMap) {
    super();
	this.tagMap = tagMap;
  }

  /**
   * Returns the object corresponding to the root element of the document
   * being parsed.
   *
   * @return the object created or <code>null</code> if none.
   */
  public Object getRoot() {
    return root;
  }

  /**
   * Receives notification of the beginning of the document.
   *
   * @throws <code>SAXException</code> any SAX exception, possibly wrapping
   *         another exception.
   */
  public void startDocument() throws SAXException {
    root = null;
    stack = new Stack();
    charData = new CharData();
  }

  /**
   * Receives notification of the end of the document.
   *
   * @throws <code>SAXException</code> any SAX exception, possibly wrapping
   *         another exception.
   */
  public void endDocument() throws SAXException {
    if (!stack.isEmpty()) throw new SAXException("Unexpected end of document");
    if (root == null) throw new SAXException("Empty document error");
  }

  /**
   * Receives notification of the start of an element.
   *
   * @param  uri the namespace.
   * @param  localName the local name.
   * @param  qName the raw XML 1.0 name (ignored)
   * @param  attributes the attributes.
   * @throws <code>SAXException</code> any SAX exception, possibly wrapping
   *         another exception.
   */
  public void startElement (String uri, String localName,
                            String qName, Attributes attributes)
      throws SAXException {
    if (root != null)
       throw new SAXException("More than one root element");
    flushCharData();
	//System.out.println(uri+" "+localName);
    stack.push(className(uri, localName));
    com.dautelle.xml.Attributes a = new com.dautelle.xml.Attributes();
    for (int i=0; i < attributes.getLength(); i++) {
	//String key = attributes.getLocalName(i);
	// Changes this to return the qualified name. --Symbian
	  String key = attributes.getQName(i);
      String value = attributes.getValue(i);
	  //System.out.println(key+" "+value+" "+attributes.getQName(i));
      a.add(key, value);
    }
    stack.push(a);
    com.dautelle.xml.Elements c = new com.dautelle.xml.Elements();
    stack.push(c);
  }
  private void flushCharData() {
    if (charData.isEmpty()) {
      charData.clear();
    } else {
      ((List) stack.peek()).add(charData);
      charData = new CharData();
    }
  }

  /**
   * Receives notification of the end of an element.
   *
   * @param  uri the namespace.
   * @param  localName the local name.
   * @param  qName the raw XML 1.0 name (ignored)
   * @param  attributes the attributes.
   * @throws <code>SAXException</code> any SAX exception, possibly wrapping
   *         another exception.
   */
  public void endElement (String uri, String localName, String qName)
      throws SAXException {
    flushCharData();
    String className = "unknown";
    try {
      // Retrieves representation from the stack.
      com.dautelle.xml.Elements content = 
		(com.dautelle.xml.Elements) stack.pop();
      com.dautelle.xml.Attributes attributes = 
		(com.dautelle.xml.Attributes) stack.pop();
      className = (String) stack.pop();

      // Check if start/end element are matching.
      if (!className.equals(className(uri, localName)))
          throw new SAXException(
          "Found end tag for element " + className(uri, localName) +
          " when end tag for element " + className +
          " was expected.");

	  // Changed 21 Mar 2001.
	  // (Added potential tag translation.)
	  Class objectClass = null;
	  // Determine if 'className' is actually just the XML label,
	  // and should be expanded to something else.
	  if(tagMap != null)
		  {
		  objectClass = tagMap.tagToClass(className);
		  }
	  if(objectClass == null)
		  objectClass = Class.forName(className);
	  else
		  className = objectClass.getName();

      // Call the XML constructor.
      Constructor xmlConstructor
        = objectClass.getConstructor(CONSTRUCTOR_SIGNATURE);
      Object[] arguments = new Object[] {attributes, content};
      Object current = xmlConstructor.newInstance(arguments);

      if (stack.isEmpty()) {
        // Root object
        root = current;
      } else {
        // Add it to the content of the enclosing element.
        ((List) stack.peek()).add(current);
      }

    } catch (EmptyStackException e1) {
      throw new SAXException("Found unexpected end tag " + qName);
    } catch (InstantiationException e2) {
      throw new SAXException("Cannot instanciate abstract class " + className);
    } catch (IllegalAccessException e3) {
      throw new SAXException("Constructor " + className + "inaccessible");
    } catch (ClassNotFoundException e4) {
      throw new SAXException("Class " + className + " not found");
    } catch (NoSuchMethodException e5) {
      throw new SAXException("XML constructor not found for class " 
							 + className);
    } catch (InvocationTargetException e6) {
      throw new SAXException("Constructor "+ className +
							 " throws an exception: "+
	  // Changed 21 Mar 2001.
	  // Added message here, so that constructors can explain the problem.
							 e6.getTargetException().getMessage());
    }
  }

  /**
   * Returns the name of the class from its Java URI and its local name.
   *
   * @param  uri the package name
   * @param  localName the relative name of the class
   * @return the full class name
   * @throws <code>ConstructorException</code> invalid URI (must use a java
   *         scheme).
   */
  private static String className(String uri, String localName)
      throws SAXException{
    if (uri.length() == 0) return localName;
    if (!uri.startsWith("java:"))
       throw new SAXException("Invalid URI (must use a java scheme)");
    String prefix = uri.substring(5);
    if (prefix.length() == 0) return localName;
    return prefix + "." + localName;
  }

  /**
   * Receive notification of character data.
   *
   * @param ch the characters from the XML document.
   * @param start the start position in the array.
   * @param length the number of characters to read from the array.
   * @see   #ignorableWhitespace
   */
  public void characters (char ch[], int start, int length) throws SAXException {
    charData.append(ch, start, length);
  }

  // Implements ignored methods.

  public void skippedEntity(String name) throws SAXException {
    // Do nothing.
  }

  public void processingInstruction(String target, String data)
      throws SAXException {
    // Do nothing.
  }

  public void ignorableWhitespace(char ch[], int start, int length)
      throws SAXException {
    // Do nothing.
  }


  public void endPrefixMapping(String prefix) throws SAXException {
    // Do nothing.
  }

  public void startPrefixMapping(String prefix, String uri)
      throws SAXException {
    // Do nothing.
  }

  public void setDocumentLocator(Locator locator) {
    // Do nothing.
  }

}
