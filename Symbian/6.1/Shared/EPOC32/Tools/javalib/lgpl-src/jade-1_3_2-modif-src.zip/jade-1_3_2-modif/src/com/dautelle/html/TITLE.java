/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.html;
import com.dautelle.xml.*;

/**
 * <P> This class represents the TITLE element of a HEAD section.</P>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     HEAD
 */
public class TITLE implements Representable {

  /**
   * The title string.
   */
  public String value;

  /**
   * Constructs a TITLE element with the specified value.
   *
   * @param   charData the chararcter entities.
   */
  public TITLE(String value) {
    this.value = value;
  }

  /**
   * XML Constructor.
   *
   * @param  attributes none.
   * @param  content the character entities.
   * @see    com.dautelle.xml.Constructor
   */
  public TITLE(Attributes attributes, Elements content) {
    value = ((CharData) content.get(0)).toString();
  }

  // Implements Representable
  //

  public Attributes getAttributes() {
    return null;
  }

  public Representable[] getContent() {
    Representable[] content = new Representable[1];
    content[0] = new CharData(value);
    return content;
  }
}