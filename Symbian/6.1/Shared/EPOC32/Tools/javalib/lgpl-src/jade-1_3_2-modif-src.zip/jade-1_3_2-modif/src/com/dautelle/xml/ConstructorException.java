/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This file was modified by Symbian Ltd. on 21 March 2001.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.xml;

/**
 * Signals that a problem of some sort has occurred when creating
 * an object from its XML representation.
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     Constructor
 */
public class ConstructorException extends RuntimeException {

    /**
     * Constructs a <code>ConstructorException</code> with  no detail message.
     */
    public ConstructorException() {
        super();
    }

    /**
     * Constructs a <code>ConstructorException</code> with the specified detail
     * message.
     *
     * @param   message the detail message.
     */
    public ConstructorException(String message) {
        super(message);
    }

// Added by Symbian.
private Exception iOriginal = null;
/** Returns null if no original exception was supplied to
	the constructor.
*/
public Exception getOriginal()
	{
	return iOriginal;
	}


    /**
     * Constructs a <code>ConstructorException</code> with the specified detail
     * message and the specified original exception. This constructor is used
     * to wrap another exception.
     *
     * @param   message the detail message.
     * @param   original the original exception.
     */
    public ConstructorException(String message, Exception original) {
        super(original + " -> " + message);
		iOriginal = original;
    }
}
