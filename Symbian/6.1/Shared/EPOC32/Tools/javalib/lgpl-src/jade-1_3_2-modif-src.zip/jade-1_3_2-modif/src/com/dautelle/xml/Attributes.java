/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.xml;
import java.util.ArrayList;
import java.util.Set;
import java.util.AbstractSet;
import java.util.Map;
import java.util.AbstractMap;
import java.util.Iterator;
import java.io.Serializable;
import java.awt.Color;
import java.net.URL;

/**
 * This class represents the set of attributes associated with a XML element.
 * The keys and values returned by <code>keySet()</code> and
 * <code>values()</code> respectively, are ordered first added, first.
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 */
public class Attributes extends AbstractMap implements Cloneable, Serializable, org.xml.sax.Attributes {

 /**
  * Holds the map entries.
  */
  private ArrayList entries = new ArrayList();

 /**
  * Creates an empty list of attributes.
  */
  public Attributes() {}

 /**
  * Adds a <code>String</code> attribute.
  *
  * @param  name the name of the attribute.
  * @param  value the <code>String</code> value for the specified attribute.
  */
  public void add(String name, String value) {
    Entry e = new Entry(name, value);
    entries.add(e);
  }

 /**
  * Adds a <code>boolean</code> attribute.
  *
  * @param  name the name of the attribute.
  * @param  value the <code>boolean</code> value for the specified attribute.
  */
  public void add(String name, boolean value) {
    Entry e = new Entry(name, String.valueOf(value));
    entries.add(e);
  }

 /**
  * Adds an <code>int</code> attribute.
  *
  * @param  name the name of the attribute.
  * @param  value the <code>int</code> value for the specified attribute.
  */
  public void add(String name, int value) {
    Entry e = new Entry(name, String.valueOf(value));
    entries.add(e);
  }

 /**
  * Adds a <code>long</code> attribute.
  *
  * @param  name the name of the attribute.
  * @param  value the <code>long</code> value for the specified attribute.
  */
  public void add(String name, long value) {
    Entry e = new Entry(name, String.valueOf(value));
    entries.add(e);
  }

 /**
  * Adds a <code>float</code> attribute.
  *
  * @param  name the name of the attribute.
  * @param  value the <code>float</code> value for the specified attribute.
  */
  public void add(String name, float value) {
    Entry e = new Entry(name, String.valueOf(value));
    entries.add(e);
  }

 /**
  * Adds a <code>double</code> attribute.
  *
  * @param  name the name of the attribute.
  * @param  value the <code>double</code> value for the specified attribute.
  */
  public void add(String name, double value) {
    Entry e = new Entry(name, String.valueOf(value));
    entries.add(e);
  }

 /**
  * Adds a <code>Color</code> attribute. A color attribute is represented
  * by a 24 bits hexadecimal number with the red component in bits 16-23,
  * the green component in bits 8-15, and the blue component in bits 0-7
  * (no alpha component).
  *
  * @param  name the name of the attribute.
  * @param  value the <code>Color</code> for the specified attribute.
  * @see    Color
  */
  public void add(String name, Color color) {
    int i = color.getRGB();
    char buf[] = new char[7];
    buf[0] = '#';
    for (int j=0; j < 6; j++) buf[6 - j] = hexaDigits[(i >> (j * 4)) & 0xf];
    Entry e = new Entry(name, new String(buf));
    entries.add(e);
  }
  private final static char[] hexaDigits
      = { '0', '1', '2', '3', '4', '5', '6','7', '8','9',
          'A', 'B', 'C', 'D', 'E', 'F' };

 /**
  * Adds a <code>URL</code> attribute.
  *
  * @param  name the name of the attribute.
  * @param  value the <code>URL</code> for the specified attribute.
  * @see    URL
  */
  public void add(String name, URL url) {
    Entry e = new Entry(name,  url.toExternalForm());
    entries.add(e);
  }

  /**
   * Searches for the specified attribute.
   *
   * @param  attribute the attribute searched for.
   * @return the <code>String</code> value of the specified attribute or
   *         <code>null</code> if the attribute is not found.
   */
  public String get(String attribute) {
    return (String) get((Object) attribute);
  }

  /**
   * Returns the specified <code>boolean</code> attribute.
   *
   * @param  attribute the attribute searched for.
   * @return the <code>boolean</code> value for the specified attribute.
   */
  public boolean getBoolean(String attribute) {
    return Boolean.valueOf((String) get(attribute)).booleanValue();
  }

  /**
   * Returns the specified <code>int</code> attribute.
   * This method handles string formats that are used to represent octal
   * and hexadecimal numbers.
   *
   * @param  attribute the attribute searched for.
   * @return the <code>int</code> value for the specified attribute.
   */
  public int getInt(String attribute) {
    return Integer.decode((String) get(attribute)).intValue();
  }

  /**
   * Returns the specified <code>long</code> attribute.
   * This method handles string formats that are used to represent octal
   * and hexadecimal numbers.
   *
   * @param  attribute the attribute searched for.
   * @return the <code>long</code> value for the specified attribute.
   */
  public long getLong(String attribute) {
    return Long.decode((String) get(attribute)).longValue();
  }

  /**
   * Returns the specified <code>float</code> attribute.
   *
   * @param  attribute the attribute searched for.
   * @return the <code>float</code> value for the specified attribute.
   */
  public float getFloat(String attribute) {
    return Float.valueOf((String) get(attribute)).floatValue();
  }

  /**
   * Returns the specified <code>double</code> attribute.
   *
   * @param  attribute the attribute searched for.
   * @return the <code>double</code> value for the specified attribute.
   */
  public double getDouble(String attribute) {
    return Double.valueOf((String) get(attribute)).doubleValue();
  }

  /**
   * Returns the specified <code>Color</code> attribute.
   *
   * @param  attribute the attribute searched for.
   * @return the <code>Color</code> for the specified attribute.
   * @see    Color
   */
  public Color getColor(String attribute) {
    int i = Integer.decode((String) get(attribute)).intValue();
    return new Color((i >> 16) & 0xFF, (i >> 8) & 0xFF, i & 0xFF);
  }

  /**
   * Returns the specified <code>URL</code> attribute.
   *
   * @param  attribute the attribute searched for.
   * @return the <code>URL</code> for the specified attribute
   *         or <code>null</code> if the URL is invalid.
   * @see    URL
   */
  public URL getURL(String attribute) {
    try {
      return new URL((String) get(attribute));
    } catch (java.net.MalformedURLException e) {
      return null;
    }
  }

  // Implement parent abstract methods.
  //

  private transient Set entrySet = null;
  /**
   * Returns a set view of the mappings contained in this map. Each element
   * in this set is a Map.Entry.  The set is backed by the map, so changes
   * to the map are reflected in the set, and vice-versa.  (If the map is
   * modified while an iteration over the set is in progress, the results of
   * the iteration are undefined.)  The set supports element removal, which
   * removes the corresponding entry from the map, via the
   * <tt>Iterator.remove</tt>, <tt>Set.remove</tt>, <tt>removeAll</tt>,
   * <tt>retainAll</tt> and <tt>clear</tt> operations.  It does not support
   * the <tt>add</tt> or <tt>addAll</tt> operations.
   *
   * @return a set view of the mappings contained in this map.
   */
  public Set entrySet() {
    if (entrySet == null) {
      entrySet = new AbstractSet() {
        public Iterator iterator() {
          return entries.iterator();
        }
        public int size() {
          return entries.size();
	}
        public boolean contains(Object k) {
          for (Iterator i = entries.iterator() ; i.hasNext() ;) {
            Entry e = (Entry) i.next();
            if (e.getKey().equals(k)) return true;
          }
          return false;
        }
      };
    }
    return entrySet;
  }

  /**
   * Returns a shallow copy of these Attributes.
   *
   * @return a shallow copy of this Attributes.
   */
  public Object clone() {
    try {
      Attributes a = (Attributes) super.clone();
      a.entries = (ArrayList) entries.clone();
      return a;
    } catch (CloneNotSupportedException e) {
      // this shouldn't happen, since we are Cloneable
      throw new InternalError();
    }
  }

  /**
   * This class represents the attributes' entries.
   */
  private static class Entry implements Map.Entry {
    String name;
    String value;

    Entry(String name, String value) {
      this.name = name;
      this.value = value;
    }

    protected Object clone() {
      return new Entry(name, value);
    }

    public Object getKey() {
      return name;
    }

    public Object getValue() {
      return value;
    }

    public Object setValue(Object value) {
      Object oldValue = this.value;
      this.value = (String) value;
      return oldValue;
    }

    public boolean equals(Object o) {
      if (!(o instanceof Map.Entry)) return false;
      Map.Entry e = (Map.Entry)o;
      return (name==null ? e.getKey()==null : name.equals(e.getKey())) &&
             (value==null ? e.getValue()==null : value.equals(e.getValue()));
    }

    public int hashCode() {
      return (getKey()==null ? 0 : getKey().hashCode()) ^
             (getValue()==null ? 0 : getValue().hashCode());
    }

    public String toString() {
      return name + "=" + value;
    }
  }

  // Implement interface org.xml.sax.Attributes (namespaces are not
  // used for attributes).
  //

  public int getLength() {
    return size();
  }

  public String getURI(int index) {
    return null;
  }

  public String getLocalName(int index) {
    return ((Entry) entries.get(index)).name;
  }

  public String getQName(int index) {
    return ((Entry) entries.get(index)).name;
  }

  public String getType(int index) {
    return "CDATA";
  }

  public String getValue(int index) {
    return ((Entry) entries.get(index)).value;
  }

  public int getIndex (String uri, String localPart) {
    return entries.indexOf(localPart);
  }

  public int getIndex (String qName) {
    return entries.indexOf(qName);
  }

  public String getType (String uri, String localName) {
    return "CDATA";
  }

  public String getType (String qName) {
    return "CDATA";
  }

  public String getValue (String uri, String localName) {
    return get(localName);
  }

  public String getValue (String qName) {
    return get(qName);
  }

}