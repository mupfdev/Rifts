/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.html;
import com.dautelle.xml.*;

/**
 * <P> This class represents the STYLE element of a HEAD section.</P>
 * <P> See <A href="http://www.w3.org/TR/REC-html40/present/styles.html#edef-STYLE">
 *     Style Specification</A>.</P>
 * <P> Instances of this class are immutable and can be shared.</P>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     HEAD
 */
public class STYLE implements Representable {

  /**
   * The style type (default "text/css").
   */
  public String type;

  /**
   * The style information.
   */
  public String info;

  /**
   * Constructs a default STYLE element with the specified information.
   *
   * @param  info the style information.
   */
  public STYLE(String info) {
    this.info = info;
    this.type = "text/css";
  }

  /**
   * Constructs a STYLE element with the specified information and type.
   *
   * @param  info the style information.
   * @param  type the style type.
   */
  public STYLE(String info, String type) {
    this.info = info;
    this.type = type;
  }

  /**
   * XML Constructor.
   *
   * @param  attributes "type".
   * @param  content the character entities.
   * @see    com.dautelle.xml.Constructor
   */
  public STYLE(Attributes attributes, Elements content) {
    type = attributes.get("type");
    info = ((CharData) content.get(0)).toString();
  }

  // Implements Representable
  //

  public Attributes getAttributes() {
    Attributes attributes = new Attributes();
    attributes.add("type", type);
    return attributes;
  }

  public Representable[] getContent() {
    Representable[] content = new Representable[1];
    content[0] = new CharData(info);
    return content;
  }
}