/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.math;

/**
 * This interface abstracts the fundamental arithmetic operations:
 * Addition, negate, multiplication and invert.
 * If the set of objects implementing this interface is commutative under addition
 * and associative under multiplication and the two operations are related
 * by distributive laws, then it forms a mathematical ring (linear algebra).
 * System of linear equations involving these objects can be resolved
 * using the <code>Matrix</code> class.
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     Matrix
 */
public interface Operable {

  /**
   * Returns the sum of this Operable with the one specified.
   *
   * @param   o the Operable object to be added.
   * @return  <code>this + o</code>.
   */
  public Operable add(Operable o);

  /**
   * Returns the Operable such as <code>this.negate().add(this) == ZERO</code>,
   * with <code>ZERO</code> being the neutral Operable for the addition.
   *
   * @return  <code>-this</code>.
   */
  public Operable negate();

  /**
   *  Returns the product of this Operable with the one specified.
   *
   * @param   o the Operable multiplier.
   * @return  <code>this * o</code>.
   */
  public Operable multiply(Operable o);

  /**
   * Returns the Operable such as <code>this.invert().multiply(this) == ONE
   * </code>, with <code>ONE</code> being the neutral Operable
   * for the multiplication.
   *
   * @return  <code>ONE / this</code>.
   */
  public Operable invert();

}