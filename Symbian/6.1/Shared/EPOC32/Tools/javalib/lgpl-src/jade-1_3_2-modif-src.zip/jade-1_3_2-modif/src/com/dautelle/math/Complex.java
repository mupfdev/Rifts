/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.math;
import java.io.Serializable;
import com.dautelle.xml.*;

/**
 * This class represents an immutable complex number. It implements
 * the interface <code>com.dautelle.math.Operable</code>, therefore allowing
 * the manipulation of complex number matrices.
 * <P>Because <code>com.dautelle.math.Complex</code> objects are immutable
 *  they can be shared.</P>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     Matrix
 */
public class Complex implements Serializable, Operable, Representable {

  /**
   * Its real component.
   */
  private final double real;

  /**
   * Its imaginary component.
   */
  private final double imaginary;

  /**
   * The imaginary unit <i><b>i</b></i>.
   */
  public static final Complex I = new Complex(0.0, 1.0);

  /**
   * Constructs a Complex number from its real and imaginary parts.
   *
   * @param   real the real component of this Complex number.
   * @param   imaginary the imaginary component of this Complex number.
   */
  public Complex(double real, double imaginary) {
    this.real = real;
    this.imaginary = imaginary;
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'real' and 'imaginary' attributes of this Complex
   *         number.
   * @param  content (none).
   * @see    com.dautelle.xml.Constructor
   */
  public Complex(Attributes attributes, Elements content) {
    real = attributes.getDouble("real");
    imaginary = attributes.getDouble("imaginary");
  }

  /**
   * Indicates if either the real or imaginary component of this Complex
   * is infinite.
   *
   * @return  <code>true</code> if this Complex is infinite;
   *          <code>false</code> otherwise.
   */
  public boolean isInfinite() {
    return Double.isInfinite(this.real) | Double.isInfinite(this.imaginary);
  }

  /**
   * Indicates if either the real or imaginary component of this Complex
   * is not a number.
   *
   * @return  <code>true</code> if this Complex is NaN;
   *          <code>false</code> otherwise.
   */
  public boolean isNaN() {
    return Double.isNaN(this.real) | Double.isNaN(this.imaginary);
  }

  /**
   * Returns the real component of this Complex number.
   *
   * @return  real component of this Complex number.
   */
  public double getReal() {
    return this.real;
  }

  /**
   * Returns the imaginary component of this Complex number.
   *
   * @return  imaginary component of this Complex number.
   */
  public double getImaginary() {
    return this.imaginary;
  }


  /**
   * Returns the opposite of this Complex.
   *
   * @return  <code>-this</code>.
   */
  public Complex minus() {
    return new Complex(- this.real, - this.imaginary);
  }

  /**
   * Returns the sum of this Complex with the one specified.
   *
   * @param   c the Complex to be added.
   * @return  <code>this + c</code>.
   */
  public Complex add(Complex c) {
    return new Complex(this.real + c.real, this.imaginary + c.imaginary);
  }

  /**
   * Returns the difference between this Complex and the one specified.
   *
   * @param   c the Complex to be subtracted.
   * @return  <code>this - c</code>.
   */
  public Complex subtract(Complex c) {
    return new Complex(this.real - c.real, this.imaginary - c.imaginary);
  }

  /**
   * Returns this Complex multiplied by the specified factor.
   *
   * @param   k the factor multiplier.
   * @return  <code>this * k</code>.
   */
  public Complex multiply(double k) {
    return new Complex(this.real * k, this.imaginary * k);
  }

  /**
   * Returns the product of this Complex with the one specified.
   *
   * @param   c the Complex multiplier.
   * @return  <code>this * c</code>.
   */
  public Complex multiply(Complex c) {
    return new Complex(this.real * c.real - this.imaginary * c.imaginary,
            this.real * c.imaginary + this.imaginary * c.real);
  }

  /**
   * Returns the inverse of this Complex.
   *
   * @return  <code>1 / this</code>.
   */
  public Complex inverse() {
    double k =
            ((this.real * this.real) + (this.imaginary * this.imaginary));
    return new Complex(this.real / k, - this.imaginary / k);
  }

  /**
   * Returns this Complex divided by the specified factor.
   *
   * @param   k the factor divisor.
   * @return  <code>this / k</code>.
   */
  public Complex divide(double k) {
    return new Complex(this.real / k, this.imaginary / k);
  }

  /**
   * Returns this Complex divided by the specified Complex.
   *
   * @param   c the Complex divisor.
   * @return  <code>this / c</code>.
   */
  public Complex divide(Complex c) {
    return this.multiply(c.inverse());
  }

  /**
   * Returns the conjugate of this Complex number.
   *
   * @return  <code>(this.real, - this.imaginary)</code>.
   */
  public Complex conjugate() {
    return new Complex(this.real, - this.imaginary);
  }

  /**
   * Returns the magnitude of this Complex number, also referred to
   * as the "modulus" or "length".
   *
   * @return  magnitude of this Complex number.
   */
  public double magnitude() {
    return Math.sqrt(this.real * this.real +
            this.imaginary * this.imaginary);
  }

  /**
   * Returns the argument of this Complex number. It is the angle
   * in radians, measured counter-clockwise from the real axis.
   *
   * @return  argument of this Complex number.
   */
  public double argument() {
    return Math.atan2(this.imaginary, this.real);
  }

  /**
   * Returns one of the two square root of this Complex number.
   *
   * @return  <code>sqrt(this)</code>.
   */
  public Complex sqrt() {
    double m = Math.sqrt(this.magnitude());
    double a = this.argument() / 2.0;
    return new Complex(m * Math.cos(a), m * Math.sin(a));
  }

  /**
   * Returns the exponential number <i>e</i> raised to the power of
   * this Complex.
   * Note: <code><i><b>e</b></i><sup><font size=+0><b>PI</b>*<i><b>i
   * </b></i></font></sup> = -1</code>
   *
   * @return  <code>exp(this)</code>.
   */
  public Complex exp() {
    double m = Math.exp(this.real);
    return new Complex(m * Math.cos(this.imaginary),
            m * Math.sin(this.imaginary));
  }

  /**
   * Returns the principal natural logarithm (base e) of this Complex.
   * Note: There are an infinity of solutions.
   *
   * @return  <code>log(this)</code>.
   */
  public Complex log() {
    return new Complex(Math.log(this.magnitude()), this.argument());
  }

  /**
   * Returns this Complex raised to the specified power.
   *
   * @param   e the exponent.
   * @return  <code>this**e</code>.
   */
  public Complex pow(double e) {
    double m = Math.pow(this.magnitude(), e);
    double a = this.argument() * e;
    return new Complex(m * Math.cos(a), m * Math.sin(a));
  }

  /**
   * Returns this Complex raised to the power of the specified Complex exponent.
   *
   * @param   c the exponent.
   * @return  <code>this**c</code>.
   */
  public Complex pow(Complex c) {
    double r1 = Math.log(this.magnitude());
    double i1 = this.argument();
    double r2 = (r1 * c.real) - (i1 * c.imaginary);
    double i2 = (r1 * c.imaginary) + (i1 * c.real);
    double m = Math.exp(r2);
    return new Complex(m * Math.cos(i2), m * Math.sin(i2));
  }

  /**
   * Indicates if two Complexes are "sufficiently" alike to be considered equal.
   *
   * @param   c the complex to compare with.
   * @param   tolerance the maximum magnitude of the difference between
   *          them before they are considered <i>not</i> equal
   * @return  <code>true</code> if they are considered equal;
   *          <code>false</code> otherwise.
   */
  public boolean equals(Complex c, double tolerance) {
    return this.subtract(c).magnitude() <= tolerance;
  }

  /**
   * Compares this Complex against the specified Object.
   *
   * @param   o   the object to compare with.
   * @return  <code>true</code> if the objects are the same;
   *          <code>false</code> otherwise.
   */
  public boolean equals(Object o) {
    return (o != null) && (o instanceof Complex) &&
            (this.real == ((Complex) o).real) &&
            (this.imaginary == ((Complex) o).imaginary);
  }

  /**
   * Returns the String representation of this Complex number using
   * its cartesian form.
   * i.e. <code>(1 + 2 i)</code>, <code>(1.3 - 2.5 i)</code> etc.
   *
   * @return  representation of this Complex number.
   */
  public String toString() {
    if (this.imaginary < 0) {
      return "(" + this.real + " - " + (-this.imaginary) + " i)";
    } else {
      return "(" + this.real + " + " + (+this.imaginary) + " i)";
    }
  }

  // Implements Operable
  //

  public Operable add(Operable o) {
    return this.add((Complex) o);
  }

  public Operable negate() {
    return this.minus();
  }

  public Operable multiply(Operable o) {
    return this.multiply((Complex) o);
  }

  public Operable invert() {
    return this.inverse();
  }

  // Implements Representable
  //

  public Attributes getAttributes() {
    Attributes attributes = new Attributes();
    attributes.add("real", real);
    attributes.add("imaginary", imaginary);
    return attributes;
  }

  public Representable[] getContent() {
    return null;
  }

}

