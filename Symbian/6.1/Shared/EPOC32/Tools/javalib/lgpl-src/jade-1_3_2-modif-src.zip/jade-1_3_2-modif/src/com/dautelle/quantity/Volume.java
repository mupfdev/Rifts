/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents the amount of space occupied by a three-dimensional
 * object or region of space, expressed in cubic units.
 * The measurement Unit for this quantity is the Cubic Meter (m*m*m).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #CUBIC_METER
 * @see     Length#METER
 */
public final class Volume extends Quantity {

  /**
   * This class represents Units of Volume.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toCubicMeter;

    private Unit() { // Default Unit (m*m*m)
      super((Length.METER).multiply(Length.METER).multiply(Length.METER));
      this.toCubicMeter = 1.0;
    }

    /**
     * Constructs a fundamental Unit of Volume.
     *
     * @param   symbol the symbol of this Unit
     * @param   toCubicMeter the multiplier coefficient to convert this
     *          Unit to m*m*m
     * @see     Volume#CUBIC_METER
     */
    public Unit(String symbol, double toCubicMeter) {
      super(symbol);
      this.toCubicMeter = toCubicMeter;
    }

    /**
     * Constructs a derived Unit of Volume from a Length Unit multiplied by
     * itself twice.
     *
     * @param   lengthUnit the Length Unit
     */
    public Unit(Length.Unit lengthUnit) {
      super(lengthUnit.multiply(lengthUnit).multiply(lengthUnit));
      Length length = new Length(1.0, lengthUnit);
      this.toCubicMeter =   length.doubleValue() * length.doubleValue()
                          * length.doubleValue();
    }
  }

  /**
   * Used to specify Cubic Meter Unit.
   * @ see    Length#METER
   */
  public static final Unit CUBIC_METER = new Unit();

  /**
   * Equivalent {@link #CUBIC_METER}
   */
  public static final Unit CUBIC_METRE = CUBIC_METER;

  /**
   * Used to specify Cubic Foot Unit.
   * @ see    Length#FOOT
   */
  public static final Unit CUBIC_FOOT = new Unit(Length.FOOT);

  /**
   * Used to specify Cubic Yard Unit.
   * @ see    Length#YARD
   */
  public static final Unit CUBIC_YARD = new Unit(Length.YARD);

  /**
   * Used to specify Cubic Inch Unit.
   * @ see    Length#INCH
   */
  public static final Unit CUBIC_INCH = new Unit(Length.INCH);

  /**
   * Used to specify Cubic Millimeter Unit.
   * @ see    Length#MILLIMETER
   */
  public static final Unit CUBIC_MILLIMETER = new Unit(Length.MILLIMETER);

  /**
   * Equivalent {@link #CUBIC_MILLIMETER}
   */
  public static final Unit CUBIC_MILLIMETRE = CUBIC_MILLIMETER;

  /**
   * Used to specify Cubic Centimeter Unit.
   * @ see    Length#CENTIMETER
   */
  public static final Unit CUBIC_CENTIMETER = new Unit(Length.CENTIMETER);

  /**
   * Equivalent {@link #CUBIC_CENTIMETER}
   */
  public static final Unit CUBIC_CENTIMETRE = CUBIC_CENTIMETER;

  /**
   * Used to specify Cubic Decimeter Unit.
   */
  public static final Unit CUBIC_DECIMETER = new Unit(Length.DECIMETER);

  /**
   * Equivalent {@link #CUBIC_DECIMETER}
   */
  public static final Unit CUBIC_DECIMETRE = CUBIC_DECIMETER;

  /**
   * Used to specify Cubic Decameter Unit.
   */
  public static final Unit CUBIC_DECAMETER = new Unit(Length.DECAMETER);

  /**
   * Equivalent {@link #CUBIC_DECAMETER}
   */
  public static final Unit CUBIC_DECAMETRE = CUBIC_DECAMETER;

  /**
   * Used to specify Liter Unit,
   * (1964 Standard: 1 Liter = 1 cubic decimeter).
   */
  public static final Unit LITER = new Unit("Liter", 1e-3); // Exact.

  /**
   * Equivalent {@link #LITER}
   */
  public static final Unit LITRE = LITER;

  /**
   * Used to specify Milliliter Unit.
   */
  public static final Unit MILLILITER =
          new Unit("MilliLiter", 0.001e-3); // Exact.

  /**
   * Equivalent {@link #MILLILITER}
   */
  public static final Unit MILLILITRE = MILLILITER;

  /**
   * Used to specify Centiliter Unit.
   */
  public static final Unit CENTILITER =
          new Unit("CentiLiter", 0.01e-3); // Exact.

  /**
   * Equivalent {@link #CENTILITER}
   */
  public static final Unit CENTILITRE = CENTILITER;

  /**
   * Used to specify Deciliter Unit.
   */
  public static final Unit DECILITER = new Unit("DeciLiter", 0.1e-3); // Exact.

  /**
   * Equivalent {@link #DECILITER}
   */
  public static final Unit DECILITRE = DECILITER;

  /**
   * Used to specify US gallon, Liquid Unit. The U.S. liquid gallon is based
   * on the Queen Anne or Wine gallon occupying 231 cubic inches.
   */
  public static final Unit GALLON_LIQUID_US = new Unit("Gallon_Liquid_US",
          CUBIC_INCH.toCubicMeter * 231);

  /**
   * Used to specify US Pint, Liquid Unit (= 1/8 Gallon).
   */
  public static final Unit PINT_LIQUID_US = new Unit("Pint_Liquid_US",
          GALLON_LIQUID_US.toCubicMeter / 8);

  /**
   * Used to specify US Fluid Ounce, Liquid Unit (= 1/16 Pint).
   */
  public static final Unit FLUID_OUNCE_US = new Unit("Fluid_Ounce_US",
          PINT_LIQUID_US.toCubicMeter / 16);

  /**
   * Used to specify US Fluid Dram, Liquid Unit (= 1/8 Fluid Ounce).
   */
  public static final Unit FLUID_DRAM_US = new Unit("Fluid_Dram_US",
          FLUID_OUNCE_US.toCubicMeter / 8);

  /**
   * Equivalent {@link #FLUID_DRAM_US}
   */
  public static final Unit FLUIDDRAM_US = FLUID_DRAM_US;

  /**
   * Used to specify US Gill, Liquid Unit (= 1/32 Gallon).
   */
  public static final Unit GILL_US = new Unit("Gill_US",
          GALLON_LIQUID_US.toCubicMeter / 32);

  /**
   * Used to specify US Quart, Liquid Unit (= 1/4 Gallon).
   */
  public static final Unit QUART_LIQUID_US = new Unit("Quart_Liquid_US",
          GALLON_LIQUID_US.toCubicMeter / 4);

  /**
   * Used to specify US Pottle, Liquid Unit (= 1/2 Gallon).
   */
  public static final Unit POTTLE_LIQUID_US = new Unit("Pottle_Liquid_US",
          GALLON_LIQUID_US.toCubicMeter / 2);

  /**
   * Used to specify US Pin, Liquid Unit (= 4.5 Gallons).
   */
  public static final Unit PIN_US = new Unit("Pin_US",
          GALLON_LIQUID_US.toCubicMeter * 4.5);

  /**
   * Used to specify US Firkin, Liquid Unit (= 9 Gallons).
   */
  public static final Unit FIRKIN_US = new Unit("Firkin_US",
          GALLON_LIQUID_US.toCubicMeter * 9);

  /**
   * Used to specify US Anker, Liquid Unit (= 10 Gallons).
   */
  public static final Unit ANKER_US = new Unit("Anker_US",
          GALLON_LIQUID_US.toCubicMeter * 10);

  /**
   * Used to specify US Rundlet, Liquid Unit (= 18 Gallons).
   */
  public static final Unit RUNDLET_US = new Unit("Rundlet_US",
          GALLON_LIQUID_US.toCubicMeter * 18);

  /**
   * Used to specify US Kilderkin, Liquid Unit (= 18 Gallons).
   */
  public static final Unit KILDERKIN_US = new Unit("Kilderkin_US",
          GALLON_LIQUID_US.toCubicMeter * 18);

  /**
   * Used to specify US Barrel, Liquid Unit (= 31.5 Gallons).
   */
  public static final Unit BARREL_LIQUID_US = new Unit("Barrel_US",
          GALLON_LIQUID_US.toCubicMeter * 31.5);

  /**
   * Used to specify US Tierce, Liquid Unit (= 84 Gallons).
   */
  public static final Unit TIERCE_US = new Unit("Tierce_US",
          GALLON_LIQUID_US.toCubicMeter * 84);

  /**
   * Used to specify US Hogshead, Liquid Unit (= 63 Gallons).
   */
  public static final Unit HOGSHEAD_US = new Unit("Hogshead_US",
          GALLON_LIQUID_US.toCubicMeter * 63);

  /**
   * Used to specify US Puncheon, Liquid Unit (= 126 Gallons).
   */
  public static final Unit PUNCHEON_US = new Unit("Puncheon_US",
          GALLON_LIQUID_US.toCubicMeter * 126);

  /**
   * Used to specify US Pipe, Liquid Unit (= 126 Gallons).
   */
  public static final Unit PIPE_US = new Unit("Pipe_US",
          GALLON_LIQUID_US.toCubicMeter * 126);

  /**
   * Used to specify US Butt, Liquid Unit (= 126 Gallons).
   */
  public static final Unit BUTT_US = new Unit("Butt_US",
          GALLON_LIQUID_US.toCubicMeter * 126);

  /**
   * Used to specify US Ton, Liquid Unit (= 252 Gallons).
   */
  public static final Unit TON_LIQUID_US = new Unit("Ton_Liquid_US",
          GALLON_LIQUID_US.toCubicMeter * 252);
  public static final Unit TUN_LIQUID_US = TON_LIQUID_US;

  /**
   * The U. S. dry gallon is 1/2 peck, or 4 dry quarts, or 268.8025 cubic inches,
   * or approximately 4.404 884 liters. This unit is the English corn or
   * grain gallon, standardized during the reign of Elizabeth I in the sixteenth
   * century. The earliest official definition of a dry gallon in Britain is
   * a 1303 proclamation of Edward I, where the gallon is defined as the volume
   *  of 8 pounds of wheat; the current U.S. gallon contains about 7.5 pounds of wheat.
   */
  public static final Unit GALLON_DRY_US = new Unit("Gallon_Dry_US",
          CUBIC_INCH.toCubicMeter * 268.8025);

  /**
   * Used to specify US Pint, Dry Unit (= 1  / 8 Gallon).
   */
  public static final Unit PINT_DRY_US = new Unit("Pint_Dry_US",
          GALLON_DRY_US.toCubicMeter * 8);

  /**
   * Used to specify US Quart, Dry Unit (= 1/4 Gallon).
   */
  public static final Unit QUART_DRY_US = new Unit("Quart_Dry_US",
          GALLON_DRY_US.toCubicMeter * 4);

  /**
   * Used to specify US Pottle, Dry Unit (= 1/2 Gallon).
   */
  public static final Unit POTTLE_DRY_US = new Unit("Pottle_Dry_US",
          GALLON_DRY_US.toCubicMeter * 2);

  /**
   * Used to specify US Peck, Dry Unit (= 2 Gallons).
   */
  public static final Unit PECK_US = new Unit("Peck_US",
          GALLON_DRY_US.toCubicMeter * 2);

  /**
   * Used to specify US Bucket, Dry Unit (= 4 Gallons).
   */
  public static final Unit BUCKET_US = new Unit("Bucket_US",
          GALLON_DRY_US.toCubicMeter * 4);

  /**
   * Used to specify US Bushel, Dry Unit (= 8 Gallons).
   */
  public static final Unit BUSHEL_US = new Unit("Bushel_US",
          GALLON_DRY_US.toCubicMeter * 8);

  /**
   * Used to specify US Strike, Dry Unit (= 16 Gallons).
   */
  public static final Unit STRIKE_US = new Unit("Strike_US",
          GALLON_DRY_US.toCubicMeter * 16);

  /**
   * Used to specify US Bag, Dry Unit (= 24 Gallons).
   */
  public static final Unit BAG_US = new Unit("Bag_US",
          GALLON_DRY_US.toCubicMeter * 24);

  /**
   * Used to specify US Coomb, Dry Unit (= 32 Gallons).
   */
  public static final Unit COOMB_US = new Unit("Coomb_US",
          GALLON_DRY_US.toCubicMeter * 32);

  /**
   * Used to specify US Barrel, Dry Unit (= 105 Quart).
   */
  public static final Unit BARREL_DRY_US = new Unit("Barrel_Dry_US",
          QUART_DRY_US.toCubicMeter * 105);

  /**
   * Used to specify US Quarter, Dry Unit (= 64 Gallons).
   */
  public static final Unit QUARTER_US = new Unit("Quarter_US",
          GALLON_DRY_US.toCubicMeter * 64);

  /**
   * Used to specify US Ton, Dry Unit (= 256 Gallons).
   */
  public static final Unit TON_DRY_US = new Unit("Ton_Dry_US",
          GALLON_DRY_US.toCubicMeter * 256);
  public static final Unit TUN_DRY_US = TON_DRY_US;

  /**
   * Used to specify UK Gallon Unit. The Imperial Weights and Measures Act
   * of 1824 established a new unit for all volumes, liquid or dry,
   * replacing all the other gallons in previous use in Britain.
   * The imperial gallon, designed to contain exactly 10 pounds of distilled
   * water under precisely defined conditions, holds exactly 4.546 09 liters.
   */
  public static final Unit GALLON_UK = new Unit("Gallon_UK",
          LITER.toCubicMeter * 4.54609);

  /**
   * Used to specify UK Quart Unit (= 1/4 Gallon).
   */
  public static final Unit QUART_UK = new Unit("Quart_UK",
          GALLON_UK.toCubicMeter / 4);

  /**
   * Used to specify UK Pint Unit (= 1/8 Gallon).
   */
  public static final Unit PINT_UK = new Unit("Pint_UK",
          GALLON_UK.toCubicMeter / 8);

  /**
   * Used to specify UK Fluid Ounce Unit (= 1/160 Gallon).
   */
  public static final Unit FLUID_OUNCE_UK = new Unit("Fluid_Ounce_UK",
          GALLON_UK.toCubicMeter / 160);

  /**
   * Used to specify UK Fluid Dram, Liquid Unit (= 1/8 Fluid Ounce).
   */
  public static final Unit FLUID_DRAM_UK = new Unit("Fluid_Dram_UK",
          FLUID_OUNCE_UK.toCubicMeter / 8);

  /**
   * Equivalent {@link #FLUID_DRAM_UK}
   */
  public static final Unit FLUIDDRAM_UK = FLUID_DRAM_UK;

  /**
   * Used to specify UK Gill Unit (= 1/32 Gallon).
   */
  public static final Unit GILL_UK = new Unit("Gill_UK",
          GALLON_UK.toCubicMeter / 32);

  /**
   * Used to specify UK Chopin Unit (= 1/16 Gallon).
   */
  public static final Unit CHOPIN_UK = new Unit("Chopin_UK",
          GALLON_UK.toCubicMeter / 16);

  /**
   * Used to specify UK Pottle Unit (= 1/2 Gallon).
   */
  public static final Unit POTTLE_UK = new Unit("Pottle_UK",
          GALLON_UK.toCubicMeter / 2);

  /**
   * Used to specify UK Peck Unit (= 2 Gallons).
   */
  public static final Unit PECK_UK = new Unit("Peck_UK",
          GALLON_UK.toCubicMeter * 2);

  /**
   * Used to specify UK Bucket Unit(= 4 Gallons).
   */
  public static final Unit BUCKET_UK = new Unit("Bucket_UK",
          GALLON_UK.toCubicMeter * 4);

  /**
   * Used to specify UK Pin Unit (= 4.5 Gallons).
   */
  public static final Unit PIN_UK = new Unit("Pin_UK",
          GALLON_UK.toCubicMeter * 4.5);

  /**
   * Used to specify UK Bushel Unit (= 8 Gallons).
   */
  public static final Unit BUSHEL_UK = new Unit("Bushel_UK",
          GALLON_UK.toCubicMeter * 8);

  /**
   * Used to specify UK Firkin Unit (= 9 Gallons).
   */
  public static final Unit FIRKIN_UK = new Unit("Firkin_UK",
          GALLON_UK.toCubicMeter * 9);

  /**
   * Used to specify UK Anker Unit (= 10 Gallons).
   */
  public static final Unit ANKER_UK = new Unit("Anker_UK",
          GALLON_UK.toCubicMeter * 10);

  /**
   * Used to specify UK Strike Unit (= 16 Gallons).
   */
  public static final Unit STRIKE_UK = new Unit("Strike_UK",
          GALLON_UK.toCubicMeter * 16);

  /**
   * Used to specify UK Rundlet Unit (= 18 Gallons).
   */
  public static final Unit RUNDLET_UK = new Unit("Rundlet_UK",
          GALLON_UK.toCubicMeter * 18);

  /**
   * Used to specify UK Kilderkin Unit (= 18 Gallons).
   */
  public static final Unit KILDERKIN_UK = new Unit("Kilderkin_UK",
          GALLON_UK.toCubicMeter * 18);

  /**
   * Used to specify UK Bag Unit (= 24 Gallons).
   */
  public static final Unit BAG_UK = new Unit("Bag_UK",
          GALLON_UK.toCubicMeter * 24);

  /**
   * Used to specify UK Coomb Unit (= 32 Gallons).
   */
  public static final Unit COOMB_UK = new Unit("Coomb_UK",
          GALLON_UK.toCubicMeter * 32);

  /**
   * Used to specify UK Barrel Unit (= 36 Gallons). The ubiquitous barrel
   * appears to have been the most fluid (pun intended) of measures,
   * exhibiting a multitude of sizes depending upon the commodity
   * for which it was used.
   */
  public static final Unit BARREL_UK = new Unit("Barrel_UK",
          GALLON_UK.toCubicMeter * 36);

  /**
   * Used to specify UK Sack Unit (= 40 Gallons).
   */
  public static final Unit SACK_UK = new Unit("Sack_UK",
          GALLON_UK.toCubicMeter * 40);

  /**
   * Used to specify UK Tierce Unit (= 42 Gallons).
   */
  public static final Unit TIERCE_UK = new Unit("Tierce_UK",
          GALLON_UK.toCubicMeter * 42);

  /**
   * Used to specify UK Quarter Unit (= 64 Gallons).
   */
  public static final Unit QUARTER_UK = new Unit("Quarter_UK",
          GALLON_UK.toCubicMeter * 64);

  /**
   * Used to specify UK Ton Unit (= 256 Gallons).
   */
  public static final Unit TON_UK = new Unit("Ton_Volume_UK",
          GALLON_UK.toCubicMeter * 256);
  public static final Unit TUN_UK = TON_UK;

  /**
   * Used to specify UK Chaldron Unit (= 288 Gallons).
   */
  public static final Unit CHALDRON_UK = new Unit("Chaldron_UK",
          GALLON_UK.toCubicMeter * 288);

  /**
   * Used to specify UK Wey Unit (also called a 'Horse-load' = 320 Gallons).
   */
  public static final Unit WEY_UK = new Unit("Wey",
          GALLON_UK.toCubicMeter * 320);

  /**
   * Used to specify UK Last Unit (= 640 Gallons).
   */
  public static final Unit LAST_UK = new Unit("Last",
          GALLON_UK.toCubicMeter * 640);

  /**
   * Used to specify US Cup Unit (= 8 Fluid Ounces).
   */
  public static final Unit CUP_US = new Unit("Cup_US",
          FLUID_OUNCE_US.toCubicMeter * 8);

  /**
   * Used to specify UK Cup Unit (= 10 Fluid Ounces).
   */
  public static final Unit CUP_UK = new Unit("Cup_UK",
          FLUID_OUNCE_UK.toCubicMeter * 10);

  /**
   * Used to specify US Tablespoon Unit (= 1/2 Fluid Ounces).
   */
  public static final Unit TABLESPOON_US = new Unit("Tablespoon_US",
          FLUID_OUNCE_US.toCubicMeter / 2);

  /**
   * Used to specify UK Tablespoon Unit (= 5/8 Fluid Ounces).
   */
  public static final Unit TABLESPOON_UK = new Unit("Tablespoon_UK",
          FLUID_OUNCE_UK.toCubicMeter * 5.0 / 8.0);

  /**
   * Used to specify US Teaspoon Unit (= 1/6 Fluid Ounces).
   */
  public static final Unit TEASPOON_US = new Unit("Teaspoon_US",
          FLUID_OUNCE_US.toCubicMeter / 6);

  /**
   * Used to specify UK Teaspoon Unit (= 1/6 Fluid Ounces).
   */
  public static final Unit TEASPOON_UK = new Unit("Teaspoon_UK",
          FLUID_OUNCE_UK.toCubicMeter / 6);

  /**
   * Used to specify Australian Tablespoon Unit.
   */
  public static final Unit TABLESPOON_AU =
          new Unit("Tablespoon_AU", 20.0e-6);

  /**
   * Used to specify Maas Unit (Germany).
   */
  public static final Unit MAAS = new Unit("Maas", 1.837e-3);

  /**
   * Used to specify Almude Unit (Spain).
   */
  public static final Unit ALMUDE_SPAIN =
          new Unit("Almude_Spain", 4.625e-3);

  /**
   * Used to specify Almude Unit (Portugal).
   */
  public static final Unit ALMUDE_PORTUGAL =
          new Unit("Almude_Portugal", 16.7e-3);

  /**
   * Used to specify Go Unit (Japan).
   */
  public static final Unit GO = new Unit("Go", 180.39e-6);

  /**
   * Used to specify Immi Unit (Swiss).
   */
  public static final Unit IMMI = new Unit("Immi", 1.5e-3);

  /**
   * Constructs an Volume in m*m*m from the specified volume
   * stated using the specified Unit.
   *
   * @param   value the volume stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public Volume(double value, Unit unit) {
    super(value * unit.toCubicMeter,
          CUBIC_METER);
  }

  /**
   * Constructs a Volume in m*m*m from the specified volume
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the volume stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public Volume(double value, double error, Unit unit) {
    super(value * unit.toCubicMeter,
          error * unit.toCubicMeter,
          CUBIC_METER);
  }

  /**
   * Translates a Quantity in m*m*m to a Volume.
   *
   * @param   q the quantity in m*m*m
   * @throws  UnitException quantity is not in m*m*m
   */
  public Volume(Quantity q) {
    super(q);
    if (!q.unit.equals(CUBIC_METER))
      throw new UnitException("Quantity is not in m*m*m but in " + q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in m*m*m
   */
  public Volume(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(CUBIC_METER))
      throw new UnitException("Quantity is not in m*m*m but in " + this.unit);
  }

  /**
   * Returns a Quantity corresponding to this Volume in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toCubicMeter,
                        this.absoluteError() / unit.toCubicMeter,
                        unit);
  }

  /**
   * Sets the value for this Volume stated using the specified
   * measurement Unit.
   *
   * @param   value the Volume stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toCubicMeter);
  }

  /**
   * Sets the value and the measurement error for this Volume both
   * stated using the specified measurement Unit.
   *
   * @param   value the Volume stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toCubicMeter,
        error * unit.toCubicMeter);
  }

  // Specific constructors.
  //


  // Specific methods.
  //
}

