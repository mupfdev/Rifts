/**
 * Copymaximum (c) 2000 World Builders.
 * This software may be freely used, modified or distributed.
 * For corrections, improvements or comments, send an e-mail to jean-marie@dautelle.com
 * Latest release available at http://www.magi.com/~wb/quantity.html
 *
 * WORLD BUILDERS SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE.
 */
package com.dautelle.quantity;
import com.dautelle.math.*;
import com.dautelle.xml.*;

/**
 * This class represents a measurable amount. The nature of the amount
 * is deduced from the measurement Unit. The quality of the measurement
 * is given by the measurement error.
 * Automatic error calculation (including numeric error) is performed on all
 * operations involving physical quantities. In other words, the range of the
 * result for any operations is <b><i>absolutely guaranteed</b></i>.
 *
 * This class implements the interface <code>com.dautelle.math.Operable</code>,
 * therefore it is possible to resolve systems of linear equations involving
 * physical quantities, even if the system is close to singularity. In this
 * latter case the error associated with some (or all) components of the solution
 * obtained may increase greatly.
 *
 * This class implements the interface <code>com.dautelle.xml.Representable
 * </code> and provides a XML constructor, therefore allowing the
 * storage/retrieval of Quantities in XML format.
 *
 * The unit associated with a Quantity object is immutable
 * (can never be changed).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 */
public class Quantity extends Number implements Operable, Comparable, Representable {
  /**
   * The measurement Unit.
    */
  protected final Unit unit;

  /**
   * The minimum value.
   */
  private double minimum;

  /**
   * The maximum value.
   */
  private double maximum;

  /**
   * Relative numeric error (52 bits reduced to 51 bits for safety).
   */
  private static final double BIT_ERROR = Math.pow(2, -51);

  /**
   * Constructs a physical Quantity with the specified value, stated using
   * the specified Unit.
   *
   * @param   value the value stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public Quantity(double value, Unit unit) {
    this.unit = unit;
    set(value);
  }

  /**
   * Constructs a physical Quantity with the specified value and the specified
   * built-in error, both stated using the specified Unit.
   *
   * @param   value the value stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public Quantity(double value, double error, Unit unit) {
    this.unit = unit;
    set(value, error);
  }

  /**
   * Constructs a Quantity from another Quantity (clone).
   *
   * @param   q the quantity to clone.
   */
  protected Quantity(Quantity q) {
    this.unit = q.unit;
    this.minimum = q.minimum;
    this.maximum = q.maximum;
  }

  /**
   * Constructs a Quantity with the specified unit, minimum and maximum values.
   *
   * @param   unit the measurement Unit.
   * @param   minimum the minimum value for this quantity.
   * @param   maximum the maximum value for this quantity.
   */
  protected Quantity(Unit unit, double minimum, double maximum) {
    this.unit = unit;
    this.minimum = minimum;
    this.maximum = maximum;
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   */
  public Quantity(Attributes attributes, Elements content) {
    this(attributes.getDouble("value"), attributes.getDouble("error"),
         Unit.parse(attributes.get("unit")));
  }

  /**
   * Sets the value and the measurement error for this Quantity both
   * stated using this Quantity measurement unit.
   *
   * @param   value the value stated using this Quantity Unit.
   * @param   error the absolute error.
   * @throws  IllegalArgumentException the absolute error is always positive.
   * @see     #unit()
   */
  public void set(double value, double error) {
    if (error < 0.0)
      throw new IllegalArgumentException("The absolute error is always positive.");
    double numericError = Math.max(Math.abs(BIT_ERROR * value), Double.MIN_VALUE);
    double maxError = Math.max(numericError, error);
    this.minimum = value - maxError;
    this.maximum = value + maxError;
  }

  /**
   * Sets the value for this Quantity stated using this Quantity measurement
   * unit.
   *
   * @param   value the value stated using this Quantity Unit.
   * @see     #unit()
   */
  public void set(double value) {
    double numericError = Math.max(Math.abs(BIT_ERROR * value), Double.MIN_VALUE);
    this.minimum = value - numericError;
    this.maximum = value + numericError;
  }

  /**
   * Sets this Quantity to the value and error of the specified Quantity.
   *
   * @param   q the quantity to be copied from.
   * @throws  IllegalArgumentException both quantities shall be specified using
   *          identical units.
   */
  public void set(Quantity q) {
    if (!this.unit.equals(q.unit)) throw new IllegalArgumentException(
              "Both Quantities must be stated using identical units.");
    this.minimum = q.minimum;
    this.maximum = q.maximum;
  }

  /**
   * Returns the amount by which the estimated value may differ from
   * the true value.
   *
   * @return  the absolute error.
   */
  public double absoluteError() {
    return (this.maximum - this.minimum) / 2.0;
  }

  /**
   * Returns the percentage by which the estimated value may differ
   * from the true value.
   *
   * @return  the relative error.
   */
  public double relativeError() {
    return (this.maximum - this.minimum) / (this.minimum + this.maximum);
  }

  /**
   * Returns this Quantity's measurement Unit.
   *
   * @return  the measurement Unit
   * @see     Unit
   */
  public Unit unit() {
    return this.unit;
  }

  /**
   * Returns the minimum value for this Quantity.
   *
   * @return  the minimun value.
   */
  public double minimum() {
    return this.minimum;
  }

  /**
   * Returns the maximum value for this Quantity.
   *
   * @return  the maximum value.
   */
  public double maximum() {
    return this.maximum;
  }

  // Arithmetic Operations
  //

  /**
   * Returns the Quantity -(this).
   *
   * @return  -(this).
   */
  public Quantity minus() {
    return new Quantity(this.unit, -this.maximum, -this.minimum);
  }

  /**
   * Returns the Quantity (this + q).
   *
   * @param   q the quantity to be added.
   * @return  (this + q).
   * @throws  UnitException quantities do not use the same Units.
   */
  public Quantity add(Quantity q) {
    if (!this.unit.equals(q.unit))
      throw new UnitException("Cannot add \"" + this.unit + "\" with \"" +
              q.unit + "\"");
    return new Quantity(this.unit, this.minimum + q.minimum,
            this.maximum + q.maximum);
  }

  /**
   * Returns the Quantity (this - q).
   *
   * @param   q the quantity to be subtracted.
   * @return  (this + q.minus()).
   * @throws  UnitException quantities do not use the same Units.
   * @see     #minus()
   */
  public Quantity subtract(Quantity q) {
    if (!this.unit.equals(q.unit))
      throw new UnitException("Cannot subtract \"" + this.unit + "\" with \"" +
              q.unit + "\"");
    return this.add(q.minus());
  }

  /**
   * Returns this Quantity multiplied by the specified factor.
   *
   * @param   k the factor multiplier.
   * @return  (this * k).
   */
  public Quantity multiply(double k) {
    if (k < 0)
      return new Quantity(this.unit, this.maximum * k, this.minimum * k);
    else
      return new Quantity(this.unit, this.minimum * k, this.maximum * k);
  }

  /**
   * Returns the Quantity  (this * q).
   *
   * @param   q the quantity multiplier.
   * @return  (this * q).
   */
  public Quantity multiply(Quantity q) {
    if (this.minimum > -this.maximum)
      if (q.minimum > -q.maximum)
        return new Quantity(this.unit.multiply(q.unit),
                this.minimum * q.minimum, this.maximum * q.maximum);
      else
        return new Quantity(this.unit.multiply(q.unit),
                this.maximum * q.minimum, this.minimum * q.maximum);
    else if (q.minimum > -q.maximum)
      return new Quantity(this.unit.multiply(q.unit),
              this.minimum * q.maximum, this.maximum * q.minimum);
    else
      return new Quantity(this.unit.multiply(q.unit),
              this.maximum * q.maximum, this.minimum * q.minimum);
  }

  /**
   * Returns the Quantity (1 / this).
   *
   * @return  (1 / this).
   */
  public Quantity inverse() {
    if ((this.minimum <= 0) && (this.maximum >= 0))
      return new Quantity(this.unit.inverse(),
              Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY);
    return new Quantity(this.unit.inverse(), 1 / this.maximum,
            1 / this.minimum);
  }

  /**
   * Returns this Quantity divided by the specified factor.
   *
   * @param   k the factor divisor.
   * @return  (this / k).
   */
  public Quantity divide(double k) {
    if (k < 0)
      return new Quantity(this.unit, this.maximum / k, this.minimum / k);
    else
      return new Quantity(this.unit, this.minimum / k, this.maximum / k);
  }

  /**
   * Returns the Quantity (this / q).
   *
   * @param   q the quantity divisor.
   * @return  (this * q.inverse()).
   * @see     #inverse()
   */
  public Quantity divide(Quantity q) {
    return this.multiply(q.inverse());
  }

  /**
   * Returns the absolute value of this Quantity.
   *
   * @return  abs(this).
   */
  public Quantity abs() {
    if (this.minimum > -this.maximum)
      return this;
    else
      return this.minus();
  }

  /**
   * Returns the square root of this Quantity (unique).
   *
   * @return  sqrt(this).
   * @throws  UnitException resulting root has no defined unit.
   */
  public Quantity sqrt() {
    return new Quantity(this.unit.root(2), Math.sqrt(this.minimum),
            Math.sqrt(this.maximum));
  }

  /**
   * Returns a random but possible value for this Quantity.
   *
   * @return  a double value r such as <code>this.minimum &lt r &gt this.maximum</code>.
   */
  public double random() {
    return this.minimum + Math.random() * (this.maximum - this.minimum);
  }

  /**
   * @deprecated As of J.A.D.E. version 1.3,
   * replaced by {@link Matrix#solve(Matrix, Matrix)}.
   */
  public static Matrix solve(Matrix A, Matrix B) {
    return Matrix.solve(A, B);
  }

  /**
   * Indicates if two Quantities are "sufficiently" close to be considered equal.
   *
   * @param   q the quantity to compare with.
   * @return  <code>true</code> if their range overlaps;
   *          <code>false</code> otherwise.
   */
  public boolean equals(Quantity q) {
    Quantity diff = this.subtract(q);
    if ((diff.minimum > 0) && (diff.maximum > 0))
      return false;
    if ((diff.minimum < 0) && (diff.maximum < 0))
      return false;
    return true; // Difference encompasses zero.
  }

  /**
   * Compares this Quantity against the specified Object.
   *
   * @param   o   the object to compare with.
   * @return  <code>true</code> if the objects are the same;
   *          <code>false</code> otherwise.
   */
  public boolean equals(Object o) {
    return (o != null) && (o instanceof Quantity) &&
            (this.equals((Quantity) o));
  }

  /**
   * Returns the decimal String representation of this Quantity including its
   * Unit (if any). The uncertainty is always on the last represented digit.&nbsp
   * For example, <code>new Quantity(1.23456)</code> is represented
   * by <code>"1.2345600000000"</code> (the error on the 14nd digit is due to
   * numerical errors), but <code>new Quantity(1.23456, 0.001)</code> is
   * represented by <code>"1.235"</code>.
   *
   * @return  representation of this Quantity.
   */
  public String toString() {
    final double log10 = Math.log(10);

    double value = this.doubleValue();
    double error = Math.max(Math.abs(this.absoluteError()),
            Math.abs(value) * BIT_ERROR);

    if (Double.isNaN(value))
      return "NaN";
    if (Double.isInfinite(value))
      return "Infinity";

    int logValue = (int) Math.floor(Math.log(Math.abs(value)) / log10);
    int logError = (int) Math.floor(Math.log(error) / log10);
    int nbrDigit = logValue - logError;
    long digitValue = Math.round(value * Math.pow(10, -logError));

    String sign = (digitValue < 0) ? "-" : "";
    String digitString = Long.toString(Math.abs(digitValue));
    int exponent = logError;

    int dotPos = digitString.length() + exponent;
    if ((dotPos < 0) || (dotPos > digitString.length())) {
      // Scientific notation has to be used.
      exponent += digitString.length() - 1;
      return sign + digitString.substring(0, 1) + "." +
              digitString.substring(1) + "e" +
              Integer.toString(exponent) + " " + this.unit();
    } else {
      // No exponent necessary.
      return sign + digitString.substring(0, dotPos) + "." +
              digitString.substring(dotPos) + " " + this.unit();
    }
  }

  // Implements java.lang.Number abstract methods
  //

  public int intValue() {
    return (int) Math.round((this.minimum + this.maximum) / 2);
  }

  public long longValue() {
    return Math.round((this.minimum + this.maximum) / 2);
  }

  public float floatValue() {
    return (float)((this.minimum + this.maximum) / 2.0);
  }

  public double doubleValue() {
    return (this.minimum + this.maximum) / 2.0;
  }

  // Implements Comparable
  //

  /**
   * Compares two Quantities. In order to be compared, the quantities must have the same units.
   *
   * @param   q the quantity to compare with.
   * @return  -1, 0 or 1 as this quantity is numerically less than, equal
   *          to, or greater than <code>q</code>.
   * @throws  UnitException quantities do not use the same units.
   * @see     #equals(Quantity)
   */
  public int compareTo(Quantity q) {
    if (!this.unit.equals(q.unit))
      throw new UnitException("Cannot compare \"" + this.unit + "\" with \"" +
              q.unit + "\"");
    if (this.equals(q))
      return 0;
    return (this.subtract(q).doubleValue() < 0 ? -1 : 1);
  }

  public int compareTo(Object o) {
    return this.compareTo((Quantity) o);
  }

  // Implements Operable.
  //

  public Operable add(Operable o) {
    return this.add((Quantity) o);
  }

  public Operable negate() {
    return this.minus();
  }

  public Operable multiply(Operable o) {
    return this.multiply((Quantity) o);
  }

  public Operable invert() {
    return this.inverse();
  }

  // Implements Representable
  //

  public Attributes getAttributes() {
    Attributes attributes = new Attributes();
    attributes.add("value", doubleValue());
    attributes.add("error", absoluteError());
    attributes.add("unit", unit.toString());
    return attributes;
  }

  public Representable[] getContent() {
    return null;
  }

}

