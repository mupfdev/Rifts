/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents the extent of a planar region or of the surface of
 * a solid measured in square units.
 * The measurement Unit for this quantity is the Square Meter (m*m).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #SQUARE_METER
 * @see     Length#METER
 */
public final class Area extends Quantity {

  /**
   * This class represents Units of Area.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toSquareMeter;

    private Unit() { // Default Unit (m*m)
      super((Length.METER).multiply(Length.METER));
      this.toSquareMeter = 1.0;
    }

    /**
      * Constructs a fundamental Unit of Area.
      *
      * @param   symbol the symbol of this Unit
      * @param   toSquareMeter the multiplier coefficient to convert this
      *          Unit to m*m
      * @see     Area#SQUARE_METER
      */
    public Unit(String symbol, double toSquareMeter) {
      super(symbol);
      this.toSquareMeter = toSquareMeter;
    }

    /**
      * Constructs a derived Unit of Area from a Length Unit multiplied by
      * itself.
      *
      * @param   lengthUnit the Length Unit
      */
    public Unit(Length.Unit lengthUnit) {
      super(lengthUnit.multiply(lengthUnit));
      Length length = new Length(1.0, lengthUnit);
      this.toSquareMeter = length.doubleValue() * length.doubleValue();
    }
  }

  /**
   * Used to specify Square Meter Unit.
   * @ see    Length#METER
   */
  public static final Unit SQUARE_METER = new Unit();

  /**
   * Equivalent {@link #SQUARE_METER}
   */
  public static final Unit SQUARE_METRE = SQUARE_METER;

  /**
   * Used to specify Square Foot Unit.
   * @ see    Length#FOOT
   */
  public static final Unit SQUARE_FOOT = new Unit(Length.FOOT);

  /**
   * Used to specify Square Yard Unit.
   * @ see    Length#YARD
   */
  public static final Unit SQUARE_YARD = new Unit(Length.YARD);

  /**
   * Used to specify Square Inch Unit.
   * @ see    Length#INCH
   */
  public static final Unit SQUARE_INCH = new Unit(Length.INCH);

  /**
   * Used to specify Square Mile Unit.
   * @ see    Length#MILE
   */
  public static final Unit SQUARE_MILE = new Unit(Length.MILE);

  /**
   * Used to specify Square Millimeter Unit.
   * @ see    Length#MILLIMETER
   */
  public static final Unit SQUARE_MILLIMETER = new Unit(Length.MILLIMETER);

  /**
   * Equivalent {@link #SQUARE_MILLIMETER}
   */
  public static final Unit SQUARE_MILLIMETRE = SQUARE_MILLIMETER;

  /**
   * Used to specify Square Centimeter Unit.
   * @ see    Length#CENTIMETER
   */
  public static final Unit SQUARE_CENTIMETER = new Unit(Length.CENTIMETER);

  /**
   * Equivalent {@link #SQUARE_CENTIMETER}
   */
  public static final Unit SQUARE_CENTIMETRE = SQUARE_CENTIMETER;

  /**
   * Used to specify Square Kilometer Unit.
   * @ see    Length#KILOMETER
   */
  public static final Unit SQUARE_KILOMETER = new Unit(Length.KILOMETER);

  /**
   * Equivalent {@link #SQUARE_KILOMETER}
   */
  public static final Unit SQUARE_KILOMETRE = SQUARE_KILOMETER;

  /**
   * Used to specify Square Rod Unit.
   * @ see    Length#ROD
   */
  public static final Unit SQUARE_ROD = new Unit(Length.ROD);

  /**
   * Equivalent {@link #SQUARE_ROD}
   */
  public static final Unit SQUARE_POLE = SQUARE_ROD;

  /**
   * Used to specify Acre Unit (= 1/640 Square Mile).
   */
  public static final Unit ACRE = new Unit("Acre",
          SQUARE_MILE.toSquareMeter / 640.0); // Exact.

  /**
   * Used to specify Hectare Unit.
   */
  public static final Unit HECTARE = new Unit("Hectare", 10000); // Exact.

  /**
   * Used to specify Are Unit.
   */
  public static final Unit ARE = new Unit("Are", 100); // Exact.

  /**
   * Used to specify Rood Unit.
   */
  public static final Unit ROOD = new Unit("Rood", 1011.7141056); // Exact.

  /**
   * Used to specify Square (of timber) Unit.
   */
  public static final Unit SQUARE = new Unit("Square", 9.290304); // Exact.

  /**
   * Used to specify Circular Inch Unit.
   */
  public static final Unit CIRCULAR_INCH =
          new Unit("Circular_Inch", 0.000506707479);

  /**
   * Used to specify Township Unit.
   */
  public static final Unit TOWNSHIP = new Unit("Township", 93239571.972);

  /**
   * Used to specify Morgen Unit (Dutch & South Africa).
   */
  public static final Unit MORGEN = new Unit("Morgen", 8565.171618);

  /**
   * Used to specify Mou Unit (China).
   */
  public static final Unit MOU = new Unit("Mou", 674.462135);

  /**
   * Used to specify SE Unit (Japan).
   */
  public static final Unit SE = new Unit("SE", 99.1772468);

  /**
   * Used to specify Section Unit.
   */
  public static final Unit SECTION =
          new Unit("Section", 2589988.110336); // Exact.

  /**
   * Constructs an Area in m*m from the specified area
   * stated using the specified Unit.
   *
   * @param   value the area stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public Area(double value, Unit unit) {
    super(value * unit.toSquareMeter,
          SQUARE_METER);
  }

  /**
   * Constructs an Area in m*m from the specified area
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the area stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public Area(double value, double error, Unit unit) {
    super(value * unit.toSquareMeter,
          error * unit.toSquareMeter,
          SQUARE_METER);
  }

  /**
   * Translates a Quantity in m*m to an Area.
   *
   * @param   q the quantity in m*m
   * @throws  UnitException quantity is not in m*m
   */
  public Area(Quantity q) {
    super(q);
    if (!q.unit.equals(SQUARE_METER))
      throw new UnitException("Quantity is not in m*m but in " + q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in m*m
   */
  public Area(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(SQUARE_METER))
      throw new UnitException("Quantity is not in m*m but in " + this.unit);
  }

  /**
   * Returns a Quantity corresponding to this Area in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toSquareMeter,
                        this.absoluteError() / unit.toSquareMeter,
                        unit);
  }

  /**
   * Sets the value for this Area stated using the specified
   * measurement Unit.
   *
   * @param   value the Area stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toSquareMeter);
  }

  /**
   * Sets the value and the measurement error for this Area both
   * stated using the specified measurement Unit.
   *
   * @param   value the Area stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toSquareMeter,
        error * unit.toSquareMeter);
  }

  // Specific constructors.
  //

  /**
   * Constructs an Area from a radius and an angle (slice of a circle).
   * It returns the Area defined from the specified
   * circle radius and central angle.
   *
   * @param   radius the circle radius
   * @param   theta the central angle
   */
  public Area(Length radius, Angle theta) {
    this(theta.multiply(radius).multiply(radius).divide(
            new Angle(2, Angle.RADIAN)));
  }

  // Specific methods.
  //
}

