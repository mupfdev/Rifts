/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents an Electric Resistance.
 * The measurement Unit for this quantity is the Ohm
 * (Volt / Ampere = kg*m*m/A/A/s/s/s).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #OHM
 * @see     ElectricPotential#VOLT
 * @see     ElectricCurrent#AMPERE
 */
public final class ElectricResistance extends Quantity {

  /**
   * This class represents Units of ElectricResistance.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toOhm;

    private Unit() { // Default Unit (Ohm)
      super(ElectricPotential.VOLT.divide(ElectricCurrent.AMPERE));
      this.toOhm = 1.0;
    }

    /**
     * Constructs a fundamental Unit of ElectricResistance.
     *
     * @param   symbol the symbol of this Unit
     * @param   toOhm the multiplier coefficient to convert this
     *          Unit to Ohm
     * @see     ElectricResistance#OHM
     */
    public Unit(String symbol, double toOhm) {
      super(symbol);
      this.toOhm = toOhm;
    }
  }

  /**
   * Used to specify Ohm Unit. One Ohm is equal to the resistance of a conductor
   * in which a current of one ampere is produced by a potential of one volt
   * across its terminals.
   * It is named after the German physicist Georg Simon Ohm (1789-1854).
   */
  public static final Unit OHM = new Unit();

  /**
   * Constructs an ElectricResistance in Ohm from the specified electric resistance
   * stated using the specified Unit.
   *
   * @param   value the electric resistance stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public ElectricResistance(double value, Unit unit) {
    super(value * unit.toOhm,
          OHM);
  }

  /**
   * Constructs an ElectricResistance in Ohm from the specified electric resistance
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the electric resistance stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public ElectricResistance(double value, double error, Unit unit) {
    super(value * unit.toOhm,
          error * unit.toOhm,
          OHM);
  }

  /**
   * Translates a Quantity in Ohm to ElectricResistance.
   *
   * @param   q the quantity in Ohm
   * @throws  UnitException quantity is not in  kg*m*m/A/A/s/s/s
   */
  public ElectricResistance(Quantity q) {
    super(q);
    if (!q.unit.equals(OHM))
      throw new UnitException(
              "Quantity is not in kg*m*m/A/A/s/s/s but in " + q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in  kg*m*m/A/A/s/s/s
   */
  public ElectricResistance(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(OHM))
      throw new UnitException(
              "Quantity is not in kg*m*m/A/A/s/s/s but in " + this.unit);
  }

  /**
   * Returns a Quantity corresponding to this ElectricResistance in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toOhm,
                        this.absoluteError() / unit.toOhm,
                        unit);
  }

  /**
   * Sets the value for this ElectricResistance stated using the specified
   * measurement Unit.
   *
   * @param   value the ElectricResistance stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toOhm);
  }

  /**
   * Sets the value and the measurement error for this ElectricResistance both
   * stated using the specified measurement Unit.
   *
   * @param   value the ElectricResistance stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toOhm,
        error * unit.toOhm);
  }

  // Specific constructors.
  //


  // Specific methods.
  //
}

