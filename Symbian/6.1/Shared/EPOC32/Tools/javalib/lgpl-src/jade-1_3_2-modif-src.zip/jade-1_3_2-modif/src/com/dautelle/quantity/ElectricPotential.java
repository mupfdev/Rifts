/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents an Electric Potential or Electromotive Force.
 * The measurement Unit for this quantity is the Volt
 * (Joule / Coulomb = kg*m*m/A/s/s/s).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #VOLT
 * @see     Energy#JOULE
 * @see     ElectricCharge#COULOMB
 */
public final class ElectricPotential extends Quantity {

  /**
   * This class represents Units of ElectricPotential.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toVolt;

    private Unit() { // Default Unit (Volt)
      super(Energy.JOULE.divide(ElectricCharge.COULOMB));
      this.toVolt = 1.0;
    }

    /**
      * Constructs a fundamental Unit of ElectricPotential.
      *
      * @param   symbol the symbol of this Unit
      * @param   toVolt the multiplier coefficient to convert this
      *          Unit to Volt
      * @see     ElectricPotential#VOLT
      */
    public Unit(String symbol, double toVolt) {
      super(symbol);
      this.toVolt = toVolt;
    }
  }

  /**
   * Used to specify Volt Unit. One Volt is equal to the difference of
   * electric potential between two points on a conducting wire carrying
   * a constant current of one ampere when the power dissipated between
   * the points is one watt.
   * It is named after the Italian physicist Count Alessandro Volta (1745-1827).
   */
  public static final Unit VOLT = new Unit();

  /**
   * Used to specify MilliVolt Unit.
   * @ see    #VOLT
   */
  public static final Unit MILLIVOLT = new Unit("MilliVolt", 1e-3); // Exact.

  /**
   * Used to specify MicroVolt Unit.
   * @ see    #VOLT
   */
  public static final Unit MICROVOLT = new Unit("MicroVolt", 1e-6); // Exact.

  /**
   * Used to specify NanoVolt Unit.
   * @ see    #VOLT
   */
  public static final Unit NANOVOLT = new Unit("NanoVolt", 1e-9); // Exact.

  /**
   * Constructs an ElectricPotential in Volt from the specified electric potential
   * stated using the specified Unit.
   *
   * @param   value the electric potential stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public ElectricPotential(double value, Unit unit) {
    super(value * unit.toVolt,
          VOLT);
  }

  /**
   * Constructs an ElectricPotential in Volt from the specified electric potential
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the electric potential stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public ElectricPotential(double value, double error, Unit unit) {
    super(value * unit.toVolt,
          error * unit.toVolt,
          VOLT);
  }

  /**
   * Translates a Quantity in Volt to ElectricPotential.
   *
   * @param   q the quantity in Volt
   * @throws  UnitException quantity is not in  kg*m*m/A/s/s/s
   */
  public ElectricPotential(Quantity q) {
    super(q);
    if (!q.unit.equals(VOLT))
      throw new UnitException(
              "Quantity is not in kg*m*m/A/s/s/s but in " + q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in  kg*m*m/A/s/s/s
   */
  public ElectricPotential(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(VOLT))
      throw new UnitException(
              "Quantity is not in kg*m*m/A/s/s/s but in " + this.unit);
  }

  /**
   * Returns a Quantity corresponding to this ElectricPotential in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toVolt,
                        this.absoluteError() / unit.toVolt,
                        unit);
  }

  /**
   * Sets the value for this ElectricPotential stated using the specified
   * measurement Unit.
   *
   * @param   value the ElectricPotential stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toVolt);
  }

  /**
   * Sets the value and the measurement error for this ElectricPotential both
   * stated using the specified measurement Unit.
   *
   * @param   value the ElectricPotential stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toVolt,
        error * unit.toVolt);
  }

  // Specific constructors.
  //


  // Specific methods.
  //
}

