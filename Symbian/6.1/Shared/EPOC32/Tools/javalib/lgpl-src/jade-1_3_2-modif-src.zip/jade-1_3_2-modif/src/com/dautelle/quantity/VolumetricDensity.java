/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents a mass per unit volume of a substance under
 * specified conditions of pressure and temperature
 * The measurement Unit for this quantity is the Kilogram per Cubic Meter (kg/m/m/m).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #KILOGRAM_PER_CUBIC_METER
 * @see     Mass#KILOGRAM
 * @see     Volume#CUBIC_METER
 */
public final class VolumetricDensity extends Quantity {

  /**
   * This class represents Units of Volumetric Density.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toKilogramPerCubicMeter;

    private Unit() { // Default Unit (kg/m/m/m)
      super((Mass.KILOGRAM).divide(Volume.CUBIC_METER));
      this.toKilogramPerCubicMeter = 1.0;
    }

    /**
     * Constructs a fundamental Unit of Volumetric Density.
     *
     * @param   symbol the symbol of this Unit
     * @param   toKilogramPerCubicMeter the multiplier coefficient to convert this
     *          Unit to kg/m/m/m
     * @see     VolumetricDensity#KILOGRAM_PER_CUBIC_METER
     */
    public Unit(String symbol, double toKilogramPerCubicMeter) {
      super(symbol);
      this.toKilogramPerCubicMeter = toKilogramPerCubicMeter;
    }

    /**
     * Constructs a derived Unit of Volumetric Density from a Mass Unit divided by
     * a Volume Unit.
     *
     * @param   massUnit the Mass Unit
     * @param   volumeUnit the Volume Unit
     */
    public Unit(Mass.Unit massUnit, Volume.Unit volumeUnit) {
      super(massUnit.divide(volumeUnit));
      Mass mass = new Mass(1.0, massUnit);
      Volume volume = new Volume(1.0, volumeUnit);
      this.toKilogramPerCubicMeter = mass.doubleValue() / volume.doubleValue();
    }
  }

  /**
   * Used to specify Kilogram per Cubic Meter Unit.
   */
  public static final Unit KILOGRAM_PER_CUBIC_METER = new Unit();

  /**
   * Equivalent {@link #KILOGRAM_PER_CUBIC_METER}
   */
  public static final Unit KILOGRAM_PER_CUBIC_METRE =
          KILOGRAM_PER_CUBIC_METER;

  /**
   * Used to specify Grain per Gallon (U.K.) Unit.
   * @ see    Mass#GRAIN
   * @ see    Volume#GALLON_UK
   */
  public static final Unit GRAIN_PER_GALLON_UK =
          new Unit(Mass.GRAIN, Volume.GALLON_UK);

  /**
   * Used to specify Grain per Gallon (U.S.) Unit.
   * @ see    Mass#GRAIN
   * @ see    Volume#GALLON_LIQUID_US
   */
  public static final Unit GRAIN_PER_GALLON_US =
          new Unit(Mass.GRAIN, Volume.GALLON_LIQUID_US);

  /**
   * Used to specify Gram per Cubic Centimeter Unit.
   * @ see    Mass#GRAM
   * @ see    Volume#CUBIC_CENTIMETER
   */
  public static final Unit GRAM_PER_CUBIC_CENTIMETER =
          new Unit(Mass.GRAM, Volume.CUBIC_CENTIMETER);

  /**
   * Equivalent {@link #GRAM_PER_CUBIC_CENTIMETER}
   */
  public static final Unit GRAM_PER_CUBIC_CENTIMETRE =
          GRAM_PER_CUBIC_CENTIMETER;

  /**
   * Used to specify Gram per Liter Unit.
   * @ see    Mass#GRAM
   * @ see    Volume#LITER
   */
  public static final Unit GRAM_PER_LITER =
          new Unit(Mass.GRAM, Volume.LITER);

  /**
   * Equivalent {@link #GRAM_PER_LITER}
   */
  public static final Unit GRAM_PER_LITRE = GRAM_PER_LITER;

  /**
   * Used to specify Gram per Milliliter Unit.
   * @ see    Mass#GRAM
   * @ see    Volume#MILLILITER
   */
  public static final Unit GRAM_PER_MILLILITER =
          new Unit(Mass.GRAM, Volume.MILLILITER);

  /**
   * Equivalent {@link #GRAM_PER_MILLILITER}
   */
  public static final Unit GRAM_PER_MILLILITRE = GRAM_PER_MILLILITER;

  /**
   * Used to specify Milligram per Milliliter Unit.
   * @ see    Mass#MILLIGRAM
   * @ see    Volume#MILLILITER
   */
  public static final Unit MILLIGRAM_PER_MILLILITER =
          new Unit(Mass.MILLIGRAM, Volume.MILLILITER);

  /**
   * Equivalent {@link #MILLIGRAM_PER_MILLILITER}
   */
  public static final Unit MILLIGRAM_PER_MILLILITRE =
          MILLIGRAM_PER_MILLILITER;

  /**
   * Used to specify Milligram per Liter Unit.
   * @ see    Mass#MILLIGRAM
   * @ see    Volume#LITER
   */
  public static final Unit MILLIGRAM_PER_LITER =
          new Unit(Mass.MILLIGRAM, Volume.LITER);

  /**
   * Equivalent {@link #MILLIGRAM_PER_LITER}
   */
  public static final Unit MILLIGRAM_PER_LITRE = MILLIGRAM_PER_LITER;

  /**
   * Used to specify Kilogram per Liter Unit.
   * @ see    Mass#KILOGRAM
   * @ see    Volume#LITER
   */
  public static final Unit KILOGRAM_PER_LITER =
          new Unit(Mass.KILOGRAM, Volume.LITER);

  /**
   * Equivalent {@link #KILOGRAM_PER_LITER}
   */
  public static final Unit KILOGRAM_PER_LITRE = KILOGRAM_PER_LITER;

  /**
   * Used to specify Ounce per Cubic Inch Unit.
   * @ see    Mass#OUNCE
   * @ see    Volume#CUBIC_INCH
   */
  public static final Unit OUNCE_PER_CUBIC_INCH =
          new Unit(Mass.OUNCE, Volume.CUBIC_INCH);

  /**
   * Used to specify Ounce per Gallon (U.K.) Unit.
   * @ see    Mass#OUNCE
   * @ see    Volume#GALLON_UK
   */
  public static final Unit OUNCE_PER_GALLON_UK =
          new Unit(Mass.OUNCE, Volume.GALLON_UK);

  /**
   * Used to specify Ounce per Gallon (U.S.) Unit.
   * @ see    Mass#OUNCE
   * @ see    Volume#GALLON_LIQUID_US
   */
  public static final Unit OUNCE_PER_GALLON_US =
          new Unit(Mass.OUNCE, Volume.GALLON_LIQUID_US);

  /**
   * Used to specify Pound per Cubic Inch Unit.
   * @ see    Mass#POUND
   * @ see    Volume#CUBIC_INCH
   */
  public static final Unit POUND_PER_CUBIC_INCH =
          new Unit(Mass.POUND, Volume.CUBIC_INCH);

  /**
   * Used to specify Pound per Cubic Foot Unit.
   * @ see    Mass#POUND
   * @ see    Volume#CUBIC_FOOT
   */
  public static final Unit POUND_PER_CUBIC_FOOT =
          new Unit(Mass.POUND, Volume.CUBIC_FOOT);

  /**
   * Used to specify Pound per Gallon (U.K.) Unit.
   * @ see    Mass#POUND
   * @ see    Volume#GALLON_UK
   */
  public static final Unit POUND_PER_GALLON_UK =
          new Unit(Mass.POUND, Volume.GALLON_UK);

  /**
   * Used to specify Pound per Gallon (U.S.) Unit.
   * @ see    Mass#POUND
   * @ see    Volume#GALLON_LIQUID_US
   */
  public static final Unit POUND_PER_GALLON_US =
          new Unit(Mass.POUND, Volume.GALLON_LIQUID_US);

  /**
   * Used to specify Tonne per Cubic Meter Unit.
   * @ see    Mass#TONNE
   * @ see    Volume#CUBIC_METER
   */
  public static final Unit TONNE_PER_CUBIC_METER =
          new Unit(Mass.TONNE, Volume.CUBIC_METER);

  /**
   * Equivalent {@link #TONNE_PER_CUBIC_METER}
   */
  public static final Unit TONNE_PER_CUBIC_METRE = TONNE_PER_CUBIC_METER;

  /**
   * Used to specify Ton per Cubic Yard (U.K) Unit.
   * @ see    Mass#TON_UK
   * @ see    Volume#CUBIC_YARD
   */
  public static final Unit TON_PER_CUBIC_YARD_UK =
          new Unit(Mass.TON_UK, Volume.CUBIC_YARD);

  /**
   * Used to specify Ton per Cubic Yard (U.S.) Unit.
   * @ see    Mass#TON_US
   * @ see    Volume#CUBIC_YARD
   */
  public static final Unit TON_PER_CUBIC_YARD_US =
          new Unit(Mass.TON_US, Volume.CUBIC_YARD);

  /**
   * Constructs a Volumetric Density in kg/m/m/m from the specified volumetric density
   * stated using the specified Unit.
   *
   * @param   value the volumetric density stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public VolumetricDensity(double value, Unit unit) {
    super(value * unit.toKilogramPerCubicMeter,
          KILOGRAM_PER_CUBIC_METER);
  }

  /**
   * Constructs a VolumetricDensity in kg/m/m/m from the specified volumetric density
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the volumetric density stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public VolumetricDensity(double value, double error, Unit unit) {
    super(value * unit.toKilogramPerCubicMeter,
          error * unit.toKilogramPerCubicMeter,
          KILOGRAM_PER_CUBIC_METER);
  }

  /**
   * Translates a Quantity in kg/m/m/m to a VolumetricDensity.
   *
   * @param   q the quantity in kg/m/m/m
   * @throws  UnitException quantity is not in kg/m/m/m
   */
  public VolumetricDensity(Quantity q) {
    super(q);
    if (!q.unit.equals(KILOGRAM_PER_CUBIC_METER))
      throw new UnitException("Quantity is not in kg/m/m/m but in " +
              q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in kg/m/m/m
   */
  public VolumetricDensity(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(KILOGRAM_PER_CUBIC_METER))
      throw new UnitException("Quantity is not in kg/m/m/m but in " +
              this.unit);
  }

  /**
   * Returns a Quantity corresponding to this VolumetricDensity in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toKilogramPerCubicMeter,
                        this.absoluteError() / unit.toKilogramPerCubicMeter,
                        unit);
  }

  /**
   * Sets the value for this VolumetricDensity stated using the specified
   * measurement Unit.
   *
   * @param   value the VolumetricDensity stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toKilogramPerCubicMeter);
  }

  /**
   * Sets the value and the measurement error for this VolumetricDensity both
   * stated using the specified measurement Unit.
   *
   * @param   value the VolumetricDensity stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toKilogramPerCubicMeter,
        error * unit.toKilogramPerCubicMeter);
  }

  // Specific constructors.
  //


  // Specific methods.
  //
}