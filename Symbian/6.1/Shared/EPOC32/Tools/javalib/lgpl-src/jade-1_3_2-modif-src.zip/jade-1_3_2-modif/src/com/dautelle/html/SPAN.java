/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.html;
import com.dautelle.xml.*;

/**
 * <P> This class represents the SPAN element.</P>
 * <P> SPAN elements, in conjunction with the id and class attributes,
 *    offer a generic mechanism for adding structure to documents.</P>
 * <P> Ref. <a href="http://www.w3.org/TR/REC-html40/struct/global.html#edef-SPAN">
 *     SPAN Specification</a></P>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 */
public class SPAN extends Inline {

  /**
   * Default constructor.
   */
  public SPAN() { super(); }

  /**
   * XML Constructor.
   *
   * @param  attributes "class", "id", "style".
   * @param  content the XML elements (mark-up or character data).
   * @see    com.dautelle.xml.Constructor
   */
  public SPAN(Attributes attributes, Elements content) {
    super(attributes, content);
  }
}