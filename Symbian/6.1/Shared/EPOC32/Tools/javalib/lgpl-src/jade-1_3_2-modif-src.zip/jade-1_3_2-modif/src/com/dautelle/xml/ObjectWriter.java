/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This file was modified by Symbian Ltd. on 21 March 2001.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.xml;
import java.util.Map;
import java.util.Properties;
import java.util.LinkedList;
import java.util.Iterator;
import java.io.OutputStream;
import java.io.IOException;
import java.io.Writer;
import java.io.PrintWriter;
import java.io.OutputStreamWriter;
import java.io.BufferedOutputStream;

/**
 * <p> This class takes a <code>Representable</code> object and formats it to
 *     a stream as XML. Objects written using this facility may be read using
 *     the <code>Constructor</code> class if their XML constructor is consistent
 *     with their XML representation.</p>
 * <p> Namespaces are supported (including default namespace).</p>
 * <p> For example, the following code creates an <code>ObjectWriter</code> using
 *     a default namespace for all classes located within the package
 *     <code>com.dautelle.quantity</code> and the prefixes "math"
 *     for all classes located within the packages <code>com.dautelle.math</code>.</p>
 * <pre>
 *     Properties namespaces = new Properties();
 *     namespaces.setProperty("com.dautelle.quantity", ""); // Default namespace.
 *     namespaces.setProperty("com.dautelle.math", "math");
 *     ObjectWriter ow = new ObjectWriter(namespaces);
 * </pre>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     Representable
 * @see     Constructor
 */
public class ObjectWriter {

  /**
   * Mapping between a java package and its namespace prefix (default
   * no namespace).
   */
  protected final Map namespaces;

  /**
   * Holds the document indent (default two-space indent).
   */
  protected final String indent;

  /**
   * Indicates if the prolog has to be written (default <code>true</code>).
   */
  protected boolean includeProlog;

  protected TagMap tagMap = null;
  public void setTagMap(TagMap aTagMap)
	{
	tagMap = aTagMap;
	}
  public TagMap getTagMap()
	{
	return tagMap;
	}


 /**
  * Creates a default writer.
  *
  * @see   #ObjectWriter(Map, String)
  */
  public ObjectWriter() {
    this(new Properties(), "  ", true);
  }

 /**
  * Creates a writer using the specified namespaces.
  *
  * @param  namespaces maps namespaces to java packages.
  * @see   #ObjectWriter(Map, String, boolean)
  */
  public ObjectWriter(Map namespaces) {
    this(namespaces, "  ", true);
  }

 /*
  * Creates a writer using the specified namespaces and indent.
  *
  * @param  namespaces maps namespaces to java packages.
  * @see   #ObjectWriter(Map, String, boolean)
  */
  public ObjectWriter(Map namespaces, String indent) {
    this(namespaces, indent, true);
  }

 /**
  * Creates a custom writer.
  * The <code>namespaces</code> parameter maps namespaces to java packages
  * For example, if "com.dautelle.xml" (key) is associated to the namespace
  * "xml" (value), then the root element maps the "xml" namespace to the URI
  * "java:com.dautelle.xml" and all classes within the package
  * <code>com.dautelle.xml</code> are prefixed with "xml:".
  * The default namespace is identified by the value "" (empty String).
  *
  * @param  namespaces maps namespaces to java packages.
  * @param  indent the indent <code>String</code>, usually some number of
  *         spaces.
  * @param  includeProlog indicates if a XML prolog has to be written.
  */
  public ObjectWriter(Map namespaces, String indent, boolean includeProlog) {
    this.indent = indent;
    this.namespaces = namespaces;
    this.includeProlog = includeProlog;
  }

  /**
   * Writes the specified <code>Representable</code> to the given output stream
   * in XML format. The characters are written using UTF-8 encoding.
   *
   * @param r <code>Representable</code> object to format.
   * @param out the OutputStream to write to.
   * @throws <code>IOException</code> if there's any problem writing.
   */
  public void write(Representable r, OutputStream out) throws IOException {
    PrintWriter pw = new PrintWriter(
      new OutputStreamWriter(new BufferedOutputStream(out), "UTF8"));
    if (includeProlog) 
		pw.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
    writeElement(r, pw, 0);
	// This would close 'out' as well, but we did not open it,
	// so why should we close it. We might even be dealing with
	// System.out or something. Flushing is something we can reasonably
	// do, I guess.
    //pw.close();
	pw.flush();
  }

  /**
   * Writes the specified <code>Representable</code> to the given Writer
   * in XML format. The characters are written using UTF-16 encoding.
   *
   * @param r <code>Representable</code> object to format.
   * @param writer the Writer to write to.
   * @throws <code>IOException</code> if there's any problem writing.
   */
  public void write(Representable r, Writer writer) throws IOException {
    PrintWriter pw = new PrintWriter(writer);
    if (includeProlog) 
		pw.print("<?xml version=\"1.0\" encoding=\"UTF-16\"?>");
    allowNewLine = true;
    writeElement(r, pw, 0);
	// This would close 'out' as well, but we did not open it,
	// so why should we close it. We might even be dealing with
	// System.out or something. Flushing is something we can reasonably
	// do, I guess.
    //pw.close();
	pw.flush();
  }

  /*
   * Writes the specified element.
   *
   * @param r <code>Representable</code> to output.
   * @param out <code>PrintWriter</code> to write to.
   * @param level the level of nesting (0 for root).
   */
  private void writeElement(Representable r, PrintWriter writer,
                            int level) {
    Attributes attributes = r.getAttributes();
    Representable[] content = r.getContent();

    String elementName = null;

	// Full class identifier, including package.
    String className = r.getClass().getName();
	
	// Changed 21 Mar 2001.
	// (Added potential tag translation.)
	if(tagMap != null)
		elementName = tagMap.classToTag(className);

    if(elementName == null)
		{
	// Name of package, or "" if none.
    int index = className.lastIndexOf(".");
    String packageName = (index < 0) ?  "" : className.substring(0, index);

	// Get namespace for the package.
    String prefix = (String) namespaces.get(packageName);

    if (prefix != null)
		{
		if (prefix.length() ==0) 
			elementName = className.substring(index + 1);
		else 
			elementName = prefix + ":" + className.substring(index + 1);
		}
    else 
		// No name space for package, use the default namespace.
		elementName = className;
		}

    // Start element
    if (allowNewLine) {
      writer.print('\n');
      for (int i=0; i < level; i++) writer.print(indent);
    }
    writer.print("<" + elementName);

    // Writes namespace declaration (if root)
    if (level == 0)
      for (Iterator i = namespaces.keySet().iterator(); i.hasNext();){
        String pkgName = (String) i.next();
        String nsPrefix = (String) namespaces.get(pkgName);
        if (nsPrefix.length() == 0) 
			writer.print(" xmlns=\"java:" + pkgName + "\"");
        else writer.print(" xmlns:" + nsPrefix + "=\"java:" + pkgName + "\"");
      }

    // Writes attributes
    if (attributes != null) {
      for (Iterator i = attributes.keySet().iterator(); i.hasNext();) {
        String key = (String) i.next();
        String value = attributes.get(key);
        writer.print(" " + key + "=\"" + 
					 escapeSpecialCharacters(value) + "\"");
      }
    }

    // Writes content
    if (content == null) {
      writer.print("/>");
    } else {
      writer.print('>');
      allowNewLine = true;
      for (int i = 0; i < content.length; i++) {
        if (content[i] instanceof CharData) {
          writer.print(escapeSpecialCharacters(((CharData) content[i]).
											   toString()));
          allowNewLine = false;
        } else {
          writeElement(content[i], writer, level + 1);
        }
      }
      // End element
      if (allowNewLine) {
        writer.print('\n');
        for (int i=0; i < level; i++) writer.print(indent);
      }
      writer.print("</" + elementName + ">");
      allowNewLine = true;
    }
  }
  private boolean allowNewLine;

  /*
   * Replaces special characters with their appropriate entity reference
   * suitable for XML attributes.
   */
  private String escapeSpecialCharacters(String str) {
    StringBuffer buff = new StringBuffer();
    char[] block = str.toCharArray();
    for (int i=0; i < block.length; i++) {
      switch(block[i]) {
      case '<' :
        buff.append("&lt;");
        break;
      case '>' :
        buff.append("&gt;");
        break;
      case '\'' :
        buff.append("&apos;");
        break;
      case '\"' :
        buff.append("&quot;");
        break;
      case '&' :
        buff.append("&amp;");
        break;
      default :
        buff.append(block[i]);
      }
    }
    return buff.toString();
  }
}
