/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents a distance traveled divided by the time of travel.
 * The measurement Unit for this quantity is the Meter per Second (m/s).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #METER_PER_SECOND
 * @see     Length#METER
 * @see     Duration#SECOND
 */
public final class Velocity extends Quantity {

  /**
   * This class represents Units of Velocity.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toMeterPerSecond;

    private Unit() { // Default Unit (m/s)
      super((Length.METER).divide(Duration.SECOND));
      this.toMeterPerSecond = 1.0;
    }

    /**
     * Constructs a fundamental Unit of Velocity.
     *
     * @param   symbol the symbol of this Unit
     * @param   toMeterPerSecond the multiplier coefficient to convert this
     *          Unit to m/s
     * @see     Velocity#METER_PER_SECOND
     */
    public Unit(String symbol, double toMeterPerSecond) {
      super(symbol);
      this.toMeterPerSecond = toMeterPerSecond;
    }

    /**
     * Constructs a derived Unit of Velocity from a Length Unit divided by
     * a Duration Unit.
     *
     * @param   lengthUnit the Length Unit
     * @param   durationUnit the Duration Unit
     */
    public Unit(Length.Unit lengthUnit, Duration.Unit durationUnit) {
      super(lengthUnit.divide(durationUnit));
      Length length = new Length(1.0, lengthUnit);
      Duration duration = new Duration(1.0, durationUnit);
      this.toMeterPerSecond = length.doubleValue() / duration.doubleValue();
    }
  }

  /**
   * Used to specify Meter per Second Unit.
   * @ see    Length#METER
   * @ see    Duration#SECOND
   */
  public static final Unit METER_PER_SECOND = new Unit();

  /**
   * Equivalent {@link #METER_PER_SECOND}
   */
  public static final Unit METRE_PER_SECOND = METER_PER_SECOND;

  /**
   * Used to specify Centimeter per Minute Unit.
   * @ see    Length#CENTIMETER
   * @ see    Duration#MINUTE
   */
  public static final Unit CENTIMETER_PER_MINUTE =
          new Unit(Length.CENTIMETER, Duration.MINUTE);

  /**
   * Equivalent {@link #CENTIMETER_PER_MINUTE}
   */
  public static final Unit CENTIMETRE_PER_MINUTE = CENTIMETER_PER_MINUTE;

  /**
   * Used to specify Centimeter per Second Unit.
   * @ see    Length#CENTIMETER
   * @ see    Duration#SECOND
   */
  public static final Unit CENTIMETER_PER_SECOND =
          new Unit(Length.CENTIMETER, Duration.SECOND);

  /**
   * Equivalent {@link #CENTIMETER_PER_SECOND}
   */
  public static final Unit CENTIMETRE_PER_SECOND = CENTIMETER_PER_SECOND;

  /**
   * Used to specify Foot per Hour Unit.
   * @ see    Length#FOOT
   * @ see    Duration#HOUR
   */
  public static final Unit FOOT_PER_HOUR =
          new Unit(Length.FOOT, Duration.HOUR);

  /**
   * Used to specify Foot per Minute Unit.
   * @ see    Length#FOOT
   * @ see    Duration#MINUTE
   */
  public static final Unit FOOT_PER_MINUTE =
          new Unit(Length.FOOT, Duration.MINUTE);

  /**
   * Used to specify Foot per Second Unit.
   * @ see    Length#FOOT
   * @ see    Duration#SECOND
   */
  public static final Unit FOOT_PER_SECOND =
          new Unit(Length.FOOT, Duration.SECOND);

  /**
   * Used to specify Inch per Minute Unit.
   * @ see    Length#INCH
   * @ see    Duration#MINUTE
   */
  public static final Unit INCH_PER_MINUTE =
          new Unit(Length.INCH, Duration.MINUTE);

  /**
   * Used to specify Inche per Second Unit.
   * @ see    Length#INCH
   * @ see    Duration#SECOND
   */
  public static final Unit INCH_PER_SECOND =
          new Unit(Length.INCH, Duration.SECOND);

  /**
   * Used to specify Kilometer per Hour Unit.
   * @ see    Length#KILOMETER
   * @ see    Duration#HOUR
   */
  public static final Unit KILOMETER_PER_HOUR =
          new Unit(Length.KILOMETER, Duration.HOUR);

  /**
   * Equivalent {@link #KILOMETER_PER_HOUR}
   */
  public static final Unit KILOMETRE_PER_HOUR = KILOMETER_PER_HOUR;

  /**
   * Used to specify Kilometer per Second Unit.
   * @ see    Length#KILOMETER
   * @ see    Duration#SECOND
   */
  public static final Unit KILOMETER_PER_SECOND =
          new Unit(Length.KILOMETER, Duration.SECOND);

  /**
   * Equivalent {@link #KILOMETER_PER_SECOND}
   */
  public static final Unit KILOMETRE_PER_SECOND = KILOMETER_PER_SECOND;

  /**
   * Used to specify Knot Unit (Nautical Mile per Hour).
   * @ see    Length#NAUTICAL_MILE
   * @ see    Duration#HOUR
   */
  public static final Unit KNOT =
          new Unit(Length.NAUTICAL_MILE, Duration.HOUR);

  /**
   * Used to specify Mach Unit (= Speed of Sound).
   */
  public static final Unit MACH = new Unit("Mach", 331.6);

  /**
   * Used to specify Meter per Hour Unit.
   * @ see    Length#METER
   * @ see    Duration#HOUR
   */
  public static final Unit METER_PER_HOUR =
          new Unit(Length.METER, Duration.HOUR);

  /**
   * Equivalent {@link #METER_PER_HOUR}
   */
  public static final Unit METRE_PER_HOUR = METER_PER_HOUR;

  /**
   * Used to specify Meter per Minute Unit.
   * @ see    Length#METER
   * @ see    Duration#MINUTE
   */
  public static final Unit METER_PER_MINUTE =
          new Unit(Length.METER, Duration.MINUTE);

  /**
   * Equivalent {@link #METER_PER_MINUTE}
   */
  public static final Unit METRE_PER_MINUTE = METER_PER_MINUTE;

  /**
   * Used to specify Mile per Hour Unit.
   * @ see    Length#MILE
   * @ see    Duration#HOUR
   */
  public static final Unit MILE_PER_HOUR =
          new Unit(Length.MILE, Duration.HOUR);

  /**
   * Used to specify Yard per Hour Unit.
   * @ see    Length#YARD
   * @ see    Duration#HOUR
   */
  public static final Unit YARD_PER_HOUR =
          new Unit(Length.YARD, Duration.HOUR);

  /**
   * Used to specify Yard per Minute Unit.
   * @ see    Length#YARD
   * @ see    Duration#MINUTE
   */
  public static final Unit YARD_PER_MINUTE =
          new Unit(Length.YARD, Duration.MINUTE);

  /**
   * Used to specify Yard per Second Unit.
   * @ see    Length#YARD
   * @ see    Duration#SECOND
   */
  public static final Unit YARD_PER_SECOND =
          new Unit(Length.YARD, Duration.SECOND);

  /**
   * Used to specify c Unit (velocity equal to the speed of light).
   */
  public static final Unit C = new Unit("c", 299792458.0);

  /**
   * Constructs a Velocity in m/s from the specified velocity
   * stated using the specified Unit.
   *
   * @param   value the velocity stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public Velocity(double value, Unit unit) {
    super(value * unit.toMeterPerSecond,
          METER_PER_SECOND);
  }

  /**
   * Constructs a Velocity in m/s from the specified velocity
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the velocity stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public Velocity(double value, double error, Unit unit) {
    super(value * unit.toMeterPerSecond,
          error * unit.toMeterPerSecond,
          METER_PER_SECOND);
  }

  /**
   * Translates a Quantity in m/s to a Velocity.
   *
   * @param   q the quantity in m/s
   * @throws  UnitException quantity is not in m/s
   */
  public Velocity(Quantity q) {
    super(q);
    if (!q.unit.equals(METER_PER_SECOND))
      throw new UnitException("Quantity is not in m/s but in " + q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in m/s
   */
  public Velocity(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(METER_PER_SECOND))
      throw new UnitException("Quantity is not in m/s but in " + this.unit);
  }

  /**
   * Returns a Quantity corresponding to this Velocity in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toMeterPerSecond,
                        this.absoluteError() / unit.toMeterPerSecond,
                        unit);
  }

  /**
   * Sets the value for this Velocity stated using the specified
   * measurement Unit.
   *
   * @param   value the Velocity stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toMeterPerSecond);
  }

  /**
   * Sets the value and the measurement error for this Velocity both
   * stated using the specified measurement Unit.
   *
   * @param   value the Velocity stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toMeterPerSecond,
        error * unit.toMeterPerSecond);
  }

  // Specific constructors.
  //


  // Specific methods.
  //
}