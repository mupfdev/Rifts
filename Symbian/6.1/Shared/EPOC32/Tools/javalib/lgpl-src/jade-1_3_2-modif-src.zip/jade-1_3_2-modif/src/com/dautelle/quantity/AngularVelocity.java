/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents the rate of change of angular displacement
 * with respect to time. The measurement Unit for this quantity is the Radian
 * per Second (rad/s).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #RADIAN_PER_SECOND
 * @see     Angle#RADIAN
 * @see     Duration#SECOND
 */
public final class AngularVelocity extends Quantity {

  /**
   * This class represents Units of AngularVelocity.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toRadianPerSecond;

    private Unit() { // Default Unit (rad/s)
      super((Angle.RADIAN).divide(Duration.SECOND));
      this.toRadianPerSecond = 1.0;
    }

    /**
      * Constructs a fundamental Unit of AngularVelocity.
      *
      * @param   symbol the symbol of this Unit
      * @param   toRadianPerSecond the multiplier coefficient to convert this
      *          Unit to rad/s
      * @see     AngularVelocity#RADIAN_PER_SECOND
      */
    public Unit(String symbol, double toRadianPerSecond) {
      super(symbol);
      this.toRadianPerSecond = toRadianPerSecond;
    }

    /**
      * Constructs a derived Unit of AngularVelocity from an Angle Unit divided by
      * a Duration Unit.
      *
      * @param   angleUnit the Length Unit
      * @param   durationUnit the Duration Unit
      */
    public Unit(Angle.Unit angleUnit, Duration.Unit durationUnit) {
      super(angleUnit.divide(durationUnit));
      Angle angle = new Angle(1.0, angleUnit);
      Duration duration = new Duration(1.0, durationUnit);
      this.toRadianPerSecond = angle.doubleValue() / duration.doubleValue();
    }
  }

  /**
   * Used to specify Radian per Second Unit.
   * @ see    Angle#RADIAN
   * @ see    Duration#SECOND
   */
  public static final Unit RADIAN_PER_SECOND = new Unit();

  /**
   * Used to specify Degree per Second Unit.
   * @ see    Angle#DEGREE
   * @ see    Duration#SECOND
   */
  public static final Unit DEGREE_PER_SECOND =
          new Unit(Angle.DEGREE, Duration.SECOND);

  /**
   * Used to specify Revolution per Second Unit.
   * @ see    Angle#REVOLUTION
   * @ see    Duration#SECOND
   */
  public static final Unit REVOLUTION_PER_SECOND =
          new Unit(Angle.REVOLUTION, Duration.SECOND);

  /**
   * Used to specify Revolution per Minute Unit (rpm).
   * @ see    Angle#REVOLUTION
   * @ see    Duration#MINUTE
   */
  public static final Unit REVOLUTION_PER_MINUTE =
          new Unit(Angle.REVOLUTION, Duration.MINUTE);

  /**
   * Used to specify Revolution per Hour Unit.
   * @ see    Angle#REVOLUTION
   * @ see    Duration#HOUR
   */
  public static final Unit REVOLUTION_PER_HOUR =
          new Unit(Angle.REVOLUTION, Duration.HOUR);

  /**
   * Constructs an AngularVelocity in rad/s from the specified angular velocity
   * stated using the specified Unit.
   *
   * @param   value the angular velocity stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public AngularVelocity(double value, Unit unit) {
    super(value * unit.toRadianPerSecond,
          RADIAN_PER_SECOND);
  }

  /**
   * Constructs an AngularVelocity in rad/s from the specified velocity
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the angular velocity stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public AngularVelocity(double value, double error, Unit unit) {
    super(value * unit.toRadianPerSecond,
          error * unit.toRadianPerSecond,
          RADIAN_PER_SECOND);
  }

  /**
   * Translates a Quantity in rad/s to a AngularVelocity.
   *
   * @param   q the quantity in rad/s
   * @throws  UnitException quantity is not in rad/s
   */
  public AngularVelocity(Quantity q) {
    super(q);
    if (!q.unit.equals(RADIAN_PER_SECOND))
      throw new UnitException("Quantity is not in rad/s but in " + q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in rad/s
   */
  public AngularVelocity(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(RADIAN_PER_SECOND))
      throw new UnitException("Quantity is not in rad/s but in " + this.unit);
  }

  /**
   * Returns a Quantity corresponding to this AngularVelocity in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toRadianPerSecond,
                        this.absoluteError() / unit.toRadianPerSecond,
                        unit);
  }

  /**
   * Sets the value for this AngularVelocity stated using the specified
   * measurement Unit.
   *
   * @param   value the AngularVelocity stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toRadianPerSecond);
  }

  /**
   * Sets the value and the measurement error for this AngularVelocity both
   * stated using the specified measurement Unit.
   *
   * @param   value the AngularVelocity stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toRadianPerSecond,
        error * unit.toRadianPerSecond);
  }

  // Specific constructors.
  //


  // Specific methods.
  //
}

