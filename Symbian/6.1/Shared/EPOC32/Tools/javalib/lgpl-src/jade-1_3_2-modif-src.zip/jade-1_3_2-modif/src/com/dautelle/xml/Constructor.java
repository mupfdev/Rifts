/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This file was modified by Symbian Ltd. on 21 March 2001.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.xml;
import org.xml.sax.XMLReader;
import org.xml.sax.InputSource;
import java.io.InputStream;
import java.io.Reader;
import java.io.File;
import java.net.URL;
import java.net.MalformedURLException;

/**
 * <p> This class creates Java objects from their XML representation.</p>
 * <p> In order to benefit from this facility, client classes need
 *     to define a XML constructor.</p>
 * <p> A XML constructor is a Java constructor with two parameters,
 *     one for the attributes and one for the child elements.
 *     When the XML document is parsed, the XML constructor is being called
 *     with the parameters set according to the element's attributes and content.</p>
 * <p> The attributes are simple properties of the object being created
 *    (represented by a String) whereas the content is the list of all nested
 *     elements, which have been created recursively.</p>
 * <p> When character data with non-ignorable whitespace are encountered,
 *     instances of <code>CharData</code> are automatically created and appended
 *     to the content of the enclosing element.</p>
 * <p> Processing instructions are ignored, but namespaces may be used to specify
 *     package names (java addressing scheme).</p>
 * <p> For example, the following XML representation can be used to create
 *     a Matrix composed of Complex elements:</p>
 * <pre>
 * &lt;?xml version='1.0'?&gt;
 * &lt;Matrix xmlns="java:com.dautelle.math" row='2' column='2'&gt;
 *   &lt;Complex real='0.0' imaginary='0.0'/&gt;
 *   &lt;Complex real='0.0' imaginary='1.0'/&gt;
 *   &lt;Complex real='0.0' imaginary='1.0'/&gt;
 *   &lt;Complex real='0.0' imaginary='0.0'/&gt;
 * &lt;/Matrix&gt;
 * </pre>
 * <p>The following code segment creates the Matrix from a file. </p>
 * <pre>
 *     Constructor constructor = new Constructor();
 *     Matrix M = (Matrix) constructor.create(file);
 * </pre>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     LightParser
 * @see     CharData
 */
public class Constructor {

  /**
   * The SAX2 driver to be used.
   */
  protected XMLReader driver;


  protected TagMap tagMap = null;
  public void setTagMap(TagMap aTagMap)
	{
	tagMap = aTagMap;
	}
  public TagMap getTagMap()
	{
	return tagMap;
	}


  /**
   * Creates a default Constructor using the primitive parser
   * <code>com.dautelle.xml.LightParser</code> included with
   * this package.
   *
   * @see    LightParser
   */
  public Constructor() {
      driver = new LightParser();
  }

  /**
   * Creates a Constructor using the specified XMLReader. The XMLReader is the
   * interface that a XML parser's SAX2 driver must implement.
   * For a list of SAX2 parsers goto:  <a href="http://www.megginson.com/SAX/">
   * http://www.megginson.com/SAX/</a>.
   *
   * @param  driverClassName the name of the SAX2 driver implementing the
   *         interface <code>org.xml.sax.XMLReader</code> (i.e.
   *         "org.apache.xerces.parsers.SAXParser").
   * @throws <code>ConstructorException</code> if the driver cannot be loaded.
   * @see    org.xml.sax.XMLReader
   */
  public Constructor(String driverClassName) throws ConstructorException {
    try {
      driver =  (XMLReader)(Class.forName(driverClassName).newInstance());
    } catch (ClassNotFoundException e1) {
      throw new ConstructorException("SAX2 driver class " + driverClassName +
          " not found", e1);
    } catch (IllegalAccessException e2) {
      throw new ConstructorException("SAX2 driver class " + driverClassName +
          " found but cannot be loaded: "+e2.getMessage(), e2);
    } catch (InstantiationException e3) {
      throw new ConstructorException("SAX2 driver class " + driverClassName +
          " loaded but cannot be instantiated (no empty public constructor?)", e3);
    } catch (ClassCastException e4) {
       throw new ConstructorException("SAX2 driver class " + driverClassName +
           " does not implement XMLReader", e4);
    }
  }

  /**
   * Creates an object from its XML representation read from
   * the specified InputStream.
   *
   * @param  in the InputStream containing the XML representation of the
   *         object being created.
   * @return a new object dynamically created.
   * @throws <code>ConstructorException</code> if the object cannot be
   *         created.
   */
  public Object create(InputStream in) throws ConstructorException {
    return create(new InputSource(in));
  }


  /**
   * Creates an object from its XML representation read from
   * the specified Reader.
   *
   * @param  reader the Reader containing the XML representation of the
   *         object being created.
   * @return a new object dynamically created.
   * @throws <code>ConstructorException</code> if the object cannot be
   *         created.
   */
  public Object create(Reader reader) throws ConstructorException {
    return create(new InputSource(reader));
  }

  /**
   * Creates an object from its XML representation read from
   * the specified File.
   *
   * @param  file the File containing the XML representation of the
   *         object being created.
   * @return a new object dynamically created.
   * @throws <code>ConstructorException</code> if the object cannot be
   *         created.
   */
  public Object create(File file) throws ConstructorException {
    try {
      URL url = file.toURL();
      return create(url);
    } catch (MalformedURLException e) {
      throw new ConstructorException("File cannot be accessed", e);
    }
  }

  /**
   * Creates an object from its XML representation read from
   * the specified URL.
   *
   * @param  url the URL containing the XML representation of the
   *         object being created.
   * @return a new object dynamically created.
   * @throws <code>ConstructorException</code> if the object cannot be
   *         created.
   */
  public Object create(URL url) throws ConstructorException {
    String systemID = url.toExternalForm();
    return create(new InputSource(systemID));
  }

  /**
   * Creates an object from its XML representation read from the specified
   * InputSource.
   *
   * @param  xmlSource the InputSource to read from.
   * @return a new object dynamically created.
   * @throws <code>ConstructorException</code> if the object cannot be
   *         created.
   */
  public Object create(InputSource xmlSource) throws ConstructorException {
    try {
      ConstructorHandler handler = new ConstructorHandler(tagMap);
      driver.setContentHandler(handler);
      driver.parse(xmlSource);
      return handler.getRoot();
    } catch (Exception e) {
      throw new ConstructorException("Object cannot be created", e);
    }
  }
}
