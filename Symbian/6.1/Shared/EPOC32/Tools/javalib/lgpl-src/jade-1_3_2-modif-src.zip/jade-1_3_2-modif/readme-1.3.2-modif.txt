
This is JADE Version 1.3.2-modif, which is based on JADE Version
1.3.2, as written by Jean-Marie Dautelle. Fairly minor modifications
have been made. Some files have been removed, i.e everything under
org, plus some changes have been made to the com.dautelle.xml package. 
Changed and added files contain comments stating they have been 
modified/created by Symbian.
(An exception is version.txt, which was also modified by Symbian,
on 7 August 2001.)

This version is meant to be used with the JAXP 1.1 reference
implementation (available from Sun), 
whose JAR files (named jaxp.jar, crimson.jar, xalan.jar)
you should copy to the lib directory before attempting to compile,
into a subdirectory called "jaxp1.1".

 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
