/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;
import java.util.Date;

/**
 * This class represents a period of existence or persistence.
 * The measurement Unit for this quantity is the Second
 * (Syst�me International d'Unit�s).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #SECOND
 */
public final class Duration extends Quantity {

  /**
   * This class represents Units of Duration.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toSecond;

    private Unit() { // Default Unit (Second)
      super("s");
      this.toSecond = 1.0;
    }

    /**
      * Constructs a fundamental Unit of Duration.
      *
      * @param   symbol the symbol of this Unit
      * @param   toSecond the multiplier coefficient to convert this
      *          Unit to Second
      * @see     Duration#SECOND
      */
    public Unit(String symbol, double toSecond) {
      super(symbol);
      this.toSecond = toSecond;
    }
  }

  /**
   * Used to specify Second Unit. It is defined as the duration
   * of 9,192,631,770 cycles of radiation corresponding to the transition
   * between two hyperfine levels of  the ground state of cesium
   * (1967 Standard).
   */
  public static final Unit SECOND = new Unit();

  /**
   * Used to specify Pico-Second Unit.
   */
  public static final Unit PICOSECOND =
          new Unit("PicoSecond", 1e-12); // Exact

  /**
   * Used to specify Nano-Second Unit.
   */
  public static final Unit NANOSECOND = new Unit("NanoSecond", 1e-9);
          // Exact

  /**
   * Used to specify Micro-Second Unit.
   */
  public static final Unit MICROSECOND =
          new Unit("MicroSecond", 1e-6); // Exact

  /**
   * Used to specify Milli-Second Unit.
   */
  public static final Unit MILLISECOND =
          new Unit("MilliSecond", 1e-3); // Exact

          /**
   * Used to specify Minute Unit.
   */
  public static final Unit MINUTE = new Unit("Minute", 60); // Exact

  /**
   * Used to specify Hour Unit.
   */
  public static final Unit HOUR = new Unit("Hour", 3600); // Exact

  /**
   * Used to specify Day Unit.
   */
  public static final Unit DAY = new Unit("Day", 86400); // Exact

  /**
   * Used to specify Week Unit.
   */
  public static final Unit WEEK = new Unit("Week", 604800); // Exact

  /**
   * Used to specify Fortnight Unit (= 2 weeks).
   */
  public static final Unit FORTNIGHT = new Unit("Fortnight", 1209600);
          // Exact

  /**
   * Used to specify Month Unit (= 1 year / 12).
   */
  public static final Unit MONTH = new Unit("Month", 2629746);

  /**
   * Used to specify Year Unit.
   * One year consists of 365 days, 5 hours, 49 minutes, and 12 seconds
   */
  public static final Unit YEAR = new Unit("Year", 31556952);

  /**
   * Used to specify Decade Unit.
   */
  public static final Unit DECADE = new Unit("Decade", 315569520);

  /**
   * Used to specify Century Unit.
   */
  public static final Unit CENTURY = new Unit("Century", 3155695.2e3);

  /**
   * Used to specify Millenium Unit.
   */
  public static final Unit MILLENIUM = new Unit("Millenium", 3155695.2e4);

  /**
   * Used to specify Sidereal Day Unit.
   * A sidereal day is the time required for a complete rotation of the earth
   * in reference to any star or to the vernal equinox at the meridian,
   * equal to 23 hours, 56 minutes, 4.09 seconds.
   */
  public static final Unit DAY_SIDEREAL =
          new Unit("Day_Sidereal", 86164.09);

  /**
   * Used to specify Sidereal Year Unit.
   * A sidereal year is the time required for one complete revolution of the
   * earth about the sun, relative to the fixed stars, or 365 days, 6 hours,
   * 9 minutes, 9.54 seconds.
   */
  public static final Unit YEAR_SIDEREAL =
          new Unit("Year_Sidereal", 31558149.54);

  /**
   * Used to specify Calendar Year Unit (= 365 days).
   */
  public static final Unit YEAR_CALENDAR =
          new Unit("Year_Calendar", 31536000); // Exact

  /**
   * Used to specify Calendar Aeon Unit (= 1e9  years).
   */
  public static final Unit AEON = new Unit("Aeon", 31556952e9);


  /**
   * Constructs a Duration in Second from the specified duration
   * stated using the specified Unit.
   *
   * @param   value the duration stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public Duration(double value, Unit unit) {
    super(value * unit.toSecond,
          SECOND);
  }

  /**
   * Constructs a Duration in Second from the specified duration
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the duration stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public Duration(double value, double error, Unit unit) {
    super(value * unit.toSecond,
          error * unit.toSecond,
          SECOND);
  }

  /**
   * Translates a Quantity in Second to a Duration.
   *
   * @param   q the quantity in Second
   * @throws  UnitException quantity is not in s
   */
  public Duration(Quantity q) {
    super(q);
    if (!q.unit.equals(SECOND))
      throw new UnitException("Quantity is not in s but in " + q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in s
   */
  public Duration(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(SECOND))
      throw new UnitException("Quantity is not in s but in " + this.unit);
  }

  /**
   * Returns a Quantity corresponding to this Duration in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toSecond,
                        this.absoluteError() / unit.toSecond,
                        unit);
  }

  /**
   * Sets the value for this Duration stated using the specified
   * measurement Unit.
   *
   * @param   value the Duration stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toSecond);
  }

  /**
   * Sets the value and the measurement error for this Duration both
   * stated using the specified measurement Unit.
   *
   * @param   value the Duration stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toSecond,
        error * unit.toSecond);
  }

  // Specific constructors.
  //

  /**
   * Constructs a Duration from the ellapsed time between two dates.
   *
   * @param   from the departure date
   * @param   from the arrival date
   * @see     java.util.Date
   */
  public Duration(Date from, Date to) {
    this(from.getTime() - to.getTime(), 1, MILLISECOND);
  }

  // Specific methods.
  //

  /**
   *  Returns the Date after the specified date.&nbsp How long after being
   *  specified by this Duration.
   *
   * @param   date the date of origin
   * @return  date + this
   */
  public Date after(Date date) {
    return new Date(date.getTime() + this.in(MILLISECOND).longValue());
  }

  /**
   *  Returns the Date before the specified date.&nbsp How long before being
   *  specified by this Duration.
   *
   * @param   date the date of origin
   * @return  date - this
   */
  public Date before(Date date) {
    return new Date(date.getTime() - this.in(MILLISECOND).longValue());
  }
}
