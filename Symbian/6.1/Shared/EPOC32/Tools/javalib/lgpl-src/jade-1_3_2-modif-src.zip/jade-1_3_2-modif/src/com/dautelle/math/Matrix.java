/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.math;
import java.util.Vector;
import java.io.Serializable;
import com.dautelle.xml.*;

/**
 * This class represents a rectangular array of <code>Operable</code> objects.
 * It may be used to resolve any system of linear equations involving <code>Operable</code>
 * elements.
 * Non-commutative multiplication is supported and the class itself implements
 * the <code>Operable</code> interface.
 * Consequently, this class may be used to resolve system of linear equations involving
 * matrices (for which the multiplication is not commutative).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     Operable
 */
public class Matrix implements Serializable, Cloneable, Operable, Representable {

  /**
   * The array of Operable object.
    */
  private Operable[][] A;

  /**
   * Row dimension.
    */
  private final int m;

  /**
   * Column dimension.
    */
  private final int n;

  /**
   * Constructs an uninitialized m-by-n Matrix.
   *
   * @param   m the row dimension.
   * @param   n the column dimension.
   */
  public Matrix(int m, int n) {
    this.m = m;
    this.n = n;
    A = new Operable[m][n];
  }

  /**
   * Constructs a m-by-n Matrix filled with the specified element.
   *
   * @param   m the row dimension.
   * @param   n the column dimension.
   * @param   o the element filling the matrix.
   */
  public Matrix(int m, int n, Operable o) {
    this.m = m;
    this.n = n;
    A = new Operable[m][n];
    for (int i = 0; i < m; i++)
      for (int j = 0; j < n; j++)
        A[i][j] = o;
  }

  /**
   * Constructs a m-by-n Matrix filled with the specified diagonal element
   * and the specified non-diagonal element.
   * This constructor may be used to create the Identity matrix
   * (<code>new Matrix(n, n, ONE, ZERO)</code>).
   *
   * @param   m the row dimension.
   * @param   n the column dimension.
   * @param   d the diagonal element.
   * @param   o the non-diagonal element.
   */
  public Matrix(int m, int n, Operable d, Operable o) {
    this.m = m;
    this.n = n;
    A = new Operable[m][n];
    for (int i = 0; i < m; i++)
      for (int j = 0; j < n; j++)
        if (i == j)
          A[i][j] = d;
        else
          A[i][j] = o;
  }

  /**
   * Constructs a Matrix from a 2-dimensional array of Operable objects.
   * The first dimension being the row and the second being the column.
   *
   * @param   A the array of Operable objects.
   * @throws  IllegalArgumentException all rows must have the same length.
   */
  public Matrix(Operable[][] A) {
    this.m = A.length;
    this.n = A[0].length;
    for (int i = 0; i < m; i++)
      if (A[i].length != n)
        throw new IllegalArgumentException("All rows must have the same length.");
    this.A = A;
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'row' and 'columns' attributes of this Matrix.
   * @param  content list of <code>Operable</code> elements.
   * @throws  IllegalArgumentException if the number of elements is not
   *          equal to <code>row * column</code>.
   * @see    com.dautelle.xml.Constructor
   */
  public Matrix(Attributes attributes, Elements content) {
    m = attributes.getInt("row");
    n = attributes.getInt("column");
    if ((m * n) != content.size())
      throw new IllegalArgumentException();
    A = new Operable[m][n];
    Object[] elements = content.toArray();
    for (int i = 0; i < m; i++)
      for (int j = 0; j < n; j++)
        A[i][j] = (Operable) elements[i * n + j];
  }

  /**
   * Get the row dimension of this Matrix.
   *
   * @return  the number of rows.
   */
  public int getRowDimension() {
    return m;
  }

  /**
   * Get the column dimension of this Matrix.
   *
   * @return  the number of columns.
   */
  public int getColumnDimension() {
    return n;
  }

  /**
   * Get a single element from this Matrix.
   *
   * @param   i the row index.
   * @param   j the column index.
   * @return  element read at [i,j].
   * @throws  ArrayIndexOutOfBoundsException <code>i &gt;= getRowDimension() |
   *          j &gt;= getColumnDimension()</code>.
   */
  public Operable get(int i, int j) {
    return this.A[i][j];
  }

  /**
      * Get the 2-dimensional array of this Matrix's elements.
      *
      * @return  elements of this Matrix.
      */
  public Operable[][] getArray() {
    return this.A;
  }

  /**
   * Set a single element of this Matrix.
   *
   * @param   i the row index.
   * @param   j the column index.
   * @param   o the element writen at [i,j].
   * @throws  ArrayIndexOutOfBoundsException <code>i &gt;= getRowDimension() |
   *          j &gt;= getColumnDimension()</code>.
   */
  public void set(int i, int j, Operable o) {
    this.A[i][j] = o;
  }


  /**
   * Compares the specified Object with this Matrix for equality.  Returns
   * <code>true</code> if and only if the specified Object is also a Matrix,
   * both have the same elements.
   *
   * @param   o the Object to be compared for equality with this Matrix.
   * @return  <code>true</code> if the specified Object is equal to this Matrix.
   */
  public boolean equals(Object o) {
    if (o == this)
      return true;
    if (!(o instanceof Matrix))
      return false;
    Matrix M = (Matrix) o;
    if (M.m != this.m || M.n != this.n)
      return false;
    for (int i = 0; i < this.m; i++)
      for (int j = 0; j < this.n; j++)
        if (!this.A[i][j].equals(M.A[i][j]))
          return false;
    return true;
  }

  /**
   * Returns a clone of this Matrix. The copy will contain a new
   * internal data array. The Matrix's elements themself are not cloned.
   *
   * @return  a copy of this Matrix.
   */
  public Object clone() {
    Matrix R = new Matrix(this.m, this.n);
    for (int i = 0; i < this.m; i++)
      System.arraycopy(this.A[i], 0, R.A[i], 0, this.n);
    return R;
  }

  /**
   * Returns the opposite of this Matrix.
   *
   * @return  <code>-this</code>.
   */
  public Matrix minus() {
    Matrix R = new Matrix(this.m, this.n);
    for (int i = 0; i < this.m; i++)
      for (int j = 0; j < this.n; j++)
        R.A[i][j] = this.A[i][j].negate();
    return R;
  }

  /**
   * Returns the sum of this Matrix with the one specified.
   *
   * @param   M the Matrix to be added.
   * @return  <code>this + M</code>.
   * @throws  MatrixDimensionException matrices's dimensions are different.
   */
  public Matrix add(Matrix M) {
    if (M.m != this.m || M.n != this.n)
      throw new MatrixDimensionException();
    Matrix R = new Matrix(M.m, M.n);
    for (int i = 0; i < this.m; i++)
      for (int j = 0; j < this.n; j++)
        R.A[i][j] = this.A[i][j].add(M.A[i][j]);
    return R;
  }

  /**
   * Returns the difference between this Matrix and the one specified.
   *
   * @param   M the Matrix to be subtracted.
   * @return  <code>this - M</code>.
   * @throws  MatrixDimensionException matrices's dimensions are different.
   */
  public Matrix subtract(Matrix M) {
    return this.add(M.minus());
  }

  /**
   * Return the multiplication of this Matrix with the specified factor.
   *
   * @param   k the coefficient multiplier.
   * @return  <code>k * M</code>.
   */
  public Matrix factor(Operable k) {
    Matrix R = new Matrix(this.m, this.n);
    for (int i = 0; i < this.m; i++)
      for (int j = 0; j < this.n; j++)
        R.A[i][j] = this.A[i][j].multiply(k);
    return R;
  }

  /**
   * Returns the product of this Matrix with the one specified.
   *
   * @param   M the Matrix multiplier.
   * @return  <code>this * M</code>.
   * @throws  MatrixDimensionException <code>M.getRowDimension()
   *          != this.getColumnDimension()</code>.
   */
  public Matrix multiply(Matrix M) {
    if (M.m != this.n)
      throw new MatrixDimensionException();
    Matrix R = new Matrix(this.m, M.n);
    for (int i = 0; i < this.m; i++)
      for (int j = 0; j < M.n; j++) {
        Operable s = this.A[i][0].multiply(M.A[0][j]);
        for (int k = 1; k < this.n; k++)
          s = s.add(this.A[i][k].multiply(M.A[k][j]));
        R.A[i][j] = s;
      }
    return R;
  }

  /**
   * Returns this Matrix divided by the one specified.
   *
   * @param   M the Matrix divisor.
   * @return  <code>this.multiply(M.inverse())</code>.
   */
  public Matrix divide(Matrix M) {
    return this.multiply(M.inverse());
  }

  /**
   * Returns the pseudo-inverse of this Matrix. The matrix doesn't need
   * to be square and can be ill-formed. Stability is guaranteed.
   *
   * @return  the pseudo-inverse or this Matrix.
   */
  public Matrix pseudoInverse() {
    return (this.transpose().multiply(this)).inverse(). multiply(
            this.transpose());
  }

  /**
   * Returns the inverse of this square Matrix.
   *
   * @return  the inverse or this Matrix.
   * @throws  MatrixDimensionException matrix is not square.
   */
  public Matrix inverse() {
    Operable inv_det = this.determinant().invert();
    Matrix R = this.adjoint();
    for (int i = 0; i < R.m; i++)
      for (int j = 0; j < R.n; j++)
        R.A[i][j] = inv_det.multiply(R.A[i][j]);
    return R;
  }

  /**
   * Returns the String representation of this Matrix.
   *
   * @return   String representation of this Matrix.
   */
  public String toString() {
    StringBuffer result = new StringBuffer(32);
    result.append("{");
    for (int i = 0; i < m; i++) {
      result.append("{");
      for (int j = 0; j < n; j++) {
        result.append(this.A[i][j].toString());
        if (j != n - 1)
          result.append(", ");
      }
      if (i != m - 1)
        result.append("},\n ");
    }
    result.append("}}");
    return result.toString();
  }

  /**
   * Returns the transpose of this Matrix.
   *
   * @return  <code>A'</code>.
   */
  public Matrix transpose() {
    Matrix R = new Matrix(this.n, this.m);
    for (int i = 0; i < this.m; i++)
      for (int j = 0; j < this.n; j++)
        R.A[j][i] = this.A[i][j];
    return R;
  }

  /**
   * Returns the determinant of this Matrix.
   *
   * @return  determinant of this Matrix
   * @throws  MatrixDimensionException matrix is not square.
   */
  public Operable determinant() {
    if (this.m != this.n)
      throw new MatrixDimensionException("Matrix is not square");
    if (this.m == 1)
      return this.A[0][0];
    Operable d = this.A[0][0].multiply(this.cofactor(0, 0));
    for (int i = 1; i < this.m; i++)
      if (i % 2 == 0)
        d = d.add(this.A[i][0].multiply(this.cofactor(i, 0)));
      else
        d = d.add(this.A[i][0].multiply(this.cofactor(i, 0).negate()));
    return d;
  }

  /**
   * Returns the cofactor of an element in this Matrix. It is the value
   * obtained by evaluating the determinant formed by the elements not in
   * that particular row or column.
   *
   * @param   i the row index.
   * @param   j the column index.
   * @return  the cofactor of <code>this[i,j]</code>.
   * @throws  MatrixDimensionException matrix is not square or its dimension
   *          is less than 2.
   */
  public Operable cofactor(int i, int j) {
    if (this.m != this.n)
      throw new MatrixDimensionException("Matrix is not square");
    if (this.m < 2)
      throw new MatrixDimensionException("Matrix's dimension < 2");
    Matrix M = new Matrix(this.m - 1, this.n - 1);
    int row = 0;
    for (int k1 = 0; k1 < this.m; k1++) {
      if (k1 == i)
        continue;
      int column = 0;
      for (int k2 = 0; k2 < this.n; k2++) {
        if (k2 == j)
          continue;
        M.A[row][column] = this.A[k1][k2];
        column++;
      }
      row++;
    }
    return M.determinant();
  }

  /**
   * Returns the trace of this Matrix.
   *
   * @return  sum of the diagonal elements.
   */
  public Operable trace() {
    Operable t = this.A[0][0];
    for (int i = 0; i < Math.min(m, n); i++) {
      t = t.add(this.A[i][i]);
    }
    return t;
  }

  /**
   * Returns the adjoint of this Matrix. It is obtained by replacing each
   * element in this matrix with its cofactor and applying a + or - sign
   * according (-1)**(i+j), and then finding the transpose of the resulting
   * Matrix.
   *
   * @throws  MatrixDimensionException matrix is not square or its dimension is
   *          less than 2.
   * @return  the adjoint of this Matrix.
   */
  public Matrix adjoint() {
    if (this.m != this.n)
      throw new MatrixDimensionException("Matrix is not square");
    if (this.m < 2)
      throw new MatrixDimensionException("Matrix's dimension < 2");
    Matrix R = new Matrix(this.m, this.n);
    for (int i = 0; i < this.m; i++)
      for (int j = 0; j < this.n; j++)
        if ((i + j) % 2 == 0)
          R.A[i][j] = this.cofactor(i, j);
        else
          R.A[i][j] = this.cofactor(i, j).negate();
    return R.transpose();
  }

  /**
   * Returns the solution X of the equation: A * X =  B.
   * This method introduces less calculation errors than
   * <code>A.inverse().multiply(B)</code>.
   *
   * @param   A the matrix corresponding to the system of linear equations
   *          being solved.
   * @param   B the input vector.
   * @return  the solution X = (1 / A) * B.
   * @throws  MatrixDimensionException matrice is not square.
   */
  public static Matrix solve(Matrix A, Matrix B) {
    return A.adjoint().multiply(B).factor(A.determinant().invert());
  }

  // Implements Operable
  //

  public Operable add(Operable o) {
    return add((Matrix) o);
  }

  public Operable negate() {
    return this.minus();
  }

  public Operable multiply(Operable o) {
    return multiply((Matrix) o);
  }

  public Operable invert() {
    return this.inverse();
  }

  // Implements Representable
  //

  public Attributes getAttributes() {
    Attributes attributes = new Attributes();
    attributes.add("row", m);
    attributes.add("column", n);
    return attributes;
  }

  public Representable[] getContent() {
    Representable[] content = new Representable[m * n];
    for (int i = 0; i < this.m; i++)
      for (int j = 0; j < this.n; j++)
        content[i * n + j] = (Representable) A[i][j];
    return content;
  }
}