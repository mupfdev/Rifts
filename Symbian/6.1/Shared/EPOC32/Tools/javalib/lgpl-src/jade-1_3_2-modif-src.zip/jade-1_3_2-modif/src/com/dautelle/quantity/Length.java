/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents the extent of something along its greatest dimension
 * or the extent of space between two objects or places. The measurement Unit for
 * this quantity is the Meter (Syst�me International d'Unit�s).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #METER
 */
public final class Length extends Quantity {

  /**
   * This class represents Units of Length.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toMeter;

    private Unit() { // Default Unit (Meter)
      super("m");
      this.toMeter = 1.0;
    }

    /**
      * Constructs a fundamental Unit of Length.
      *
      * @param   symbol the symbol of this Unit
      * @param   toMeter the multiplier coefficient to convert this
      *          Unit to Meter
      * @see     Length#METER
      */
    public Unit(String symbol, double toMeter) {
      super(symbol);
      this.toMeter = toMeter;
    }
  }

  /**
   * Used to specify Meter Unit. One Meter was redefined in 1983 as
   * the distance traveled by light in a vacuum in 1/299,792,458 of a Second.
   *
   * @see     Duration
   */
  public static final Unit METER = new Unit();

  /**
   * Equivalent {@link #METER}
   */
  public static final Unit METRE = METER;

  /**
   * Used to specify Foot Unit (1959 Standard).
   */
  public static final Unit FOOT = new Unit("Foot", 0.3048); // Exact.

  /**
   * Used to specify Yard Unit (1959 Standard).
   */
  public static final Unit YARD = new Unit("Yard", 0.9144); // Exact.

  /**
   * Used to specify Inch Unit (1959 Standard).
   */
  public static final Unit INCH = new Unit("Inch", 0.0254); // Exact.

  /**
   * Used to specify Mile Unit.
   */
  public static final Unit MILE = new Unit("Mile", 1609.344); // Exact.

  /**
   * Used to specify Nautical Mile Unit.
   */
  public static final Unit NAUTICAL_MILE =
          new Unit("Nautical_Mile", 1852.0); // Exact.

  /**
   * Used to specify Angstrom Unit.
   */
  public static final Unit ANGSTROM = new Unit("Angstrom", 1e-10); // Exact.

  /**
   * Used to specify Micron Unit (micrometer).
   */
  public static final Unit MICRON = new Unit("Micron", 0.000001); // Exact.

  /**
   * Equivalent {@link #MICRON}
   */
  public static final Unit MICROMETER = MICRON;

  /**
   * Equivalent {@link #MICRON}
   */
  public static final Unit MICROMETRE = MICRON;

  /**
   * Used to specify Centimeter Unit.
   */
  public static final Unit CENTIMETER = new Unit("CentiMeter", 0.01); // Exact.

  /**
   * Equivalent {@link #CENTIMETER}
   */
  public static final Unit CENTIMETRE = CENTIMETER;

  /**
   * Used to specify Decimeter Unit.
   */
  public static final Unit DECIMETER = new Unit("DeciMeter", 0.1); // Exact.

  /**
   * Equivalent {@link #DECIMETER}
   */
  public static final Unit DECIMETRE = DECIMETER;

  /**
   * Used to specify Decameter Unit.
   */
  public static final Unit DECAMETER = new Unit("DecaMeter", 10); // Exact.

  /**
   * Equivalent {@link #DECAMETER}
   */
  public static final Unit DECAMETRE = DECAMETER;

  /**
   * Used to specify Kilometer Unit.
   */
  public static final Unit KILOMETER = new Unit("KiloMeter", 1000); // Exact.

  /**
   * Equivalent {@link #KILOMETER}
   */
  public static final Unit KILOMETRE = KILOMETER;

  /**
   * Used to specify Hand Unit.
   */
  public static final Unit HAND = new Unit("Hand", 0.106); // Exact.

  /**
   * Used to specify Perch Unit.
   */
  public static final Unit PERCH = new Unit("Perch", 5.0292); // Exact.

  /**
   * Equivalent {@link #PERCH}
   */
  public static final Unit ROD = PERCH;

  /**
   * Equivalent {@link #PERCH}
   */
  public static final Unit POLE = PERCH;

  /**
   * Used to specify Furlong Unit.
   */
  public static final Unit FURLONG = new Unit("Furlong", 201.168); // Exact.

  /**
   * Used to specify Fathoms Unit.
   */
  public static final Unit FATHOM = new Unit("Fathom", 1.8288); // Exact.

  /**
   * Used to specify Barleycorn Unit.
   */
  public static final Unit BARLEYCORN =
          new Unit("Barleycorn", 0.008467); // Exact.

          /**
   * Used to specify EMS Unit.
   */
  public static final Unit EMS = new Unit("EMS", 0.0042333);

  /**
   * Used to specify Astronomical Unit.
   */
  public static final Unit ASTRONOMICAL_UNIT =
          new Unit("Astronomical_Unit", 149597870691.0);

  /**
   * Used to specify Light Year Unit.
   */
  public static final Unit LIGHT_YEAR =
          new Unit("Light_Year", 9.460528405e15);

  /**
   * Used to specify Parsec Unit.
   */
  public static final Unit PARSEC = new Unit("Parsec", 30856770e9);

  /**
   * Used to specify Fermi Unit.
   */
  public static final Unit FERMI = new Unit("Fermi", 1e-15); // Exact.

  /**
   * Used to specify Bohr Unit. It is the mean distance between the proton
   * and the electron in an unexcited hydrogen atom.
   */
  public static final Unit BOHR = new Unit("Bohr", 52.918e-12);

  /**
   * Equivalent {@link #FERMI}
   */
  public static final Unit FEMTOMETER = FERMI;

  /**
   * Equivalent {@link #FERMI}
   */
  public static final Unit FEMTOMETRE = FERMI;

  /**
   * Used to specify Millimeter Unit.
   */
  public static final Unit MILLIMETER = new Unit("MilliMeter", 1e-3);
          // Exact.

  /**
   * Equivalent {@link #MILLIMETER}
   */
  public static final Unit MILLIMETRE = MILLIMETER;

  /**
   * Used to specify Nanometer Unit.
   */
  public static final Unit NANOMETER = new Unit("NanoMeter", 1e-9); // Exact.

  /**
   * Equivalent {@link #NANOMETER}
   */
  public static final Unit NANOMETRE = NANOMETER;

  /**
   * Used to specify Millimeter Unit.
   */
  public static final Unit PICOMETER = new Unit("PicoMeter", 1e-12);
          // Exact.

  /**
   * Equivalent {@link #PICOMETER}
   */
  public static final Unit PICOMETRE = PICOMETER;

  /**
   * Used to specify Point Unit. The American point was invented by Nelson
   * Hawks in 1879 and dominates USA publishing. It was standardized by the
   * American Typefounders Association at the value of 0.013837 inches exactly.
   * Computer people have rounded this value to an even 1/72 inch.
   * @see #PIXEL
   */
  public static final Unit POINT = new Unit("Point", INCH.toMeter * 0.013837); // Exact.

  /**
   * Used to specify Pixel Unit. It is the American point rounded to
   * an even 1/72 inch.
   * @see #POINT
   */
  public static final Unit PIXEL = new Unit("Pixel", INCH.toMeter / 72); // Exact.

  /**
   * Equivalent {@link #PIXEL}
   */
  public static final Unit COMPUTER_POINT = PIXEL;

  /**
   * Used to specify Pica Unit. There are exactly 12 Points in a Pica.
   * @see #POINT
   */
  public static final Unit PICA = new Unit("Pica", POINT.toMeter * 12); // Exact.

  /**
   * Used to specify Didot Unit.
   */
  public static final Unit DIDOT = new Unit("Didot",  0.37592e-3); // Exact.

  /**
   * Used to specify Cicero Unit. There are exactly 12 Didots in a Cicero.
   * @see #DIDOT
   */
  public static final Unit CICERO = new Unit("Cicero", DIDOT.toMeter * 12); // Exact.

  /**
   * Constructs a Length in meter from the specified length
   * stated using the specified Unit.
   *
   * @param   value the length stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public Length(double value, Unit unit) {
    super(value * unit.toMeter,
          METER);
  }

  /**
   * Constructs a Length in meter from the specified length and the specified
   * built-in error, both stated using the specified Unit.
   *
   * @param   value the length stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public Length(double value, double error, Unit unit) {
    super(value * unit.toMeter,
          error * unit.toMeter,
          METER);
  }

  /**
   * Translates a Quantity in Meter to a Length.
   *
   * @param   q the quantity in Meter
   * @throws  UnitException quantity is not in m
   */
  public Length(Quantity q) {
    super(q);
    if (!q.unit.equals(METER))
      throw new UnitException("Quantity is not in m but in " + q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in m
   */
  public Length(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(METER))
      throw new UnitException("Quantity is not in m but in " + this.unit);
  }

  /**
   * Returns a Quantity corresponding to this Length in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toMeter,
                        this.absoluteError() / unit.toMeter,
                        unit);
  }

  /**
   * Sets the value for this Length stated using the specified
   * measurement Unit.
   *
   * @param   value the Length stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toMeter);
  }

  /**
   * Sets the value and the measurement error for this Length both
   * stated using the specified measurement Unit.
   *
   * @param   value the Length stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toMeter,
        error * unit.toMeter);
  }

  // Specific constructors.
  //

  /**
   * Constructs a Length from a radius and an angle (arc of a circle).
   * It returns the Length of the arc defined from the specified
   * circle radius and central angle.
   *
   * @param   radius the circle radius
   * @param   theta the central angle
   */
  public Length(Length radius, Angle theta) {
    this(radius.multiply(theta).divide(new Angle(1.0, Angle.RADIAN)));
  }

  // Specific methods.
  //

}