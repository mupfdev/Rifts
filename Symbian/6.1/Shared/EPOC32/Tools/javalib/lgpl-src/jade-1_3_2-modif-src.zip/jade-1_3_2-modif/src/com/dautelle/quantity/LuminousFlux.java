/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents a Luminous Flux.
 * The measurement Unit for this quantity is the Lumen
 * (Candela * Steradian = cd*sr).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #LUMEN
 * @see     LuminousIntensity#CANDELA
 * @see     SolidAngle#STERADIAN
 */
public final class LuminousFlux extends Quantity {

  /**
   * This class represents Units of LuminousFlux.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toLumen;

    private Unit() { // Default Unit (Lumen)
      super(LuminousIntensity.CANDELA.multiply(SolidAngle.STERADIAN));
      this.toLumen = 1.0;
    }

    /**
     * Constructs a fundamental Unit of LuminousFlux.
     *
     * @param   symbol the symbol of this Unit
     * @param   toLumen the multiplier coefficient to convert this
     *          Unit to Lumen
     * @see     #LUMEN
     */
    public Unit(String symbol, double toLumen) {
      super(symbol);
      this.toLumen = toLumen;
    }
  }

  /**
   * Used to specify Lumen Unit. One Lumen is equal to the amount of light
   * given out through a solid angle by a source of one candela intensity
   * radiating equally in all directions.
   */
  public static final Unit LUMEN = new Unit();

  /**
   * Constructs a LuminousFlux in Lumen from the specified luminous flux
   * stated using the specified Unit.
   *
   * @param   value the luminous flux stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public LuminousFlux(double value, Unit unit) {
    super(value * unit.toLumen,
          LUMEN);
  }

  /**
   * Constructs a LuminousFlux in Lumen from the specified luminous flux
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the luminous flux stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public LuminousFlux(double value, double error, Unit unit) {
    super(value * unit.toLumen,
          error * unit.toLumen,
          LUMEN);
  }

  /**
   * Translates a Quantity in Lumen to LuminousFlux.
   *
   * @param   q the quantity in Lumen
   * @throws  UnitException quantity is not in cd*sr
   */
  public LuminousFlux(Quantity q) {
    super(q);
    if (!q.unit.equals(LUMEN))
      throw new UnitException("Quantity is not in cd*sr but in " + q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in cd*sr
   */
  public LuminousFlux(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(LUMEN))
      throw new UnitException("Quantity is not in cd*sr but in " + this.unit);
  }

  /**
   * Returns a Quantity corresponding to this LuminousFlux in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toLumen,
                        this.absoluteError() / unit.toLumen,
                        unit);
  }

  /**
   * Sets the value for this LuminousFlux stated using the specified
   * measurement Unit.
   *
   * @param   value the LuminousFlux stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toLumen);
  }

  /**
   * Sets the value and the measurement error for this LuminousFlux both
   * stated using the specified measurement Unit.
   *
   * @param   value the LuminousFlux stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toLumen,
        error * unit.toLumen);
  }

  // Specific constructors.
  //


  // Specific methods.
  //
}