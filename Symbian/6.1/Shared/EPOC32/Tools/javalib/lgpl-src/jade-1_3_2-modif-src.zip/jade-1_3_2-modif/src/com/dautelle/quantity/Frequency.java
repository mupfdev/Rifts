/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents the number of times a specified phenomenon occurs
 * within a specified interval.
 * The measurement Unit for this quantity is the Hertz (1/s).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #HERTZ
 */
public final class Frequency extends Quantity {

  /**
   * This class represents Units of Frequency.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toHertz;

    private Unit() { // Default Unit (Hertz)
      super(Duration.SECOND.inverse());
      this.toHertz = 1.0;
    }

    /**
      * Constructs a fundamental Unit of Frequency.
      *
      * @param   symbol the symbol of this Unit
      * @param   toHertz the multiplier coefficient to convert this
      *          Unit to Hertz
      * @see     Frequency#HERTZ
      */
    public Unit(String symbol, double toHertz) {
      super(symbol);
      this.toHertz = toHertz;
    }
  }

  /**
   * Used to specify Hertz Unit. A unit of frequency equal
   * to one cycle per second.&nbsp After Heinrich Rudolf Hertz (1857-1894),
   * German physicist who was the first to produce radio waves artificially.
   */
  public static final Unit HERTZ = new Unit();

  /**
   * Used to specify KiloHertz Unit.
   */
  public static final Unit KILOHERTZ = new Unit("KiloHertz", 1e3); // Exact.

  /**
   * Used to specify MegaHertz Unit.
   */
  public static final Unit MEGAHERTZ = new Unit("MegaHertz", 1e6); // Exact.

  /**
   * Used to specify Gigahertz Unit.
   */
  public static final Unit GIGAHERTZ = new Unit("GigaHertz", 1e9); // Exact.

  /**
   * Constructs a Frequency in Hertz from the specified frequency
   * stated using the specified Unit.
   *
   * @param   value the frequency stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public Frequency(double value, Unit unit) {
    super(value * unit.toHertz,
          HERTZ);
  }

  /**
   * Constructs a Frequency in Hertz from the specified frequency
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the frequency stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public Frequency(double value, double error, Unit unit) {
    super(value * unit.toHertz,
          error * unit.toHertz,
          HERTZ);
  }

  /**
   * Translates a Quantity in Hertz to a Frequency.
   *
   * @param   q the quantity in Hertz
   * @throws  UnitException quantity is not in 1/s
   */
  public Frequency(Quantity q) {
    super(q);
    if (!q.unit.equals(HERTZ))
      throw new UnitException("Quantity is not in 1/s but in " + q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in 1/s
   */
  public Frequency(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(HERTZ))
      throw new UnitException("Quantity is not in 1/s but in " + this.unit);
  }

  /**
   * Returns a Quantity corresponding to this Frequency in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toHertz,
                        this.absoluteError() / unit.toHertz,
                        unit);
  }

  /**
   * Sets the value for this Frequency stated using the specified
   * measurement Unit.
   *
   * @param   value the Frequency stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toHertz);
  }

  /**
   * Sets the value and the measurement error for this Frequency both
   * stated using the specified measurement Unit.
   *
   * @param   value the Frequency stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toHertz,
        error * unit.toHertz);
  }

  // Specific constructors.
  //

  // Specific methods.
  //

}


