/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents a dimensionless Quantity.
 * It contains methods for performing basic numeric operations such as
 * the elementary exponential, logarithm  and trigonometric functions.
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     Angle
 */
public final class Dimensionless extends Quantity {

  /**
   * Base of the natural logarithms.
   * @ see    exp()
   * @ see    log()
   */
  public static final Dimensionless E = new Dimensionless(Math.E);

  /**
   * Ratio of the circumference of a circle to its diameter.
   * @ see    Angle
   */
  public static final Dimensionless PI = new Dimensionless(Math.PI);

  /**
   * Constructs a dimensionless from the specified value.
   *
   * @param   value the value of this dimensionless
   */
  public Dimensionless(double value) {
    super(value, com.dautelle.quantity.Unit.DIMENSIONLESS);
  }

  /**
   * Constructs a dimensionless from the specified value and the
   * specified built-in error.
   *
   * @param   value the value of this dimensionless
   * @param   error the absolute error
   */
  public Dimensionless(double value, double error) {
    super(value, error, com.dautelle.quantity.Unit.DIMENSIONLESS);
  }

  /**
   * Translates a dimensionless Quantity to a Dimensionless.
   *
   * @param   q the dimensionless quantity
   * @throws  UnitException quantity is not dimensionless
   */
  public Dimensionless(Quantity q) {
    super(q);
    if (!q.unit.equals(com.dautelle.quantity.Unit.DIMENSIONLESS))
      throw new UnitException("Quantity is not dimensionless but in " +
              q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value' and 'error' attributes
   *         of this Dimensionless.
   * @param  content (none).
   */
  public Dimensionless(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          com.dautelle.quantity.Unit.DIMENSIONLESS);
  }

  // Specific constructors.
  //

  /**
   * Constructs a Dimensionless within the specified interval.
   *
   * @param   unit not used (to avoid signature clash)
   * @param   minimum the minimum value for this dimensionless
   * @param   maximum the maximum value for this dimensionless
   */
  protected Dimensionless(Unit unit, double minimum, double maximum) {
    super(com.dautelle.quantity.Unit.DIMENSIONLESS, minimum, maximum);
  }

  // Specific methods.
  //

  /**
   * Returns the exponential number <i>e</i> raised to the power of this Dimensionless.
   *
   * @return  exp(this)
   */
  public Dimensionless exp() {
    return new Dimensionless(null, Math.exp(this.minimum()),
            Math.exp(this.maximum()));
  }

  /**
   * Returns the natural logarithm (base e) of this Dimensionless.
   *
   * @return  log(this)
   */
  public Dimensionless log() {
    return new Dimensionless(null, Math.log(this.minimum()),
            Math.log(this.maximum()));
  }

  /**
   * Returns this Dimensionless raised to the specified power.
   *
   * @param   e the exponent
   * @return  this**e
   */
  public Dimensionless pow(double e) {
    return new Dimensionless(null, Math.pow(this.minimum(), e),
            Math.pow(this.maximum(), e));
  }

  /**
   * Returns this Dimensionless raised to the power of the specified Dimensionless exponent.
   *
   * @param   d the exponent
   * @return  this**d
   */
  public Dimensionless pow(Dimensionless d) {
    return new Dimensionless(null, Math.pow(this.minimum(), d.minimum()),
            Math.pow(this.maximum(), d.maximum()));
  }

  /**
   * Returns an Angle such as its sine is this Dimensionless.
   *
   * @return  the arc sine of this angle
   */
  public Angle asin() {
    double min = this.minimum();
    double max = this.maximum();
    if (min < -1.0)
      min = -1;
    if (max > 1.0)
      max = 1;
    return new Angle(Math.asin(min), Math.asin(max));
  }

  /**
   * Returns an Angle such as its cosine is this Dimensionless.
   *
   * @return  the arc cosine of this angle
   */
  public Angle acos() {
    double min = this.minimum();
    double max = this.maximum();
    if (min < -1.0)
      min = -1;
    if (max > 1.0)
      max = 1;
    return new Angle(Math.acos(max), Math.acos(min));
  }

  /**
   * Returns an Angle such as its tangent is this Dimensionless.
   *
   * @return  the arc tangent of this angle
   */
  public Angle atan() {
    Dimensionless one = new Dimensionless(1.0);
    return Angle.atan2(this, one);
  }

  /**
   * Overrides <code>getAttributes()</code> from <code>Quantity</code>,
   * there is no need to specify a 'unit' attribute.
   *
   * @return  the attributes of this Dimensionless.
   */
  public Attributes getAttributes() {
    Attributes attributes = new Attributes();
    attributes.add("value", doubleValue());
    attributes.add("error", absoluteError());
    return attributes;
  }


}

