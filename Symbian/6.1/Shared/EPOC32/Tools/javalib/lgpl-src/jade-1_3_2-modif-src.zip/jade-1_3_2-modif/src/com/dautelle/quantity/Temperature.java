/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents the degree of hotness or coldness of a body or
 * an environment. The measurement Unit for this quantity is the Kelvin
 * (Syst�me International d'Unit�s).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #KELVIN
 */
public final class Temperature extends Quantity {

  /**
   * This class represents Units of Temperature.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double zeroKelvin; // Temperature in this Unit corresponding to zero Kelvin
    private final double oneKelvin; // Increment in this Unit corresponding to one Kelvin increment
    // TKelvin = (TthisUnit - zeroKelvin) / oneKelvin;

    private Unit() { // Default Unit (Kelvin)
      super("K");
      this.zeroKelvin = 0.0;
      this.oneKelvin = 1.0;
    }

    /**
     * Constructs a fundamental Unit of Temperature.
     *
     * @param   symbol the symbol of this Unit
     * @param   zeroKelvin the temperature in this Unit corresponding to absolute zero
     * @param   oneKelvin the increment of this Unit corresponding to one Kelvin increment
     * @see     Temperature#KELVIN
     */
    public Unit(String symbol, double zeroKelvin, double oneKelvin) {
      super(symbol);
      this.zeroKelvin = zeroKelvin;
      this.oneKelvin = oneKelvin;
    }
  }

  /**
   * Used to specify degree Kelvin Unit.
   * The kelvin is the 1/273.16th of the thermodynamic temperature of the
   * triple point of water.
   * It is named after the Scottish mathematician and physicist William
   * Thomson 1st Lord Kelvin (1824-1907)
   */
  public static final Unit KELVIN = new Unit();

  /**
   * Used to specify degree Celsius Unit.
   */
  public static final Unit CELSIUS = new Unit("Celsius", -273.15, 1.0); // Exact

  /**
   * Used to specify degree Centigrade Unit
   * (appoximately equal to the degree Celsius).
   */
  public static final Unit CENTIGRADE = CELSIUS;

  /**
   * Used to specify degree Fahrenheit Unit.
   */
  public static final Unit FAHRENHEIT =
          new Unit("Fahrenheit", -459.67, 1.8); // Exact

  /**
   * Used to specify degree Rankine Unit.
   */
  public static final Unit RANKINE = new Unit("Rankine", 0.0, 1.8); // Exact

  /**
   * Used to specify degree R�aumur Unit.
   */
  public static final Unit REAUMUR = new Unit("R�aumur", -218.52, 0.8); // Exact

  /**
   * Constructs a Temperature in Kelvin from the specified value
   * stated using the specified Unit.
   *
   * @param   value the Temperature stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public Temperature(double value, Unit unit) {
    super( (value - unit.zeroKelvin) / unit.oneKelvin,
          KELVIN);
  }

  /**
   * Constructs  a Temperature in Kelvin from the specified value and
   * the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the Temperature stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public Temperature(double value, double error, Unit unit) {
    super( (value - unit.zeroKelvin) / unit.oneKelvin,
          error / unit.oneKelvin,
          KELVIN);
  }

  /**
   * Translates a Quantity in Kelvin to a Temperature.
   *
   * @param   q the quantity in Kelvin
   * @throws  UnitException quantity is not in K
   */
  public Temperature(Quantity q) {
    super(q);
    if (!q.unit.equals(KELVIN))
      throw new UnitException("Quantity is not in K but in " + q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in K
   */
  public Temperature(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(KELVIN))
      throw new UnitException("Quantity is not in K but in " + this.unit);
  }

  /**
   * Returns a Quantity corresponding to this Temperature in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() * unit.oneKelvin + unit.zeroKelvin,
                        this.absoluteError() * unit.oneKelvin ,
                        unit);
  }

  /**
   * Sets the value for this Temperature stated using the specified
   * measurement Unit.
   *
   * @param   value the Temperature stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set( (value - unit.zeroKelvin) / unit.oneKelvin );
  }

  /**
   * Sets the value and the measurement error for this Temperature both
   * stated using the specified measurement Unit.
   *
   * @param   value the Temperature stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set( (value - unit.zeroKelvin) / unit.oneKelvin,
        error / unit.oneKelvin);
  }

  // Specific constructors.
  //


  // Specific methods.
  //
}