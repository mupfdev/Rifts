/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents the number of elementary entities (molecules, for
 * example) of a substance. The measurement Unit for this quantity is the Mole
 * (Syst�me International d'Unit�s).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #MOLE
 */
public final class AmountOfSubstance extends Quantity {

  /**
   * This class represents Units of Amount of Substance.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toMole;

    private Unit() { // Default Unit (Mole)
      super("mol");
      this.toMole = 1.0;
    }

    /**
      * Constructs a fundamental Unit of Amount of Substance.
      *
      * @param   symbol the symbol of this Unit
      * @param   toMole the multiplier coefficient to convert this
      *          Unit to Mole
      * @see     AmountOfSubstance#MOLE
      */
    public Unit(String symbol, double toMole) {
      super(symbol);
      this.toMole = toMole;
    }
  }

  /**
   * Used to specify Mole Unit. The mole is the amount of substance
   * of a system which contains as many elementary entities as there are atoms
   * in 0.012 kilogram of carbon 12.
   */
  public static final Unit MOLE = new Unit();

  /**
   * Used to specify One Unit.
   */
  public static final Unit ONE = new Unit("One", 1.0 / 6.02213674e23);

  /**
   * Constructs an AmountOfSubstance in Mole from the specified amount of
   * substance stated using the specified Unit.
   *
   * @param   value the amount of substance stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public AmountOfSubstance(double value, Unit unit) {
    super(value * unit.toMole,
          MOLE);
  }

  /**
   * Constructs an AmountOfSubstance in Mole from the specified amount of substance
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the amount of substance stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public AmountOfSubstance(double value, double error, Unit unit) {
    super(value * unit.toMole,
          error * unit.toMole,
          MOLE);
  }

  /**
   * Translates a Quantity in Mole to an AmountOfSubstance.
   *
   * @param   q the quantity in Mole
   * @throws  UnitException quantity is not in mol
   */
  public AmountOfSubstance(Quantity q) {
    super(q);
    if (!q.unit.equals(MOLE))
      throw new UnitException("Quantity is not in mol but in " + q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in mol
   */
  public AmountOfSubstance(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(MOLE))
      throw new UnitException("Quantity is not in mol but in " + this.unit);
  }

  /**
   * Returns a Quantity corresponding to this AmountOfSubstance in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toMole,
                        this.absoluteError() / unit.toMole,
                        unit);
  }

  /**
   * Sets the value for this AmountOfSubstance stated using the specified
   * measurement Unit.
   *
   * @param   value the AmountOfSubstance stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toMole);
  }

  /**
   * Sets the value and the measurement error for this AmountOfSubstance both
   * stated using the specified measurement Unit.
   *
   * @param   value the AmountOfSubstance stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toMole,
        error * unit.toMole);
  }

  // Specific constructors.
  //


  // Specific methods.
  //
}

