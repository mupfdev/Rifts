/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.html;
import com.dautelle.xml.*;

/**
 * <P> This class represents a Generic Object element.</P>
 * <P> The OBJECT element is a proposed standards-based element, designed
 *    to augment and replace the current embedding elements IMG, EMBED and APPLET.</P>
 * <P> Unfortunately, to this date, Netscape and Internet Explorer do not
 *     totally support this element
 *     (<A href="http://www.webreference.com/dev/html4nsie/objects.html">read</A>)</P>
 * <P> Ref. <A href="http://www.w3.org/TR/REC-html40/struct/objects.html#edef-OBJECT">
 *     OBJECT Specification</A></P>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 */
public class OBJECT extends Inline {

  /**
   * This attribute may be used to specify the location of an object's
   * implementation via a URI.
   */
  public String classidAttribute;

  /**
   * This attribute may be used to specify the location of the object's data,
   * for instance image data for objects defining images, or more generally,
   * a serialized form of an object which can be used to recreate it.
   */
  public String dataAttribute;

  /**
   * This attribute specifies the content type for the data specified by data.
   */
  public String typeAttribute;

  /**
   * Default constructor.
   */
  public OBJECT() { super(); }

  /**
   * XML Constructor.
   *
   * @param  attributes "classid", "data", "type", "class", "id", "style".
   * @param  content the XML elements (mark-up or character data).
   * @see    com.dautelle.xml.Constructor
   */
  public OBJECT(Attributes attributes, Elements content) {
    super(attributes, content);
    classidAttribute = attributes.get("classid");
    dataAttribute = attributes.get("data");
    typeAttribute = attributes.get("type");
  }

  // Overload parent method (add new attributes).
  public Attributes getAttributes() {
    Attributes attributes = super.getAttributes();
    if (classidAttribute != null) attributes.add("classid", classidAttribute);
    if (dataAttribute != null) attributes.add("data", dataAttribute);
    if (typeAttribute != null) attributes.add("type", typeAttribute);
    return attributes;
  }

}