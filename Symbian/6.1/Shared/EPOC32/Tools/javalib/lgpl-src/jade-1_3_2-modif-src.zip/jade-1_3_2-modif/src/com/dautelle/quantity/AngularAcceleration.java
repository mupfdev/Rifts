/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents The rate of change of angular velocity with respect to time.
 * The measurement Unit for this quantity is the Radian per Square Second (rad/s/s).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #RADIAN_PER_SQUARE_SECOND
 * @see     Angle#RADIAN
 * @see     Duration#SECOND
 */
public final class AngularAcceleration extends Quantity {

  /**
   * This class represents Units of AngularAcceleration.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toRadianPerSquareSecond;

    private Unit() { // Default Unit (rad/s/s)
      super((AngularVelocity.RADIAN_PER_SECOND).divide(Duration.SECOND));
      this.toRadianPerSquareSecond = 1.0;
    }

    /**
      * Constructs a fundamental Unit of AngularAcceleration.
      *
      * @param   symbol the symbol of this Unit
      * @param   toRadianPerSquareSecond the multiplier coefficient to convert this
      *          Unit to rad/s/s
      * @see     AngularAcceleration#RADIAN_PER_SQUARE_SECOND
      */
    public Unit(String symbol, double toRadianPerSquareSecond) {
      super(symbol);
      this.toRadianPerSquareSecond = toRadianPerSquareSecond;
    }

    /**
      * Constructs a derived Unit of AngularAcceleration from an Angle Unit
      * divided twice by a Duration Unit.
      *
      * @param   angleUnit the Angle Unit
      * @param   durationUnit the Duration Unit
      */
    public Unit(Angle.Unit angleUnit, Duration.Unit durationUnit) {
      super(angleUnit.divide(durationUnit).divide(durationUnit));
      Angle angle = new Angle(1.0, angleUnit);
      Duration duration = new Duration(1.0, durationUnit);
      this.toRadianPerSquareSecond = angle.doubleValue() /
              duration.doubleValue() / duration.doubleValue();
    }
  }

  /**
   * Used to specify Radian per Square Second Unit.
   * @ see    Angle#RADIAN
   * @ see    Duration#SECOND
   */
  public static final Unit RADIAN_PER_SQUARE_SECOND = new Unit();

  /**
   * Used to specify Revolution per Square Second Unit.
   * @ see    Angle#REVOLUTION
   * @ see    Duration#SECOND
   */
  public static final Unit REVOLUTION_PER_SQUARE_SECOND =
          new Unit(Angle.REVOLUTION, Duration.SECOND); // Exact.

  /**
   * Constructs an AngularAcceleration in rad/s/s from the specified angular acceleration
   * stated using the specified Unit.
   *
   * @param   value the angular acceleration stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public AngularAcceleration(double value, Unit unit) {
    super(value * unit.toRadianPerSquareSecond,
          RADIAN_PER_SQUARE_SECOND);
  }

  /**
   * Constructs an AngularAcceleration in rad/s/s from the specified angular acceleration
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the angular acceleration stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public AngularAcceleration(double value, double error, Unit unit) {
    super(value * unit.toRadianPerSquareSecond,
          error * unit.toRadianPerSquareSecond,
          RADIAN_PER_SQUARE_SECOND);
  }

  /**
   * Translates a Quantity in rad/s/s to an AngularAcceleration.
   *
   * @param   q the quantity in rad/s/s
   * @throws  UnitException quantity is not in rad/s/s
   */
  public AngularAcceleration(Quantity q) {
    super(q);
    if (!q.unit.equals(RADIAN_PER_SQUARE_SECOND))
      throw new UnitException("Quantity is not in rad/s/s but in " +
              q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in rad/s/s
   */
  public AngularAcceleration(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(RADIAN_PER_SQUARE_SECOND))
      throw new UnitException("Quantity is not in rad/s/s but in " +
              this.unit);
  }

  /**
   * Returns a Quantity corresponding to this AngularAcceleration in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toRadianPerSquareSecond,
                        this.absoluteError() / unit.toRadianPerSquareSecond,
                        unit);
  }

  /**
   * Sets the value for this AngularAcceleration stated using the specified
   * measurement Unit.
   *
   * @param   value the AngularAcceleration stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toRadianPerSquareSecond);
  }

  /**
   * Sets the value and the measurement error for this AngularAcceleration both
   * stated using the specified measurement Unit.
   *
   * @param   value the AngularAcceleration stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toRadianPerSquareSecond,
        error * unit.toRadianPerSquareSecond);
  }

  // Specific constructors.
  //


  // Specific methods.
  //

}

