/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents the angle formed by three or more planes intersecting
 * at a common point. The measurement Unit for this quantity is the Steradian (sr).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #STERADIAN
 */
public final class SolidAngle extends Quantity {

  /**
   * This class represents Units of SolidAngle.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toSteradian;

    private Unit() { // Default Unit (Steradian)
      super("sr");
      this.toSteradian = 1.0;
    }

    /**
     * Constructs a fundamental Unit of SolidAngle.
     *
     * @param   symbol the symbol of this Unit
     * @param   toSteradian the multiplier coefficient to convert this
                Unit to Steradian
     * @see     SolidAngle#STERADIAN
     */
    public Unit(String symbol, double toSteradian) {
      super(symbol);
      this.toSteradian = toSteradian;
    }
  }

  /**
   * Used to specify Steradian Unit. One steradian is the solid angle
   * subtended at the center of a sphere by an area on the surface
   * of the sphere that is equal to the radius squared. The total solid angle
   * of a sphere is 4*Pi steradians.
   */
  public static final Unit STERADIAN = new Unit();

  /**
   * Used to specify Sphere Unit.
   */
  public static final Unit SPHERE = new Unit("Sphere", 4.0 * Math.PI); // Exact.

  /**
   * Constructs an SolidAngle in Steradian from the specified angle
   * stated using the specified Unit.
   *
   * @param   value the angle stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public SolidAngle(double value, Unit unit) {
    super(value * unit.toSteradian,
          STERADIAN);
  }

  /**
   * Constructs a SolidAngle in Steradian from the specified solid angle
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the solid angle stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public SolidAngle(double value, double error, Unit unit) {
    super(value * unit.toSteradian,
          error * unit.toSteradian,
          STERADIAN);
  }

  /**
   * Translates a Quantity in Steradian to a SolidAngle.
   *
   * @param   q the quantity in Steradian
   * @throws  UnitException quantity is not in sr
   */
  public SolidAngle(Quantity q) {
    super(q);
    if (!q.unit.equals(STERADIAN))
      throw new UnitException("Quantity is not in sr but in " + q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in sr
   */
  public SolidAngle(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(STERADIAN))
      throw new UnitException("Quantity is not in sr but in " + this.unit);
  }

  /**
   * Returns a Quantity corresponding to this SolidAngle in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toSteradian,
                        this.absoluteError() / unit.toSteradian,
                        unit);
  }

  /**
   * Sets the value for this SolidAngle stated using the specified
   * measurement Unit.
   *
   * @param   value the SolidAngle stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toSteradian);
  }

  /**
   * Sets the value and the measurement error for this SolidAngle both
   * stated using the specified measurement Unit.
   *
   * @param   value the SolidAngle stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toSteradian,
        error * unit.toSteradian);
  }

  // Specific constructors.
  //


  // Specific methods.
  //

}