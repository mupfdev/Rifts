/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents the figure formed by two lines diverging from a common
 * point. The measurement Unit for this quantity is the Radian (rad).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #RADIAN
 */
public final class Angle extends Quantity {

  /**
   * This class represents Units of Angle.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toRadian;

    private Unit() { // Default Unit (Radian)
      super("rad");
      this.toRadian = 1.0;
    }

    /**
      * Constructs a fundamental Unit of Angle.
      *
      * @param   symbol the symbol of this Unit
      * @param   toRadian the multiplier coefficient to convert this
      *          Unit to Radian
      * @see     Angle#RADIAN
      */
    public Unit(String symbol, double toRadian) {
      super(symbol);
      this.toRadian = toRadian;
    }
  }

  /**
   * Used to specify Radian Unit. One radian is the angle between
   * two radii of a circle such that the length of the arc between
   * them is equal to the radius.
   */
  public static final Unit RADIAN = new Unit();

  /**
   * Used to specify Degree Unit.
   */
  public static final Unit DEGREE =
          new Unit("Degree", Math.PI / 180.0); // Exact.

  /**
   * Used to specify Grade Unit.
   */
  public static final Unit GRADE = new Unit("Grade", Math.PI / 200.0);
          // Exact.

  /**
   * Used to specify Minute Unit (angular).
   */
  public static final Unit MINUTE =
          new Unit("Minute_Angle", Math.PI / 10800.0); // Exact.

  /**
   * Used to specify Second Unit (angular).
   */
  public static final Unit SECOND =
          new Unit("Second_Angle", Math.PI / 648000.0); // Exact.

  /**
   * Used to specify Centrad Unit (= Radian / 100).
   */
  public static final Unit CENTRAD = new Unit("Centrad", 0.01); // Exact.

  /**
   * Used to specify Revolution unit.
   */
  public static final Unit REVOLUTION =
          new Unit("Revolution", 2.0 * Math.PI); // Exact.

  /**
   * Used to specify Mil Unit (= 1 Revolution / 6400).
   */
  public static final Unit MIL =
          new Unit("Mil_Angle", Math.PI / 3200.0); // Exact.

  /**
   * Constructs an Angle in Radian from the specified angle
   * stated using the specified Unit.
   *
   * @param   value the angle stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public Angle(double value, Unit unit) {
    super(value * unit.toRadian,
          RADIAN);
  }

  /**
   * Constructs an Angle in Radian from the specified angle
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the angle stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public Angle(double value, double error, Unit unit) {
    super(value * unit.toRadian,
          error * unit.toRadian,
          RADIAN);
  }

  /**
   * Translates a Quantity in Radian to an Angle.
   *
   * @param   q the quantity in Radian
   * @throws  UnitException quantity is not in rad
   */
  public Angle(Quantity q) {
    super(q);
    if (!q.unit.equals(RADIAN))
      throw new UnitException("Quantity is not in rad but in " + q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in rad
   */
  public Angle(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(RADIAN))
      throw new UnitException("Quantity is not in rad but in " + this.unit);
  }

  /**
   * Returns a Quantity corresponding to this Angle in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toRadian,
                        this.absoluteError() / unit.toRadian,
                        unit);
  }

  /**
   * Sets the value for this Angle stated using the specified
   * measurement Unit.
   *
   * @param   value the Angle stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toRadian);
  }

  /**
   * Sets the value and the measurement error for this Angle both
   * stated using the specified measurement Unit.
   *
   * @param   value the Angle stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toRadian,
        error * unit.toRadian);
  }

  // Specific constructors.
  //

  /**
   * Constructs an Angle whose value in Radian is within the specified interval.
   *
   * @param   minimum the minimum value for this angle
   * @param   maximum the maximum value for this angle
   */
  protected Angle(double minimum, double maximum) {
    super(RADIAN, minimum, maximum);
  }

  /**
   * Converts rectangular coordinates (<code>x</code>,&nbsp;<code>y</code>)
   * to polar (rho,&nbsp;<i>theta</i>).
   * This method computes the phase <i>theta</i> by computing an arc tangent
   * of <code>y/x</code>.
   *
   * @param   y   y coordinate
   * @param   x   x coordinate
   * @return  the <i>theta</i> component of the point
   *          (<i>rho</i>,&nbsp;<i>theta</i>)
   *          in polar coordinates that corresponds to the point
   *          (<i>x</i>,&nbsp;<i>y</i>) in Cartesian coordinates.
   * @throws  UnitException x and y do not use the same units
   */
  public static Angle atan2(Quantity y, Quantity x) {
    if (!x.unit.equals(y.unit))
      throw new UnitException("Quantities x and y do not use the same units");

    if ((x.minimum() < 0.0) && (x.maximum() > 0.0) &&
            (y.minimum() < 0.0) && (y.maximum() > 0.0)) {
      // Encompasses (0,0), all angles are possible
      return new Angle(0, 0.5, Angle.REVOLUTION);
    }

    double a1 = Math.atan2(y.minimum(), x.minimum());
    double a2 = Math.atan2(y.minimum(), x.maximum());
    double a3 = Math.atan2(y.maximum(), x.minimum());
    double a4 = Math.atan2(y.maximum(), x.maximum());

    // Discontinuity at -Pi
    if (x.maximum() <= 0.0) {
      if (a1 < 0)
        a1 += 2 * Math.PI;
      if (a2 < 0)
        a2 += 2 * Math.PI;
      if (a3 < 0)
        a3 += 2 * Math.PI;
      if (a4 < 0)
        a4 += 2 * Math.PI;
    }

    // Search for minimum
    double min = a1;
    if (a2 < min)
      min = a2;
    if (a3 < min)
      min = a3;
    if (a4 < min)
      min = a4;

    // Search for maximum
    double max = a1;
    if (a2 > max)
      max = a2;
    if (a3 > max)
      max = a3;
    if (a4 > max)
      max = a4;

    return new Angle(min, max);
  }

  // Specific methods.
  //

  /**
   * Returns the trigonometric sine of this Angle.
   *
   * @return  the sine of this angle
   */
  public Dimensionless sin() {
    double leftBounded =
            Math.IEEEremainder(this.minimum(), 2.0 * Math.PI); // [-Pi, Pi]

            // Measures distance to the next minima and maxima (periodic function)
            double nextMax = Math.PI / 2 - leftBounded;
    if (nextMax < 0)
      nextMax += 2 * Math.PI;
    double nextMin = - Math.PI / 2 - leftBounded;
    if (nextMin < 0)
      nextMin += 2 * Math.PI;

    double x1 = Math.sin(this.minimum());
    double x2 = Math.sin(this.maximum());

    if (x1 > x2) {
      double tmp = x1;
      x1 = x2;
      x2 = tmp;
    } // Swap

    // Test if quantity passes across a minima or a maxima
    if (this.minimum() + nextMax < this.maximum())
      x2 = 1.0;
    if (this.minimum() + nextMin < this.maximum())
      x1 = -1.0;

    return new Dimensionless(null, x1, x2);
  }

  /**
   * Returns the trigonometric cosine of this Angle.
   *
   * @return  the cosine of this angle
   */
  public Dimensionless cos() {
    return new Angle(this.add(new Angle(0.25, Angle.REVOLUTION))).sin();
  }

  /**
   * Returns the trigonometric tangent of this Angle.
   *
   * @return  the tangent of this angle
   */
  public Dimensionless tan() {
    double leftBounded = Math.IEEEremainder(this.minimum(), Math.PI); // [-Pi/2, Pi/2]

    // Measures distance to the next discontinuity
    double nextDisc = Math.PI / 2 - leftBounded;

    // Test if this quantity passes across a discontinuity
    if (this.minimum() + nextDisc < this.maximum())
      return new Dimensionless(null, Double.NEGATIVE_INFINITY,
              Double.POSITIVE_INFINITY);

    return new Dimensionless(null, Math.tan(this.minimum()),
            Math.tan(this.maximum()));
  }

  /**
   * Returns an Angle in the range of -<i>pi</i> through <i>pi</i>
   * by removing or adding a discrete number of revolution to this angle.
   *
   * @return  an angle in the the range of -<i>pi</i> through <i>pi</i>
   */
  public Angle bounded() {
    double error = this.absoluteError();
    double value = this.doubleValue();
    double boundedValue = Math.IEEEremainder(value, 2.0 * Math.PI);
    return new Angle(boundedValue, error, RADIAN);
  }
}

