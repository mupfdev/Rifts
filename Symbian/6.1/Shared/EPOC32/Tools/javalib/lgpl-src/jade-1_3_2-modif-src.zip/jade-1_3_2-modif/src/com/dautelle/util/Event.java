/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.util;
import java.util.EventObject;

/**
 * This class represents the base class for all application events.
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     Observable
 * @see     Listener
 */
public class Event extends EventObject {

  /**
   * This inner-class represents the identifiers for all application events.
   */
  public static class ID extends Enumerate {

    /**
     * Constructs an event identifier with the specified name.
     *
     * @param name the name of the event.
     */
    public ID(String name) { super(name); }

  }

  /**
   * This ID indicates that the state of the source object has changed.
   */
  public static final ID STATE_CHANGED = new ID("State Changed");

  /**
   * This ID indicates that the source object is going to be deleted.
   * Upon reception of this event, listeners may want to remove any
   * reference to the object (it allows the object to be garbage collected
   * latter).
   */
  public static final ID TO_BE_DELETED = new ID("To Be Deleted");

  /**
   * The identifier for this event.
   */
  protected ID id;

  /**
   * Constructs a base event.
   *
   * @param source the object that originated the event.
   * @param id the type of event.
   */
  public Event(Object source, ID id) {
    super(source);
    this.id = id;
  }

  /**
   * Returns the identifier for this event.
   *
   * @return the event identifier.
   */
  public ID getID() {
    return id;
  }

}