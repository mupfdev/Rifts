/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.math;
import java.io.Serializable;
import com.dautelle.xml.*;

/**
 * This class represents an immutable real number. It implements
 * the interface <code>com.dautelle.math.Operable</code>, therefore allowing
 * the manipulation of real number matrices.
 * <P>Because <code>com.dautelle.math.Real</code> objects are immutable they
 * can be shared.</P>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     Matrix
 */
public class Real extends Number implements Comparable, Operable,
                                            Representable {

  /**
   * The associated double value.
   */
  private final double value;

  /**
   * Constructs a Real number from the specified double value.
   *
   * @param   value the value of this Real number.
   */
  public Real(double value) {
    this.value = value;
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value' attributes of this Real number.
   * @param  content (none).
   * @see    com.dautelle.xml.Constructor
   */
  public Real(Attributes attributes, Elements content) {
    value = attributes.getDouble("value");
  }

  /**
   * Indicates if this Real is infinite.
   *
   * @return  <code>true</code> if this Real is infinite;
   *          <code>false</code> otherwise.
   */
  public boolean isInfinite() {
    return Double.isInfinite(this.value);
  }

  /**
   * Indicates if this Real is not a number.
   *
   * @return  <code>true</code> if this Real is NaN;
   *          <code>false</code> otherwise.
   */
  public boolean isNaN() {
    return Double.isNaN(this.value);
  }

  /**
   * Returns the opposite to this Real.
   *
   * @return  <code>-this</code>.
   */
  public Real minus() {
    return new Real(- this.value);
  }

  /**
   * Returns the sum of this Real with the one specified.
   *
   * @param   r the Real to be added.
   * @return  <code>this + q</code>.
   */
  public Real add(Real r) {
    return new Real(this.value + r.value);
  }

  /**
   * Returns the difference between this Real and the one specified.
   *
   * @param   r the Real to be subtracted.
   * @return  <code>this - r</code>.
   */
  public Real subtract(Real r) {
    return new Real(this.value - r.value);
  }

  /**
   * Returns this Real multiplied by the specified factor.
   *
   * @param   k the factor multiplier.
   * @return  <code>this * k</code>.
   */
  public Real multiply(double k) {
    return new Real(this.value * k);
  }

  /**
   * Returns the product of this Real with the one specified.
   *
   * @param   r the Real multiplier.
   * @return  <code>this * r</code>.
   */
  public Real multiply(Real r) {
    return new Real(this.value * r.value);
  }

  /**
   * Returns the inverse of this Real.
   *
   * @return  <code>1 / this</code>.
   */
  public Real inverse() {
    return new Real(1.0 / this.value);
  }

  /**
   * Returns this Real divided by the specified factor.
   *
   * @param   k the factor divisor.
   * @return  <code>this / k</code>.
   */
  public Real divide(double k) {
    return new Real(this.value / k);
  }

  /**
   * Returns this Real divided by the specified one.
   *
   * @param   r the Real divisor.
   * @return  <code>this / r</code>.
   */
  public Real divide(Real r) {
    return new Real(this.value / r.value);
  }

  /**
   * Returns the absolute value of this Real.
   *
   * @return  <code>abs(this)</code>.
   */
  public Real abs() {
    return new Real(Math.abs(this.value));
  }

  /**
   * Returns the positive square root of this Real.
   *
   * @return  <code>sqrt(this)</code>.
   */
  public Real sqrt() {
    return new Real(Math.sqrt(this.value));
  }

  /**
   * Returns the exponential number <i>e</i> raised to the power of this Real.
   *
   * @return  <code>exp(this)</code>.
   */
  public Real exp() {
    return new Real (Math.exp(this.value));
  }

  /**
   * Returns the natural logarithm (base e) of this Real.
   *
   * @return  <code>log(this)</code>.
   */
  public Real log() {
    return new Real(Math.log(this.value));
  }

  /**
   * Returns this Real raised to the specified power.
   *
   * @param   e the exponent.
   * @return  <code>this**e</code>.
   */
  public Real pow(double e) {
    return new Real(Math.pow(this.value, e));
  }

  /**
   * Returns this Real raised to the power of the specified Real exponent.
   *
   * @param   r the exponent.
   * @return  <code>this**r</code>.
   */
  public Real pow(Real r) {
    return new Real(Math.pow(this.value, r.value));
  }

  /**
   * Returns the decimal String representation of this Real.
   *
   * @return  representation of this Real number.
   */
  public String toString() {
    return String.valueOf(this.value);
  }

  /**
   * Indicates if two Reals are "sufficiently" alike to be considered equal.
   *
   * @param   r the real to compare with.
   * @param   tolerance the maximum difference between them before
   *          they are considered <i>not</i> equal
   * @return  <code>true</code> if they are considered equal;
   *          <code>false</code> otherwise.
   */
  public boolean equals(Real r, double tolerance) {
    return Math.abs(this.value - r.value) <= tolerance;
  }

  /**
   * Compares this Real against the specified Object.
   *
   * @param   o   the object to compare with.
   * @return  <code>true</code> if the objects are the same;
   *          <code>false</code> otherwise.
   */
  public boolean equals(Object o) {
    return (o != null) && (o instanceof Real) &&
            (this.value == ((Real) o).value);
  }

  // Implements java.lang.Number abstract methods.
  //

  /**
   * Returns the value of the specified number as an <code>int</code>.
   * This may involve rounding.
   *
   * @return  the numeric value represented by this Real after conversion
   *          to type <code>int</code>.
   */
  public int intValue() {
    return (int) this.value;
  }

  /**
   * Returns the value of the specified number as a <code>long</code>.
   * This may involve rounding.
   *
   * @return  the numeric value represented by this Real after conversion
   *          to type <code>long</code>.
   */
  public long longValue() {
    return (long) this.value;
  }

  /**
   * Returns the value of the specified number as a <code>float</code>.
   * This may involve rounding.
   *
   * @return  the numeric value represented by this Real after conversion
   *          to type <code>float</code>.
   */
  public float floatValue() {
    return (float) this.value;
  }

  /**
   * Returns the value of the specified number as a <code>double</code>.
   * This may involve rounding.
   *
   * @return  the numeric value represented by this Real after conversion
   *          to type <code>double</code>.
   */
  public double doubleValue() {
    return this.value;
  }

  // Implements Comparable
  //

  /**
   * Compares two Real numerically. Inherits its behavior from
   * <code>java.lang.Double.compareTo(Double)</code>
   *
   * @param   r the Real to compare with.
   * @return  -1, 0 or 1 as this Real is numerically less than, equal
   *          to, or greater than <code>r</code>.
   */
  public int compareTo(Real r) {
    return new Double(this.value).compareTo(new Double(r.value));
  }

  public int compareTo(Object o) {
    return this.compareTo((Real) o);
  }

  // Implements Operable
  //

  public Operable add(Operable o) {
    return this.add((Real) o);
  }

  public Operable negate() {
    return this.minus();
  }

  public Operable multiply(Operable o) {
    return this.multiply((Real) o);
  }

  public Operable invert() {
    return this.inverse();
  }

  // Implements Representable
  //

  public Attributes getAttributes() {
    Attributes attributes = new Attributes();
    attributes.add("value", value);
    return attributes;
  }

  public Representable[] getContent() {
    return null;
  }

}