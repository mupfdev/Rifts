/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents the amount of energy deposited per unit of
 * mass. The measurement Unit for this quantity is the Gray
 * (Joule / Kilogram = m*m/s/s).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #GRAY
 * @see     Energy#JOULE
 * @see     Mass#KILOGRAM
 */
public final class RadiationDoseAbsorbed extends Quantity {

  /**
   * This class represents Units of RadiationDoseAbsorbed.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toGray;

    private Unit() { // Default Unit (Gray)
      super(Energy.JOULE.divide(Mass.KILOGRAM));
      this.toGray = 1.0;
    }

    /**
     * Constructs a fundamental Unit of RadiationDoseAbsorbed.
     *
     * @param   symbol the symbol of this Unit
     * @param   toGray the multiplier coefficient to convert this
     *          Unit to Gray
     * @see     #GRAY
     */
    public Unit(String symbol, double toGray) {
      super(symbol);
      this.toGray = toGray;
    }
  }

  /**
   * Used to specify Gray Unit. One gray is equal to the dose of one joule
   * of energy absorbed per one kilogram of matter.
   * It is named after the British physician L. H. Gray (1905-1965).
   */
  public static final Unit GRAY = new Unit();

  /**
   * Used to specify Rad Unit.
   */
  public static final Unit RAD = new Unit("Rad", 0.01); // Exact.

  /**
   * Constructs a RadiationDoseAbsorbed in Gray from the specified radiation dose
   * stated using the specified Unit.
   *
   * @param   value the radiation dose stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public RadiationDoseAbsorbed(double value, Unit unit) {
    super(value * unit.toGray,
          GRAY);
  }

  /**
   * Constructs a RadiationDoseAbsorbed in Gray from the specified radiation dose
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the radiation dose stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public RadiationDoseAbsorbed(double value, double error, Unit unit) {
    super(value * unit.toGray,
          error * unit.toGray,
          GRAY);
  }

  /**
   * Translates a Quantity in Gray to a RadiationDoseAbsorbed.
   *
   * @param   q the quantity in Gray
   * @throws  UnitException quantity is not in m*m/s/s
   */
  public RadiationDoseAbsorbed(Quantity q) {
    super(q);
    if (!q.unit.equals(GRAY))
      throw new UnitException("Quantity is not in m*m/s/s but in " +
              q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in m*m/s/s
   */
  public RadiationDoseAbsorbed(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(GRAY))
      throw new UnitException("Quantity is not in m*m/s/s but in " +
              this.unit);
  }

  /**
   * Returns a Quantity corresponding to this RadiationDoseAbsorbed in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toGray,
                        this.absoluteError() / unit.toGray,
                        unit);
  }

  /**
   * Sets the value for this RadiationDoseAbsorbed stated using the specified
   * measurement Unit.
   *
   * @param   value the RadiationDoseAbsorbed stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toGray);
  }

  /**
   * Sets the value and the measurement error for this RadiationDoseAbsorbed both
   * stated using the specified measurement Unit.
   *
   * @param   value the RadiationDoseAbsorbed stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toGray,
        error * unit.toGray);
  }

  // Specific constructors.
  //


  // Specific methods.
  //
}