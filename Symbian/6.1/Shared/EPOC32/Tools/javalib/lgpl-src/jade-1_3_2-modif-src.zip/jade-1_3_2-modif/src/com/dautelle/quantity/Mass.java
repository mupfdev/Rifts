/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents the measure of the quantity of matter that a body
 * or an object contains. The mass of the body is not dependent on gravity
 * and therefore is different from but proportional to its weight.
 * The measurement Unit for this quantity is the Kilogram
 * (Syst�me International d'Unit�s).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #KILOGRAM
 */
public final class Mass extends Quantity {

  /**
   * This class represents Units of Mass.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toKilogram;

    private Unit() { // Default Unit (Kilogram)
      super("kg");
      this.toKilogram = 1.0;
    }

    /**
      * Constructs a fundamental Unit of Mass.
      *
      * @param   symbol the symbol of this Unit
      * @param   toKilogram the multiplier coefficient to convert this
      *          Unit to Kilogram
      * @see     Mass#KILOGRAM
      */
    public Unit(String symbol, double toKilogram) {
      super(symbol);
      this.toKilogram = toKilogram;
    }
  }

  /**
   * Used to specify Kilogram Unit. The kilogram is equal to the mass
   * of an international prototype in the form of a platinum-iridium
   * cylinder kept at Sevres in France
   */
  public static final Unit KILOGRAM = new Unit();

  /**
   * Used to specify Atomic Mass Unit.
   */
  public static final Unit ATOMIC_MASS = new Unit("Atomic_Mass",
          new AmountOfSubstance(0.001 ,
          AmountOfSubstance.ONE).doubleValue()); // Exact.

  /**
   * Equivalent {@link #ATOMIC_MASS}
   */
  public static final Unit DALTON = ATOMIC_MASS;

  /**
   * Used to specify Electron Mass Unit.
   */
  public static final Unit ELECTRON_MASS =
          new Unit("Electron_Mass", 0.910940e-30);

  /**
   * Used to specify Carat Unit.
   */
  public static final Unit CARAT = new Unit("Carat", 0.0002); // Exact.

  /**
   * Used to specify Grain Unit.
   */
  public static final Unit GRAIN = new Unit("Grain", 0.00006479891); // Exact.

  /**
   * Used to specify Gram Unit.
   */
  public static final Unit GRAM = new Unit("Gram", 0.001); // Exact.

  /**
   * Used to specify Milligram Unit.
   */
  public static final Unit MILLIGRAM = new Unit("Milligram", 1e-6); // Exact.

  /**
   * Used to specify Hundredweight (=100 pounds) U.S. Unit.
   */
  public static final Unit HUNDREDWEIGHT_US =
          new Unit("Hundredweight_US", 45.359237); // Exact.

  /**
   * Used to specify Hundredweight (=112 pounds) U.K. Unit.
   */
  public static final Unit HUNDREDWEIGHT_UK =
          new Unit("Hundredweight_UK", 50.80234544); // Exact.

  /**
   * Used to specify Quintal (metric) Unit.
   */
  public static final Unit QUINTAL = new Unit("Quintal", 100.0); // Exact.

  /**
   * Used to specify Ounce (avoirdupois) Unit.
   */
  public static final Unit OUNCE = new Unit("Ounce", 0.028349523125); // Exact.

  /**
   * Used to specify Ounce Troy (apothecary) Unit.
   */
  public static final Unit OUNCE_TROY =
          new Unit("Ounce_Troy", 0.0311034768); // Exact.

  /**
   * Used to specify Pound Unit.
   */
  public static final Unit POUND = new Unit("Pound", 0.45359237); // Exact.

  /**
   * Used to specify Slug Unit.
   */
  public static final Unit SLUG = new Unit("Slug", 14.593903); // Exact.

  /**
   * Used to specify Stone Unit.
   */
  public static final Unit STONE = new Unit("Stone", 6.35029318); // Exact.

  /**
   * Used to specify Ton U.S Unit (=2000 pounds, short ton).
   */
  public static final Unit TON_US = new Unit("Ton_US", 907.18474); // Exact.

  /**
   * Used to specify Ton U.K. Unit (=2240 pounds, long ton).
   */
  public static final Unit TON_UK = new Unit("Ton_UK", 1016.0469088); // Exact.

  /**
   * Used to specify Tonne (metric) Unit.
   */
  public static final Unit TONNE = new Unit("Tonne", 1000.0); // Exact.

  /**
   * Used to specify Jin Unit (China).
   */
  public static final Unit JIN = new Unit("Jin", 0.5); // Exact.

  /**
   * Used to specify Kin Unit (Japon).
   */
  public static final Unit KIN = new Unit("Kin", 0.6);

  /**
   * Used to specify Jupiter Unit. It is equal to the mass of the planet Jupiter.
   */
  public static final Unit JUPITER = new Unit("Jupiter", 1.899e24);

  /**
   * Constructs a Mass in Kilogram from the specified mass
   * stated using the specified Unit.
   *
   * @param   value the mass stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public Mass(double value, Unit unit) {
    super(value * unit.toKilogram,
          KILOGRAM);
  }

  /**
   * Constructs a Mass in Kilogram from the specified mass
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the mass stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public Mass(double value, double error, Unit unit) {
    super(value * unit.toKilogram,
          error * unit.toKilogram,
          KILOGRAM);
  }

  /**
   * Translates a Quantity in Kilogram to a Mass.
   *
   * @param   q the quantity in Kilogram
   * @throws  UnitException quantity is not in kg
   */
  public Mass(Quantity q) {
    super(q);
    if (!q.unit.equals(KILOGRAM))
      throw new UnitException("Quantity is not in kg but in " + q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in kg
   */
  public Mass(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(KILOGRAM))
      throw new UnitException("Quantity is not in kg but in " + this.unit);
  }

  /**
   * Returns a Quantity corresponding to this Mass in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toKilogram,
                        this.absoluteError() / unit.toKilogram,
                        unit);
  }

  /**
   * Sets the value for this Mass stated using the specified
   * measurement Unit.
   *
   * @param   value the Mass stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toKilogram);
  }

  /**
   * Sets the value and the measurement error for this Mass both
   * stated using the specified measurement Unit.
   *
   * @param   value the Mass stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toKilogram,
        error * unit.toKilogram);
  }

  // Specific constructors.
  //

  // Specific methods.
  //
}