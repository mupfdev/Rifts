/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents the luminous flux density per solid angle as measured
 * in a given direction relative to the emitting source.
 * The measurement Unit for this quantity is the Candela
 * (Syst�me International d'Unit�s).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #CANDELA
 */
public final class LuminousIntensity extends Quantity {

  /**
   * This class represents Units of LuminousIntensity.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toCandela;

    private Unit() { // Default Unit (Candela)
      super("cd");
      this.toCandela = 1.0;
    }

    /**
     * Constructs a fundamental Unit of LuminousIntensity.
     *
     * @param   symbol the symbol of this Unit
     * @param   toCandela the multiplier coefficient to convert this
     *          Unit to Candela
     * @see     LuminousIntensity#CANDELA
     */
    public Unit(String symbol, double toCandela) {
      super(symbol);
      this.toCandela = toCandela;
    }
  }

  /**
   * Used to specify Candela Unit.&nbsp The Candela is the luminous intensity,
   * in a given direction, of a source that emits monochromatic radiation
   * of frequency 540 � 1012 hertz and that has a radiant intensity in that
   * direction of 1/683 watt per steradian
   *
   * @ see    SolidAngle#STERADIAN
   */
  public static final Unit CANDELA = new Unit();

  /**
   * Equivalent {@link #CANDELA}
   */
  public static final Unit LUMEN = CANDELA;

  /**
   * Constructs a LuminousIntensity in Candela from the specified luminous
   * intensity stated using the specified Unit.
   *
   * @param   value the luminous intensity stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public LuminousIntensity(double value, Unit unit) {
    super(value * unit.toCandela,
          CANDELA);
  }

  /**
   * Constructs a LuminousIntensity in Candela from the specified luminous intensity
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the luminous intensity stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public LuminousIntensity(double value, double error, Unit unit) {
    super(value * unit.toCandela,
          error * unit.toCandela,
          CANDELA);
  }

  /**
   * Translates a Quantity in Candela to a LuminousIntensity.
   *
   * @param   q the quantity in Candela
   * @throws  UnitException quantity is not in cd
   */
  public LuminousIntensity(Quantity q) {
    super(q);
    if (!q.unit.equals(CANDELA))
      throw new UnitException("Quantity is not in cd but in " + q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in cd
   */
  public LuminousIntensity(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(CANDELA))
      throw new UnitException("Quantity is not in cd but in " + this.unit);
  }

  /**
   * Returns a Quantity corresponding to this LuminousIntensity in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toCandela,
                        this.absoluteError() / unit.toCandela,
                        unit);
  }

  /**
   * Sets the value for this LuminousIntensity stated using the specified
   * measurement Unit.
   *
   * @param   value the LuminousIntensity stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toCandela);
  }

  /**
   * Sets the value and the measurement error for this LuminousIntensity both
   * stated using the specified measurement Unit.
   *
   * @param   value the LuminousIntensity stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toCandela,
        error * unit.toCandela);
  }

  // Specific constructors.
  //

  // Specific methods.
  //
}