/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.xml;

/**
 * This class represents the text that is not markup and constitutes
 * the character data of a XML document.
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 */
public class CharData implements Representable {

  /**
   * The character content of the CharData
   */
  private final StringBuffer content;

  /**
   * Default constructor.
   */
  public CharData() {
    content = new StringBuffer();
  }

  /**
   * Creates a CharData from the specified String.
   *
   * @param str the data string.
   */
  public CharData(String str) {
    content = new StringBuffer(str);
  }

  /**
   * Creates a CharData from the specified characters.
   *
   * @param ch the characters from the XML document.
   * @param start the start position in the array.
   * @param length the number of characters to read from the array.
   */
  public CharData(char ch[], int start, int length) {
    content = new StringBuffer(new String(ch, start, length));
  }

 /**
  * Appends the specified characters to this CharData.
  *
  * @param ch the characters from the XML document.
  * @param start the start position in the array.
  * @param length the number of characters to read from the array.
   */
  public void append(char ch[], int start, int length) {
    content.append(new String(ch, start, length));
  }

 /**
  * Appends the specified String to this CharData.
  *
  * @param s the string to append.
   */
  public void append(String str) {
    content.append(str);
  }

 /**
  * Appends the specified character to this CharData.
  *
  * @param c the character to append.
   */
  public void append(char c) {
    content.append(c);
  }

 /**
  * Clears the content of this CharData.
  */
  public void clear() {
    content.setLength(0);
  }

 /**
  * Returns the string representation of this CharData.
  *
  * @return string representation of this CharData.
  */
  public String toString() {
    return content.toString();
  }

 /**
  * Returns the number of characters composing this CharData.
  *
  * @return the length.
   */
  public int length() {
    return content.length();
  }

 /**
  * Indicates if this CharData contains at least one character which is not
  * a whitespace nor a control character.
  *
  * @return  <code>true</code> if this CharData contains only whitespaces or
  *                            control characters.
  *          <code>false</code> otherwise.
   */
  public boolean isEmpty() {
    return content.toString().trim().length() == 0;
  }

  // Implements Representable
  //

  public Attributes getAttributes() {
    return null;
  }

  public Representable[] getContent() {
    return null;
  }

}