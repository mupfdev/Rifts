/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://dautelle.com/jade
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents the rate of change of velocity with respect to time.
 * The measurement Unit for this quantity is the Meter per Square Second
 * (m/s/s).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #METER_PER_SQUARE_SECOND
 * @see     Length#METER
 * @see     Duration#SECOND
 */
public final class Acceleration extends Quantity {

  /**
   * This class represents Units of Acceleration.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toMeterPerSquareSecond;

    private Unit() { // Default Unit (m/s/s)
      super((Velocity.METER_PER_SECOND).divide(Duration.SECOND));
      this.toMeterPerSquareSecond = 1.0;
    }

    /**
     * Constructs a fundamental Unit of Acceleration.
     *
     * @param   symbol the symbol of this Unit
     * @param   toMeterPerSquareSecond the multiplier coefficient to convert
     *          this Unit to m/s/s
     * @see     Acceleration#METER_PER_SQUARE_SECOND
     */
    public Unit(String symbol, double toMeterPerSquareSecond) {
      super(symbol);
      this.toMeterPerSquareSecond = toMeterPerSquareSecond;
    }

    /**
     * Constructs a derived Unit of Acceleration from a Length Unit
     * divided twice by a Duration Unit.
     *
     * @param   lengthUnit the Length Unit
     * @param   durationUnit the Duration Unit
     */
    public Unit(Length.Unit lengthUnit, Duration.Unit durationUnit) {
      super(lengthUnit.divide(durationUnit).divide(durationUnit));
      Length length = new Length(1.0, lengthUnit);
      Duration duration = new Duration(1.0, durationUnit);
      this.toMeterPerSquareSecond = length.doubleValue() /
              duration.doubleValue() / duration.doubleValue();
    }
  }

  /**
   * Used to specify Meter per Square Second Unit.
   * @ see    Length#METER
   * @ see    Duration#SECOND
   */
  public static final Unit METER_PER_SQUARE_SECOND = new Unit();

  /**
   * Equivalent {@link #METER_PER_SQUARE_SECOND}
   */
  public static final Unit METRE_PER_SQUARE_SECOND = METER_PER_SQUARE_SECOND;

  /**
   * Used to specify g Unit. It is the acceleration caused by gravity at the
   * earth's surface.
   */
  public static final Unit G = new Unit("g", 9.80665); // Exact.

  /**
   * Used to specify Galileo Unit. One Galileo is an acceleration
   * of 1 centimeter per second per second.
   */
  public static final Unit GALILEO =
          new Unit(Length.CENTIMETER, Duration.SECOND); // Exact.

  /**
   * Constructs an Acceleration in m/s/s from the specified acceleration
   * stated using the specified Unit.
   *
   * @param   value the acceleration stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public Acceleration(double value, Unit unit) {
    super(value * unit.toMeterPerSquareSecond, METER_PER_SQUARE_SECOND);
  }

  /**
   * Constructs an Acceleration in m/s/s from the specified acceleration
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the acceleration stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public Acceleration(double value, double error, Unit unit) {
    super(value * unit.toMeterPerSquareSecond,
          error * unit.toMeterPerSquareSecond,
          METER_PER_SQUARE_SECOND);
  }

  /**
   * Translates a Quantity in m/s/s to an Acceleration.
   *
   * @param   q the quantity in m/s/s
   * @throws  UnitException quantity is not in m/s/s
   */
  public Acceleration(Quantity q) {
    super(q);
    if (!q.unit.equals(METER_PER_SQUARE_SECOND))
      throw new UnitException("Quantity is not in m/s/s but in " + q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in m/s/s
   */
  public Acceleration(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(METER_PER_SQUARE_SECOND))
      throw new UnitException("Quantity is not in m/s/s but in " + this.unit);
  }

  /**
   * Returns a Quantity corresponding to this Acceleration in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toMeterPerSquareSecond,
                        this.absoluteError() / unit.toMeterPerSquareSecond,
                        unit);
  }

  /**
   * Sets the value for this Acceleration stated using the specified
   * measurement Unit.
   *
   * @param   value the acceleration stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toMeterPerSquareSecond);
  }

  /**
   * Sets the value and the measurement error for this Acceleration both
   * stated using the specified measurement Unit.
   *
   * @param   value the acceleration stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toMeterPerSquareSecond,
        error * unit.toMeterPerSquareSecond);
  }

  // Specific constructors.
  //


  // Specific methods.
  //

}

