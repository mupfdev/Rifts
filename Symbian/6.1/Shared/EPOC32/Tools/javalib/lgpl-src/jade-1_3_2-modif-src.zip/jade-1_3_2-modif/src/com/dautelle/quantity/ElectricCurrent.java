/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents the amount of electric charge flowing past
 * a specified circuit point per unit time. The measurement Unit for
 * this quantity is the Ampere (Syst�me International d'Unit�s).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #AMPERE
 */
public final class ElectricCurrent extends Quantity {

  /**
   * This class represents Units of Electric Current.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toAmpere;

    private Unit() { // Default Unit (Ampere)
      super("A");
      this.toAmpere = 1.0;
    }

    /**
      * Constructs a fundamental Unit of Electric Current.
      *
      * @param   symbol the symbol of this Unit
      * @param   toAmpere the multiplier coefficient to convert this
      *          Unit to Ampere
      * @see     ElectricCurrent#AMPERE
      */
    public Unit(String symbol, double toAmpere) {
      super(symbol);
      this.toAmpere = toAmpere;
    }
  }

  /**
   * Used to specify Ampere Unit. The Ampere is that constant current
   * which, if maintained in two straight parallel conductors of infinite
   * length, of negligible circular cross-section, and placed 1 metre apart
   * in vacuum, would produce between these conductors a force equal
   * to 2 � 10-7 newton per metre of length.
   * It is named after the French physicist Andre Ampere (1775-1836).
   *
   * @ see    Length#METER
   */
  public static final Unit AMPERE = new Unit();

  /**
   * Used to specify MilliAmpere Unit.
   * @ see    #AMPERE
   */
  public static final Unit MILLIAMPERE =
          new Unit("MilliAmpere", 1e-3); // Exact.

  /**
   * Used to specify MicroAmpere Unit.
   * @ see    #AMPERE
   */
  public static final Unit MICROAMPERE =
          new Unit("MicroAmpere", 1e-6); // Exact.

  /**
   * Used to specify NanoAmpere Unit.
   * @ see    #AMPERE
   */
  public static final Unit NANOAMPERE = new Unit("NanoAmpere", 1e-9);
          // Exact.

  /**
   * Used to specify Abampere Unit (conversion).
   * It is the centimeter-gram-second electromagnetic unit of current equal
   * to ten amperes.
   */
  public static final Unit ABAMPERE = new Unit("Abampere", 10); // Exact

  /**
   * Used to specify Gilbert Unit (conversion).
   * It is the centimeter-gram-second electromagnetic Unit
   * of magnetomotive force, equal to 10/4Pi ampere-turn.
   */
  public static final Unit GILBERT =
          new Unit("Gilbert", 10.0 / (4.0 * Math.PI)); // Exact

  /**
   * Constructs an ElectricCurrent in Ampere from the specified electric current
   * stated using the specified Unit.
   *
   * @param   value the electric current stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public ElectricCurrent(double value, Unit unit) {
    super(value * unit.toAmpere,
          AMPERE);
  }

  /**
   * Constructs an ElectricCurrent in Ampere from the specified electric current
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the electric current stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public ElectricCurrent(double value, double error, Unit unit) {
    super(value * unit.toAmpere,
          error * unit.toAmpere,
          AMPERE);
  }

  /**
   * Translates a Quantity in Ampere to an ElectricCurrent.
   *
   * @param   q the quantity in Ampere
   * @throws  UnitException quantity is not in A
   */
  public ElectricCurrent(Quantity q) {
    super(q);
    if (!q.unit.equals(AMPERE))
      throw new UnitException("Quantity is not in A but in " + q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in A
   */
  public ElectricCurrent(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(AMPERE))
      throw new UnitException("Quantity is not in A but in " + this.unit);
  }

  /**
   * Returns a Quantity corresponding to this ElectricCurrent in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toAmpere,
                        this.absoluteError() / unit.toAmpere,
                        unit);
  }

  /**
   * Sets the value for this ElectricCurrent stated using the specified
   * measurement Unit.
   *
   * @param   value the ElectricCurrent stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toAmpere);
  }

  /**
   * Sets the value and the measurement error for this ElectricCurrent both
   * stated using the specified measurement Unit.
   *
   * @param   value the ElectricCurrent stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toAmpere,
        error * unit.toAmpere);
  }

  // Specific constructors.
  //


  // Specific methods.
  //
}

