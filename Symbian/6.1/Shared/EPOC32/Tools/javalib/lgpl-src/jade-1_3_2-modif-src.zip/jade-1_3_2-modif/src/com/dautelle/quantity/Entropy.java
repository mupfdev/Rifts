/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents a measure of the disorder or randomness.
 * The measurement Unit for this quantity is the bit.
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #BIT
 */
public final class Entropy extends Quantity {

  /**
   * This class represents Units of Entropy.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toBit;

    private Unit() { // Default Unit (BIT)
      super("bit");
      this.toBit = 1.0;
    }

    /**
      * Constructs a fundamental Unit of Entropy.
      *
      * @param   symbol the symbol of this Unit
      * @param   toBit the multiplier coefficient to convert this
      *          Unit to Bits
      * @see     Entropy#BIT
      */
    public Unit(String symbol, double toBit) {
      super(symbol);
      this.toBit = toBit;
    }
  }

  /**
   * Used to specify BIT (BInary digiT) Unit. The entropy in bits of a
   * random variable over a finite alphabet is defined to be the sum of
   *  <i>-p(i)*log2(p(i))</i> over the alphabet where <i>p(i)</i> is
   * the probability that the random variable takes on the value <i>i</i>.
   */
  public static final Unit BIT = new Unit();

  /**
   * Used to specify BYTE (BinarY TErm) Unit. It consists of 8 bits.
   */
  public static final Unit BYTE =
          new Unit("Byte", BIT.toBit * 8); // Exact.

  /**
   * Equivalent {@link #BYTE}
   */
  public static final Unit OCTET = BYTE;

  /**
   * Used to specify Kilobyte Unit. It consists of 1024 bytes.
   */
  public static final Unit KILOBYTE =
          new Unit("KiloByte", BYTE.toBit * 1024); // Exact.

  /**
   * Used to specify Megabyte Unit. It consists of 1024 kilobytes.
   */
  public static final Unit MEGABYTE =
          new Unit("MegaByte", KILOBYTE.toBit * 1024); // Exact.

  /**
   * Used to specify Gigabyte Unit. It consists of 1024 megabytes.
   */
  public static final Unit GIGABYTE =
          new Unit("GigaByte", MEGABYTE.toBit * 1024); // Exact.

  /**
   * Used to specify Terabyte Unit. It consists of 1024 gigabytes.
   */
  public static final Unit TERABYTE =
          new Unit("TeraByte", GIGABYTE.toBit * 1024); // Exact.

  /**
   * Constructs an Entropy in BIT from the specified amount
   * stated using the specified Unit.
   *
   * @param   value the amount stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public Entropy(double value, Unit unit) {
    super(value * unit.toBit, BIT);
  }

  /**
   * Constructs an Entropy in BIT from the specified amount
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the amount stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public Entropy(double value, double error, Unit unit) {
    super(value * unit.toBit,
          error * unit.toBit,
          BIT);
  }

  /**
   * Translates a Quantity in BIT to an Entropy.
   *
   * @param   q the quantity in BIT
   * @throws  UnitException quantity is not in bit
   */
  public Entropy(Quantity q) {
    super(q);
    if (!q.unit.equals(BIT))
      throw new UnitException("Quantity is not in bit but in " + q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in rad
   */
  public Entropy(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(BIT))
      throw new UnitException("Quantity is not in bit but in " + this.unit);
  }

  /**
   * Returns a Quantity corresponding to this Entropy in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toBit,
                        this.absoluteError() / unit.toBit,
                        unit);
  }

  /**
   * Sets the value for this Entropy stated using the specified
   * measurement Unit.
   *
   * @param   value the Entropy stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toBit);
  }

  /**
   * Sets the value and the measurement error for this Entropy both
   * stated using the specified measurement Unit.
   *
   * @param   value the Entropy stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toBit,
        error * unit.toBit);
  }

  // Specific constructors.
  //

  // Specific methods.
  //

}

