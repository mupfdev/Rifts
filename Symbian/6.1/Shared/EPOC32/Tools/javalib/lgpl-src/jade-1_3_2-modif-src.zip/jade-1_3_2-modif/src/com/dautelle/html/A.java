/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.html;
import com.dautelle.xml.*;

/**
 * <P> This class represents an Anchor element.</P>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 */
public class A extends Inline {

  /**
   * This attribute names the current anchor so that it may be the destination
   * of another link.
   */
  public String nameAttribute;

  /**
   * This attribute specifies the location of a Web resource, thus defining
   * a link between the current element (the source anchor) and the destination
   * anchor defined by this attribute.
   */
  public String hrefAttribute;

  /**
   * This attribute specifies the character encoding of the resource designated
   * by the link.
   */
  public String charsetAttribute;

  /**
   * Default constructor.
   */
  public A() { super(); }

  /**
   * XML Constructor.
   *
   * @param  attributes "name", "href", "charset", "class", "id", "style".
   * @param  content the XML elements (mark-up or character data).
   * @see    com.dautelle.xml.Constructor
   */
  public A(Attributes attributes, Elements content) {
    super(attributes, content);
    nameAttribute = attributes.get("name");
    hrefAttribute = attributes.get("href");
    charsetAttribute = attributes.get("charset");
  }

  // Overload parent method (add new attributes).
  public Attributes getAttributes() {
    Attributes attributes = super.getAttributes();
    if (nameAttribute != null) attributes.add("name", nameAttribute);
    if (hrefAttribute != null) attributes.add("href", hrefAttribute);
    if (charsetAttribute != null) attributes.add("charset", charsetAttribute);
    return attributes;
  }

}