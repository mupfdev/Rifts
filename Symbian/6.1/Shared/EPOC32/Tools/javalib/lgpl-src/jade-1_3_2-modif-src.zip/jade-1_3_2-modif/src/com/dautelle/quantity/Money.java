/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents a commodity, such as gold, or an officially issued
 * coin or paper note that is legally established as an exchangeable equivalent
 * of all other commodities, such as goods and services,
 * and is used as a measure of their comparative values on the market.
 * The measurement unit for this quantity is the U.S Dollar.
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #USD
 */
public final class Money extends Quantity {

  /**
   * This class represents a Currency.
   */
  public final static class Currency extends com.dautelle.quantity.Unit {
    private double toUSD;

    private Currency() { // Default Currency (USD)
      super("$");
      this.toUSD = 1.0;
    }

    /**
      * Constructs a fundamental Currency. The default exchange rate for this
      * Currency is not set (<code>0.0</code>).
      *
      * @param   symbol the symbol for this Currency
      * @see     Money#setExchangeRate
      */
    public Currency(String symbol) {
      super(symbol);
      this.toUSD = 0.0;
    }
  }

  /**
   * Used to specify United States Dollar Currency.
   */
  public static final Currency USD = new Currency();

  /**
   * Used to specify Australian Dollar Currency.
   */
  public static final Currency AUD = new Currency("AUD");

  /**
   * Used to specify Belgian Franc Currency.
   */
  public static final Currency BEF = new Currency("BEF");

  /**
   * Used to specify British Pound Currency.
   */
  public static final Currency GBP = new Currency("GBP");

  /**
   * Used to specify Canadian Dollar Currency.
   */
  public static final Currency CAD = new Currency("CAD");

  /**
   * Used to specify Danish Krone Currency.
   */
  public static final Currency DKK = new Currency("DKK");

  /**
   * Used to specify Dutch Guilder Currency.
   */
  public static final Currency NLG = new Currency("NLG");

  /**
   * Used to specify Euro Currency.
   */
  public static final Currency EUR = new Currency("EUR");

  /**
   * Used to specify French Franc Currency.
   */
  public static final Currency FRF = new Currency("FRF");

  /**
   * Used to specify German Mark Currency.
   */
  public static final Currency DEM = new Currency("DEM");

  /**
   * Used to specify Italian Lira Currency.
   */
  public static final Currency ITL = new Currency("ITL");

  /**
   * Used to specify Japanese Yen Currency.
   */
  public static final Currency JPY = new Currency("JPY");

  /**
   * Used to specify Swiss Franc Currency.
   */
  public static final Currency CHF = new Currency("CHF");

  /**
   * Constructs a Money in USD from the specified money stated
   * using the specified Currency.
   * The exchange rate of any currency which is not in USD has
   * to be set prior to its use.
   *
   * @param   value the money stated using the specified Currency
   * @param   currency the Currency being used
   * @throws  UnitException exchange rate is not set for this currency
   * @see     Money#setExchangeRate
   */
  public Money(double value, Currency currency) {
    super(value * currency.toUSD, USD);
    if (currency.toUSD == 0.0)
      throw new UnitException("Exchange Rate is not set for " + currency);
  }

  /**
   * Constructs a Money in USD from the specified money
   * and the specified built-in error, both stated using the specified Currency.
   * The exchange rate of any currency which is not in USD has
   * to be set prior to its use.
   *
   * @param   value the money stated using the specified Currency
   * @param   error the absolute error
   * @param   currency the Currency being used
   * @throws  UnitException exchange rate is not set for this currency
   * @see     Money#setExchangeRate
   */
  public Money(double value, double error, Currency currency) {
    super(value * currency.toUSD,
          error * currency.toUSD,
          USD);
    if (currency.toUSD == 0.0)
      throw new UnitException("Exchange Rate is not set for " + currency);
  }

  /**
   * Translates a Quantity in USD to a Money.
   *
   * @param   q the quantity in USD
   * @throws  UnitException quantity is not in $
   */
  public Money(Quantity q) {
    super(q);
    if (!q.unit.equals(USD))
      throw new UnitException("Quantity is not in $ but in " + q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'currency' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in $
   */
  public Money(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("currency")));
    if (!this.unit.equals(USD))
      throw new UnitException("Quantity is not in $ but in " + this.unit);
  }

  /**
   * Returns a Quantity corresponding to this Money using the specified Currency.
   * The exchange rate of the Currency (if not USD) has to be set prior to
   * its use.
   *
   * @param   currency the Currency being used
   * @throws  UnitException exchange rate is not set for this currency
   */
  public Quantity in(Currency currency) {
    if (currency.toUSD == 0.0)
      throw new UnitException("Exchange Rate is not set for " + currency);
    return new Quantity(this.doubleValue() / currency.toUSD,
                        this.absoluteError() / currency.toUSD,
                        currency);
  }

  /**
   * Sets the value for this Money stated using the specified
   * Currency.
   *
   * @param   value the Money stated using the specified Currency.
   * @param   currency the Currency being used
   */
  public void set(double value, Currency currency) {
    set(value * currency.toUSD);
  }

  /**
   * Sets the value and the measurement error for this Money both
   * stated using the specified Currency.
   *
   * @param   value the Money stated using the specified Currency.
   * @param   error the absolute error.
   * @param   currency the Currency being used
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Currency currency) {
    set(value * currency.toUSD,
        error * currency.toUSD);
  }

  // Specific constructors.
  //

  // Specific methods.
  //

  /**
   * Sets the exchange rate of the specified Currency in United States Dollar.
   *
   * @param   inUSD value in United States Dollar of the specified Currency
   * @param   currency the Currency translated in USD
   */
  public static void setExchangeRate(Currency currency, double inUSD) {
    currency.toUSD = inUSD;
  }

  // Overrides parent method.
  //

  public Attributes getAttributes() {
    Attributes attributes = new Attributes();
    attributes.add("value", doubleValue());
    attributes.add("error", absoluteError());
    attributes.add("currency", unit.toString());
    return attributes;
  }

}