/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents the rate at which work is done.
 * The measurement Unit for this quantity is the Watt (Joule / Second = kg*m*m/s/s/s).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #WATT
 * @see     Energy#JOULE
 * @see     Duration#SECOND
 */
public final class Power extends Quantity {

  /**
   * This class represents Units of Power.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toWatt;

    private Unit() { // Default Unit (Watt)
      super(Energy.JOULE.divide(Duration.SECOND));
      this.toWatt = 1.0;
    }

    /**
     * Constructs a fundamental Unit of Power.
     *
     * @param   symbol the symbol of this Unit
     * @param   toWatt the multiplier coefficient to convert this
     *          Unit to Watt
     * @see     Power#WATT
     */
    public Unit(String symbol, double toWatt) {
      super(symbol);
      this.toWatt = toWatt;
    }

    /**
     * Constructs a derived Unit of Power from an Energy Unit divided by
     * a Duration Unit.
     *
     * @param   energyUnit the Energy Unit
     * @param   durationUnit the Duration Unit
     */
    public Unit(Energy.Unit energyUnit, Duration.Unit durationUnit) {
      super(energyUnit.divide(durationUnit));
      Energy energy = new Energy(1.0, energyUnit);
      Duration duration = new Duration(1.0, durationUnit);
      this.toWatt = energy.doubleValue() / duration.doubleValue();
    }
  }

  /**
   * Used to specify Watt Unit. One watt is equal to one joule per second.
   * It is named after the British scientist James Watt (1736-1819).
   */
  public static final Unit WATT = new Unit();

  /**
   * Used to specify Btu per Hour Unit.
   * @ see    Energy#BTU
   * @ see    Duration#HOUR
   */
  public static final Unit BTU_PER_HOUR =
          new Unit(Energy.BTU, Duration.HOUR);


  /**
   * Used to specify Btu per Minute Unit.
   * @ see    Energy#BTU
   * @ see    Duration#MINUTE
   */
  public static final Unit BTU_PER_MINUTE =
          new Unit(Energy.BTU, Duration.MINUTE);

  /**
   * Used to specify Btu per Second Unit.
   * @ see    Energy#BTU
   * @ see    Duration#SECOND
   */
  public static final Unit BTU_PER_SECOND =
          new Unit(Energy.BTU, Duration.SECOND);

  /**
   * Used to specify Calorie per Hour Unit.
   * @ see    Energy#CALORIE
   * @ see    Duration#HOUR
   */
  public static final Unit CALORIE_PER_HOUR =
          new Unit(Energy.CALORIE, Duration.HOUR);

  /**
   * Used to specify Calorie per Minute Unit.
   * @ see    Energy#CALORIE
   * @ see    Duration#MINUTE
   */
  public static final Unit CALORIE_PER_MINUE =
          new Unit(Energy.CALORIE, Duration.MINUTE);

  /**
   * Used to specify Calorie per Second Unit.
   * @ see    Energy#CALORIE
   * @ see    Duration#SECOND
   */
  public static final Unit CALORIE_PER_SECOND =
          new Unit(Energy.CALORIE, Duration.SECOND);

  /**
   * Used to specify  Foot-Pound Force per Minute Unit.
   * @ see    Energy#FOOT_POUND_FORCE
   * @ see    Duration#MINUTE
   */
  public static final Unit FOOT_POUND_FORCE_PER_MINUTE =
          new Unit(Energy.FOOT_POUND_FORCE, Duration.MINUTE);

  /**
   * Used to specify Foot-Pound Force per Second Unit.
   * @ see    Energy#FOOT_POUND_FORCE
   * @ see    Duration#SECOND
   */
  public static final Unit FOOT_POUND_FORCE_PER_SECOND =
          new Unit(Energy.FOOT_POUND_FORCE, Duration.SECOND);

  /**
   * Used to specify GigaWatt Unit.
   * @ see    #WATT
   */
  public static final Unit GIGAWATT = new Unit("GigaWatt", 1e9); // Exact.

  /**
   * Used to specify Horsepower (electric) Unit.
   */
  public static final Unit HORSEPOWER_ELECTRIC =
          new Unit("Horsepower_Electric", 746); // Exact.

  /**
   * Used to specify Horspower (metric) Unit.
   */
  public static final Unit HORSEPOWER_METRIC =
          new Unit("Horsepower_Metric", 735.499);


  /**
   * Used to specify Joule per Hour Unit.
   * @ see    Energy#JOULE
   * @ see    Duration#HOUR
   */
  public static final Unit JOULE_PER_HOUR =
          new Unit(Energy.JOULE, Duration.HOUR);

  /**
   * Used to specify Joule per Minute Unit.
   * @ see    Energy#JOULE
   * @ see    Duration#MINUTE
   */
  public static final Unit JOULE_PER_MINUTE =
          new Unit(Energy.JOULE, Duration.MINUTE);

  /**
   * Used to specify Joule per Second Unit.
   * @ see    Energy#JOULE
   * @ see    Duration#SECOND
   */
  public static final Unit JOULE_PER_SECOND =
          new Unit(Energy.JOULE, Duration.SECOND);

  /**
   * Used to specify KiloCalorie per Hour Unit.
   * @ see    Energy#KILOCALORIE
   * @ see    Duration#HOUR
   */
  public static final Unit KILOCALORIE_PER_HOUR =
          new Unit(Energy.KILOCALORIE, Duration.HOUR);

  /**
   * Used to specify KiloCalorie per Minute Unit.
   * @ see    Energy#KILOCALORIE
   * @ see    Duration#MINUTE
   */
  public static final Unit KILOCALORIE_PER_MINUTE =
          new Unit(Energy.KILOCALORIE, Duration.MINUTE);

  /**
   * Used to specify Kilogram-Force Meter per Hour Unit.
   * @ see    Energy#KILOGRAM_FORCE_METER
   * @ see    Duration#HOUR
   */
  public static final Unit KILOGRAM_FORCE_METER_PER_HOUR =
          new Unit(Energy.KILOGRAM_FORCE_METER, Duration.HOUR);

  /**
   * Used to specify Kilogram-Force Meter per Minute Unit.
   * @ see    Energy#KILOGRAM_FORCE_METER
   * @ see    Duration#MINUTE
   */
  public static final Unit KILOGRAM_FORCE_METER_PER_MINUTE =
          new Unit(Energy.KILOGRAM_FORCE_METER, Duration.MINUTE);

  /**
   * Used to specify KiloWatt Unit.
   * @ see    #WATT
   */
  public static final Unit KILOWATT = new Unit("KiloWatt", 1000); // Exact.

  /**
   * Used to specify MegaWatt Unit.
   * @ see    #WATT
   */
  public static final Unit MEGAWATT = new Unit("MegaWatt", 1e6); // Exact.


  /**
   * Constructs a Power in Watt from the specified power
   * stated using the specified Unit.
   *
   * @param   value the power stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public Power(double value, Unit unit) {
    super(value * unit.toWatt,
          WATT);
  }

  /**
   * Constructs a Power in Watt from the specified power
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the power stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public Power(double value, double error, Unit unit) {
    super(value * unit.toWatt,
          error * unit.toWatt,
          WATT);
  }

  /**
   * Translates a Quantity in Watt to Power.
   *
   * @param   q the quantity in Watt
   * @throws  UnitException quantity is not in kg*m*m/s/s/s
   */
  public Power(Quantity q) {
    super(q);
    if (!q.unit.equals(WATT))
      throw new UnitException(
              "Quantity is not in kg*m*m/s/s/s but in " + q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in kg*m*m/s/s/s
   */
  public Power(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(WATT))
      throw new UnitException(
              "Quantity is not in kg*m*m/s/s/s but in " + this.unit);
  }

  /**
   * Returns a Quantity corresponding to this Power in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toWatt,
                        this.absoluteError() / unit.toWatt,
                        unit);
  }

  /**
   * Sets the value for this Power stated using the specified
   * measurement Unit.
   *
   * @param   value the Power stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toWatt);
  }

  /**
   * Sets the value and the measurement error for this Power both
   * stated using the specified measurement Unit.
   *
   * @param   value the Power stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toWatt,
        error * unit.toWatt);
  }

  // Specific constructors.
  //


  // Specific methods.
  //
}