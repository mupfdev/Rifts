/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents a quantity that tends to produce an acceleration
 * of a body in the direction of its application.
 * The measurement Unit for this quantity is the Newton (kg*m/s/s).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #NEWTON
 * @see     Mass#KILOGRAM
 * @see     Length#METER
 * @see     Duration#SECOND
 */
public final class Force extends Quantity {

  /**
   * This class represents Units of Force.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toNewton;

    private Unit() { // Default Unit (Newton)
      super(Mass.KILOGRAM.multiply(Length.METER).divide(
              Duration.SECOND).divide(Duration.SECOND));
      this.toNewton = 1.0;
    }

    /**
      * Constructs a fundamental Unit of Force.
      *
      * @param   symbol the symbol of this Unit
      * @param   toNewton the multiplier coefficient to convert this
      *          Unit to Newton
      * @see     Force#NEWTON
      */
    public Unit(String symbol, double toNewton) {
      super(symbol);
      this.toNewton = toNewton;
    }
  }

  /**
   * Used to specify Newton Unit.  One newton is the force required to give
   * a mass of 1 kilogram an acceleration of 1 metre per second per second.
   * It is named after the English mathematician and physicist Sir Isaac Newton (1642-1727).
   */
  public static final Unit NEWTON = new Unit();

  /**
   * Used to specify Dyne Unit.
   */
  public static final Unit DYNE = new Unit("Dyne", 1e-5); // Exact.

  /**
   * Used to specify Kilogram Force Unit.
   */
  public static final Unit KILOGRAM_FORCE = new Unit("KiloGram_Force",
          (new Acceleration(1, Acceleration.G)).doubleValue());

  /**
   * Used to specify Kip Unit.
   */
  public static final Unit KIP = new Unit("Kip", 4448.222);

  /**
   * Used to specify Pound Force Unit.
   */
  public static final Unit POUND_FORCE = new Unit("Pound_Force",
          (new Acceleration((new Mass(1, Mass.POUND)).doubleValue(),
          Acceleration.G)).doubleValue());

  /**
   * Used to specify Poundal Unit.
   */
  public static final Unit POUNDAL = new Unit("Poundal", 0.138255);

  /**
   * Used to specify Sthene Unit.
   */
  public static final Unit STHENE = new Unit("Sthene", 1000);

  /**
   * Used to specify Tonne Force Unit.
   */
  public static final Unit TONNE_FORCE = new Unit("Tonne_Force",
          (new Acceleration(1000, Acceleration.G)).doubleValue());

  /**
   * Used to specify Ton Force (U.K.) Unit.
   */
  public static final Unit TON_FORCE_UK = new Unit("Ton_Force_UK",
          (new Acceleration((new Mass(1, Mass.TON_UK)).doubleValue(),
          Acceleration.G)).doubleValue());

  /**
   * Used to specify Ton Force (U.S) Unit.
   */
  public static final Unit TON_FORCE_US = new Unit("Ton_Force_US",
          (new Acceleration((new Mass(1, Mass.TON_US)).doubleValue(),
          Acceleration.G)).doubleValue());

  /**
   * Constructs a Force in Newton from the specified force
   * stated using the specified Unit.
   *
   * @param   value the force stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public Force(double value, Unit unit) {
    super(value * unit.toNewton,
          NEWTON);
  }

  /**
   * Constructs a Force in Newton from the specified force
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the force stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public Force(double value, double error, Unit unit) {
    super(value * unit.toNewton,
          error * unit.toNewton,
          NEWTON);
  }

  /**
   * Translates a Quantity in Newton to a Force.
   *
   * @param   q the quantity in Newton
   * @throws  UnitException quantity is not in kg*m/s/s
   */
  public Force(Quantity q) {
    super(q);
    if (!q.unit.equals(NEWTON))
      throw new UnitException("Quantity is not in kg*m/s/s but in " +
              q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in kg*m/s/s
   */
  public Force(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(NEWTON))
      throw new UnitException("Quantity is not in kg*m/s/s but in " +
              this.unit);
  }

  /**
   * Returns a Quantity corresponding to this Force in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toNewton,
                        this.absoluteError() / unit.toNewton,
                        unit);
  }

  /**
   * Sets the value for this Force stated using the specified
   * measurement Unit.
   *
   * @param   value the Force stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toNewton);
  }

  /**
   * Sets the value and the measurement error for this Force both
   * stated using the specified measurement Unit.
   *
   * @param   value the Force stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toNewton,
        error * unit.toNewton);
  }

  // Specific constructors.
  //


  // Specific methods.
  //
}

