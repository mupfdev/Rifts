/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents an Electric Inductance.
 * The measurement Unit for this quantity is the Henry
 * (Volt * Second / Ampere = kg*m*m/A/A/s/s).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #HENRY
 * @see     ElectricPotential#VOLT
 * @see     Duration#SECOND
 * @see     ElectricCurrent#AMPERE
 */
public final class ElectricInductance extends Quantity {

  /**
   * This class represents Units of ElectricInductance.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toHenry;

    private Unit() { // Default Unit (Henry)
      super(ElectricPotential.VOLT.multiply(Duration.SECOND).divide(
              ElectricCurrent.AMPERE));
      this.toHenry = 1.0;
   }

    /**
     * Constructs a fundamental Unit of ElectricInductance.
     *
     * @param   symbol the symbol of this Unit
     * @param   toHenry the multiplier coefficient to convert this
                Unit to Henry
     * @see     ElectricInductance#HENRY
     */
    public Unit(String symbol, double toHenry) {
      super(symbol);
      this.toHenry = toHenry;
    }
  }

  /**
   * Used to specify Henry Unit. One Henry is equal to the inductance for which
   * an induced electromotive force of one volt is produced when the current
   * is varied at the rate of one ampere per second.
   * It is named after the American physicist Joseph Henry (1791-1878).
   */
  public static final Unit HENRY = new Unit();

  /**
   * Constructs an ElectricInductance in Henry from the specified electric inductance
   * stated using the specified Unit.
   *
   * @param   value the electric inductance stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public ElectricInductance(double value, Unit unit) {
    super(value * unit.toHenry,
          HENRY);
  }

  /**
   * Constructs an ElectricInductance in Henry from the specified electric inductance
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the electric inductance stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public ElectricInductance(double value, double error, Unit unit) {
    super(value * unit.toHenry,
          error * unit.toHenry,
          HENRY);
  }

  /**
   * Translates a Quantity in Henry to ElectricInductance.
   *
   * @param   q the quantity in Henry
   * @throws  UnitException quantity is not in kg*m*m/A/A/s/s
   */
  public ElectricInductance(Quantity q) {
    super(q);
    if (!q.unit.equals(HENRY))
      throw new UnitException(
              "Quantity is not in kg*m*m/A/A/s/s but in " + q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in kg*m*m/A/A/s/s
   */
  public ElectricInductance(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(HENRY))
      throw new UnitException(
              "Quantity is not in kg*m*m/A/A/s/s but in " + this.unit);
  }

  /**
   * Returns a Quantity corresponding to this ElectricInductance in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toHenry,
                        this.absoluteError() / unit.toHenry,
                        unit);
  }

  /**
   * Sets the value for this ElectricInductance stated using the specified
   * measurement Unit.
   *
   * @param   value the ElectricInductance stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toHenry);
  }

  /**
   * Sets the value and the measurement error for this ElectricInductance both
   * stated using the specified measurement Unit.
   *
   * @param   value the ElectricInductance stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toHenry,
        error * unit.toHenry);
  }

  // Specific constructors.
  //


  // Specific methods.
  //
}


