/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.util;
import java.util.Collection;

/**
 * This class represents events relative to collections.
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     ObservableCollection
 * @see     CollectionListener
 */
public class CollectionEvent extends Event {

  /**
   * This ID indicates that an element is being added to the collection.
   */
  public static final ID ELEMENT_ADDED = new ID("Element Added");

  /**
   * This ID indicates that an element is being removed from the collection.
   */
  public static final ID ELEMENT_REMOVED = new ID("Element Removed");

  /**
   * The element affected by this event.
   */
  protected Object element;

  /**
   * Constructs a collection event.
   *
   * @param source the collection that originated the event.
   * @param id the type of event.
   * @param element the element involved in the event.
   */
  public CollectionEvent(Collection source, ID id, Object element) {
    super(source, id);
    this.element = element;
  }

  /**
   * Returns the originator of this event.
   *
   * @return the collection that originated the event.
   */
  public Collection getCollection() {
    return (Collection) source;
  }

  /**
   * Returns the element that was affected by this event.
   *
   * @return the element.
   */
  public Object getElement() {
    return element;
  }
}