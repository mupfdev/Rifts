/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.util;
import java.util.Hashtable;
import java.util.Vector;
import java.util.Iterator;
import java.util.Collection;
import java.io.ObjectStreamException;

/**
 * This abstract class represents the base class for all Enumerates.
 * Using this class has the following advantages over the usual
 * <code>"static int"</code> declaration:
 * <ul>
 * <li> It is strongly typed</li>
 * <li> It avoids assignment errors (duplications or discontinuities)</li>
 * <li> Comparaisons are as fast as their "Integer" counterpart</li>
 * <li> Enumerates can be used in a switch or as array index for direct
 *      access (<code>pos()</code>)</li>
 * <li> They are <code>Serializable</code>. </li>
 * <li> The collection can be exended by sub-classing.</li>
 * <li> The complete sub-class collection is accessible.</li>
 * </ul>
 * Within a sub-class, Enumerates's names are supposed to be unique.
 * Unnamed Enumerates (created with <code>null</code>)
 * represent the whole sub-class collection, and may be used to perform
 * operations upon all Enumerates within the sub-class, such as <code>toArray(),
 * iterator(), size(), get(pos), get(name) ... </code>
 * <blockquote><pre>
 *     public static class Color extends Enumerate {
 *         public static final Color RED = new Color("red");
 *         public static final Color BLUE = new Color("blue");
 *         public static final Color GREEN = new Color("green");
 *
 *         public static final Color all = new Color(null);
 *         private Color(String name) { super(name); }
 *     }
 * </pre></blockquote>
 * The following code prints all colors defined:
 * <blockquote><pre>
 *     for (Iterator i = Color.all.iterator() ; i.hasNext() ;)
 *         System.out.println(i.next());
 * </pre></blockquote>
 *
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 */
public abstract class Enumerate implements java.io.Serializable {

  /**
   * The collection of all Enumerates per sub-classes
   */
  private static final Hashtable subclasses = new Hashtable();

  /**
   * Holds the name of this Enumerate or <code>null</code> if the
   * Enumerate represents the complete collection.
   */
  private final String name;

  /**
   * Hold the position of this Enumerate according to its declarative order,
   * starting at zero.
   */
  private final transient int pos;

  /**
   * Hold the sub-class collection where this Enumerate is stored.
   */
  private final transient Vector collection;

  /**
   * Constructs an Enumerate with the given name or <code>null</code> if
   * the Enumerate is used solely to access its whole sub-class collection.
   *
   * @param   name the name of this Enumerate or <code>null</code>.
   * @throws  EnumerateException  the name is already used within
   *          this Enumerate sub-class collection.
   */
  protected Enumerate(String name) {

    // Create the Enumerate collection if it doesn't exist.
    Vector enumerates = (Vector) subclasses.get(this.getClass());
    if (enumerates == null) {
      collection = new Vector();
      subclasses.put(this.getClass(), collection);
    } else {
      collection = enumerates;
    }

    if (name != null) {
      // Check if the name is already used (duplicate)
      if (search(name, collection) != null)
          throw new EnumerateException("Name \"" + name +
                  "\" is already used in class " + this.getClass().getName());

      this.name = name;
      pos = collection.size();
      collection.add(this);
    } else {
      this.name = null;
      pos = -1;
    }
  }

  /**
   * Returns a string representation of this Enumerate.
   *
   * @return  this Enumerate's name or the representation of the whole
   *          sub-class collection.
   */
  public String toString() {
    if (name == null) return collection.toString();
    else return name;
  }

  /**
   * Returns the name of this Enumerate.
   *
   * @return  the name of this Enumerate or <code>null</code> if it represents
   *          the whole sub-class collection.
   * @see     #get(String)
   */
  public String getName() {
    return name;
  }

  /**
   * Returns the declarative position of this Enumerate starting
   * at <code>0</code>. This position can be used to provide direct
   * access to behavior (switch statement) or data (array) associated with
   * this Enumerate.&nbsp For equality / inequality comparaisons,
   * relational operators <code>== and !=</code> are preferred
   * (i.e. <code>color == Color.RED</code>).
   *
   * @return  this Enumerate declarative position within its sub-class or
   *          <code>-1</code> if it represents the whole sub-class collection.
   * @see     #get(int)
   */
  public int pos() {
    return pos;
  }

  /**
   * Returns the Enumerate at the specified declarative position within its
   * sub-class collection.
   *
   * @param   pos declarative position of the Enumerate to return.
   * @return  the Enumerate at the specified declarative position
   * @throws  IndexOutOfBoundsException if the position is out of range (
   *          <code> pos &lt; 0 || pos &gt;= this.size()</code>).
   * @see     #pos()
   */
  public Enumerate get(int pos) {
    return (Enumerate) collection.get(pos);
  }

  /**
   * Returns the Enumerate with the specified name within its sub-class
   * collection.
   *
   * @param   name the name to search for.
   * @return  the Enumerate with the specified name or <code>null</code>
   *          if not found.
   * @see     #getName()
   */
  public Enumerate get(String name) {
    return search(name, collection);
  }

  /**
   * Returns the size of this Enumerate sub-class collection.
   *
   * @return  the number of Enumerates in this sub-class collection.
   */
  public int size() {
    return collection.size();
  }

  /**
   * Returns an <code>Iterator</code> over this Enumerate sub-class collection.
   *
   * @return  an <code>Iterator</code> over the Enumerate sub-class collection.
   * @see     java.util.Iterator
   */
  public Iterator iterator() {
    return collection.iterator();
  }

  /**
   * Returns an array containing this Enumerate sub-class collection.
   *
   * @return  all Enumerates within this sub-class collection.
   */
  public Object[] toArray() {
    return collection.toArray();
  }

  /**
   * Overrides <code>readResolve()</code> to support <code>Serialization</code>.
   *
   * @return  the Enumerate from the corresponding sub-class collection.
   * @throws  EnumerateException if the Enumerate doesn't exist.
   */
  protected Object readResolve() throws ObjectStreamException {
    Vector enumerates = (Vector) subclasses.get(this.getClass());
    if (enumerates == null) throw new EnumerateException(
        "Enumerate class " + this.getClass() + " not loaded");
    Enumerate e = search(name, enumerates);
    if (e == null) throw new EnumerateException(
        "Enumerate " + name + " doesn't exist");
    return e;
  }

  /**
   * Searches for the Enumerate with the specified name within the specified
   * collection.
   *
   * @param   name the name of the enumerate to search for.
   * @param   c the collection to search into.
   * @return  the Enumerate with the specified name or <code>null</code>
   *          if none has been found.
   */
  private static Enumerate search(String name, Collection c) {
    for (Iterator i = c.iterator() ; i.hasNext() ;) {
      Enumerate e = (Enumerate) i.next();
      if (e.name.equals(name)) return e;
    }
    return null;
  }

}