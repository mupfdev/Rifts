/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents a force applied uniformly over a surface.
 * The measurement Unit for this quantity is the Pascal (Newton / Square_Meter = kg/m/s/s).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #PASCAL
 * @see     Force#NEWTON
 * @see     Area#SQUARE_METER
 */
public final class Pressure extends Quantity {

  /**
   * This class represents Units of Pressure.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toPascal;

    private Unit() { // Default Unit (Pascal)
      super(Force.NEWTON.divide(Area.SQUARE_METER));
      this.toPascal = 1.0;
    }

    /**
     * Constructs a fundamental Unit of Pressure.
     *
     * @param   symbol the symbol of this Unit
     * @param   toPascal the multiplier coefficient to convert this
     *          Unit to Pascal
     * @see     Pressure#PASCAL
     */
    public Unit(String symbol, double toPascal) {
      super(symbol);
      this.toPascal = toPascal;
    }

    /**
     * Constructs a derived Unit of Pressure from a Force Unit divided by
     * an Area Unit.
     *
     * @param   forceUnit the Force Unit
     * @param   areaUnit the Area Unit
     */
    public Unit(Force.Unit forceUnit, Area.Unit areaUnit) {
      super(forceUnit.divide(areaUnit));
      Force force = new Force(1.0, forceUnit);
      Area area = new Area(1.0, areaUnit);
      this.toPascal = force.doubleValue() / area.doubleValue();
    }
  }

  /**
   * Used to specify Pascal Unit. One watt is equal to one newton per square meter.
   * It is named after the French philosopher and mathematician Blaise Pascal (1623-1662).
   */
  public static final Unit PASCAL = new Unit();

  /**
   * Used to specify KiloPascal Unit.
   * @ see    #PASCAL
   */
  public static final Unit KILOPASCAL = new Unit("KiloPascal", 1000); // Exact.

  /**
   * Used to specify MegaPascal Unit.
   * @ see    #PASCAL
   */
  public static final Unit MEGAPASCAL = new Unit("MegaPascal", 1e6); // Exact.

  /**
   * Used to specify GigaPascal Unit.
   * @ see    #PASCAL
   */
  public static final Unit GIGAPASCAL = new Unit("GigaPascal", 1e9); // Exact.

  /**
   * Used to specify Atmosphere Unit.
   */
  public static final Unit ATMOSPHERE = new Unit("Atmosphere", 101325); // Exact.
  /**
   * Used to specify Bar Unit.
   */
  public static final Unit BAR = new Unit("Bar", 100000); // Exact.

  /**
   * Used to specify Centimeters of Mercury Unit.
   */
  public static final Unit CENTIMETER_OF_MERCURY =
          new Unit("CentiMeter_Of_Mercury", 1333.22);

  /**
   * Equivalent {@link #CENTIMETER_OF_MERCURY}
   */
  public static final Unit CENTIMETRE_OF_MERCURY = CENTIMETER_OF_MERCURY;

  /**
   * Used to specify Centimeter of Water Unit.
   * @ see    Length#CENTIMETER
   */
  public static final Unit CENTIMETER_OF_WATER =
          new Unit("CentiMeter_Of_Water",98.0665); // Exact.

  /**
   * Equivalent {@link #CENTIMETER_OF_WATER}
   */
  public static final Unit CENTIMETRE_OF_WATER = CENTIMETER_OF_WATER ;

  /**
   * Used to specify Foot of Water Unit.
   * @ see    Length#FOOT
   */
  public static final Unit FOOT_OF_WATER =
          new Unit("Foot_Of_Water", 2989.06692); // Exact.

  /**
   * Used to specify HectoPascal Unit.
   * @ see    #PASCAL
   */
  public static final Unit HECTOPASCAL = new Unit("HectoPascal", 100); // Exact.

  /**
   * Used to specify Inch of Water Unit.
   * @ see    Length#INCH
   */
  public static final Unit INCH_OF_WATER =
          new Unit("Inch_Of_Water", 249.08891); // Exact.

  /**
   * Used to specify Inch of Mercury Unit.
   * @ see    Length#INCH
   */
  public static final Unit INCH_OF_MERCURY =
          new Unit("Inch_Of_Mercury", 3386.388);

  /**
   * Used to specify Kilogram-Force per Square Centimeter Unit.
   * @ see    Force#KILOGRAM_FORCE
   * @ see    Area#SQUARE_CENTIMETER
   */
  public static final Unit KILOGRAM_FORCE_PER_SQUARE_CENTIMETER =
          new Unit(Force.KILOGRAM_FORCE, Area.SQUARE_CENTIMETER);

  /**
   * Equivalent {@link #KILOGRAM_FORCE_PER_SQUARE_CENTIMETER}
   */
  public static final Unit KILOGRAM_FORCE_PER_SQUARE_CENTIMETRE =
          KILOGRAM_FORCE_PER_SQUARE_CENTIMETER;

  /**
   * Used to specify Kilogram-Force per Square Meter Unit.
   * @ see    Force#KILOGRAM_FORCE
   * @ see    Area#SQUARE_METER
   */
  public static final Unit KILOGRAM_FORCE_PER_SQUARE_METER =
          new Unit(Force.KILOGRAM_FORCE, Area.SQUARE_METER);

  /**
   * Equivalent {@link #KILOGRAM_FORCE_PER_SQUARE_METER}
   */
  public static final Unit KILOGRAM_FORCE_PER_SQUARE_METRE =
          KILOGRAM_FORCE_PER_SQUARE_METER;

  /**
   * Used to specify Kip per Square Inch Unit.
   * @ see    Force#KIP
   * @ see    Area#SQUARE_INCH
   */
  public static final Unit KIP_PER_SQUARE_INCH =
          new Unit(Force.KIP, Area.SQUARE_INCH);

  /**
   * Used to specify Meter of Water Unit.
   */
  public static final Unit METER_OF_WATER =
          new Unit("Meter_Of_Water", 9806.65); // Exact.

  /**
   * Equivalent {@link #METER_OF_WATER}
   */
  public static final Unit METRE_OF_WATER = METER_OF_WATER;

  /**
   * Used to specify Millibar Unit.
   */
  public static final Unit MILLIBAR = new Unit("MilliBar", 100); // Exact.

  /**
   * Used to specify Millimeter of Mercury Unit.
   */
  public static final Unit MILLIMETER_OF_MERCURY =
          new Unit("MilliMeter_Of_Mercury", 133.322);

  /**
   * Equivalent {@link #MILLIMETER_OF_MERCURY}
   */
  public static final Unit MILLIMETRE_OF_MERCURY = MILLIMETER_OF_MERCURY;

  /**
   * Used to specify Millimeter of Water Unit.
   */
  public static final Unit MILLIMETER_OF_WATER =
          new Unit("MilliMeter_Of_Water", 9.80665); // Exact.

  /**
   * Equivalent {@link #MILLIMETER_OF_WATER}
   */
  public static final Unit MILLIMETRE_OF_WATER = MILLIMETER_OF_WATER;

  /**
   * Used to specify Newton per Square Centimeter Unit.
   * @ see    Force#NEWTON
   * @ see    Area#SQUARE_CENTIMETER
   */
  public static final Unit NEWTON_PER_SQUARE_CENTIMETER =
          new Unit(Force.NEWTON, Area.SQUARE_CENTIMETER);

  /**
   * Equivalent {@link #NEWTON_PER_SQUARE_CENTIMETER}
   */
  public static final Unit NEWTON_PER_SQUARE_CENTIMETRE =
          NEWTON_PER_SQUARE_CENTIMETER;

  /**
   * Used to specify Newton per Square Meter Unit.
   * @ see    Force#NEWTON
   * @ see    Area#SQUARE_METER
   */
  public static final Unit NEWTON_PER_SQUARE_METER =
          new Unit(Force.NEWTON, Area.SQUARE_METER);

  /**
   * Equivalent {@link #NEWTON_PER_SQUARE_METER}
   */
  public static final Unit NEWTON_PER_SQUARE_METRE =
          NEWTON_PER_SQUARE_METER;

  /**
   * Used to specify Newton per Square MilliMeter Unit.
   * @ see    Force#NEWTON
   * @ see    Area#SQUARE_MILLIMETER
   */
  public static final Unit NEWTON_PER_SQUARE_MILLIMETER =
          new Unit(Force.NEWTON, Area.SQUARE_MILLIMETER);

  /**
   * Equivalent {@link #NEWTON_PER_SQUARE_MILLIMETER}
   */
  public static final Unit NEWTON_PER_SQUARE_MILLIMETRE =
          NEWTON_PER_SQUARE_MILLIMETER;

  /**
   * Used to specify Pound-Force per Square Foot Unit.
   * @ see    Force#POUND_FORCE
   * @ see    Area#SQUARE_FOOT
   */
  public static final Unit POUND_FORCE_PER_SQUARE_FOOT =
          new Unit(Force.POUND_FORCE, Area.SQUARE_FOOT);

  /**
   * Used to specify Pound-Force per Square Inch Unit (psi).
   * @ see    Force#POUND_FORCE
   * @ see    Area#SQUARE_INCH
   */
  public static final Unit POUND_FORCE_PER_SQUARE_INCH =
          new Unit(Force.POUND_FORCE, Area.SQUARE_INCH);

  /**
   * Used to specify Poundal per Square Foot Unit.
   * @ see    Force#POUNDAL
   * @ see    Area#SQUARE_FOOT
   */
  public static final Unit POUNDAL_PER_SQUARE_FOOT =
          new Unit(Force.POUNDAL, Area.SQUARE_FOOT);

  /**
   * Used to specify Ton-Force per Square Foot (U.K.) Unit.
   * @ see    Force#TON_FORCE_UK
   * @ see    Area#SQUARE_FOOT
   */
  public static final Unit TON_FORCE_PER_SQUARE_FOOT_UK =
          new Unit(Force.TON_FORCE_UK, Area.SQUARE_FOOT);

  /**
   * Used to specify Ton-Force per Square Inch (U.K.) Unit.
   * @ see    Force#TON_FORCE_UK
   * @ see    Area#SQUARE_INCH
   */
  public static final Unit TON_FORCE_PER_SQUARE_INCH_UK =
          new Unit(Force.TON_FORCE_UK, Area.SQUARE_INCH);

  /**
   * Used to specify Ton-Force per Square Foot (U.S.) Unit.
   * @ see    Force#TON_FORCE_US
   * @ see    Area#SQUARE_FOOT
   */
  public static final Unit TON_FORCE_PER_SQUARE_FOOT_US =
          new Unit(Force.TON_FORCE_US, Area.SQUARE_FOOT);

  /**
   * Used to specify Ton-Force per Square Inch (U.S.) Unit.
   * @ see    Force#TON_FORCE_US
   * @ see    Area#SQUARE_INCH
   */
  public static final Unit TON_FORCE_PER_SQUARE_INCH_US =
          new Unit(Force.TON_FORCE_US, Area.SQUARE_INCH);

  /**
   * Used to specify Tonne-Force per Square Centimeter Unit.
   * @ see    Force#TONNE_FORCE
   * @ see    Area#SQUARE_CENTIMETER
   */
  public static final Unit TONNE_FORCE_PER_SQUARE_CENTIMETER =
          new Unit(Force.TONNE_FORCE, Area.SQUARE_CENTIMETER);

  /**
   * Equivalent {@link #TONNE_FORCE_PER_SQUARE_CENTIMETER}
   */
  public static final Unit TONNE_FORCE_PER_SQUARE_CENTIMETRE =
          TONNE_FORCE_PER_SQUARE_CENTIMETER;

  /**
   * Used to specify Tonne-Force per Square Meter Unit.
   * @ see    Force#TONNE_FORCE
   * @ see    Area#SQUARE_METER
   */
  public static final Unit TONNE_FORCE_PER_SQUARE_METER =
          new Unit(Force.TONNE_FORCE, Area.SQUARE_METER);

  /**
   * Equivalent {@link #TONNE_FORCE_PER_SQUARE_METER}
   */
  public static final Unit TONNE_FORCE_PER_SQUARE_METRE =
          TONNE_FORCE_PER_SQUARE_METER;

  /**
   * Constructs a Pressure in Pascal from the specified pressure
   * stated using the specified Unit.
   *
   * @param   value the pressure stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public Pressure(double value, Unit unit) {
    super(value * unit.toPascal,
          PASCAL);
  }

  /**
   * Constructs a Pressure in Pascal from the specified pressure
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the pressure stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public Pressure(double value, double error, Unit unit) {
    super(value * unit.toPascal,
          error * unit.toPascal,
          PASCAL);
  }

  /**
   * Translates a Quantity in Pascal to Pressure.
   *
   * @param   q the quantity in Pascal
   * @throws  UnitException quantity is not in kg/m/s/s
   */
  public Pressure(Quantity q) {
    super(q);
    if (!q.unit.equals(PASCAL))
      throw new UnitException("Quantity is not in kg/m/s/s but in " +
              q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in kg/m/s/s
   */
  public Pressure(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(PASCAL))
      throw new UnitException("Quantity is not in kg/m/s/s but in " +
              this.unit);
  }

  /**
   * Returns a Quantity corresponding to this Pressure in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toPascal,
                        this.absoluteError() / unit.toPascal,
                        unit);
  }

  /**
   * Sets the value for this Pressure stated using the specified
   * measurement Unit.
   *
   * @param   value the Pressure stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toPascal);
  }

  /**
   * Sets the value and the measurement error for this Pressure both
   * stated using the specified measurement Unit.
   *
   * @param   value the Pressure stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toPascal,
        error * unit.toPascal);
  }

  // Specific constructors.
  //


  // Specific methods.
  //
}