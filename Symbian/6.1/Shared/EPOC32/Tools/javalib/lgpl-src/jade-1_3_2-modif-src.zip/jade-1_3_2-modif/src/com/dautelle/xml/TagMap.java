/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This file was created by Symbian Ltd. on 21 March 2001.
 * This file is copyright 2001 Symbian Ltd.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
package com.dautelle.xml;

import java.util.*;

public class TagMap
	{

	/** Classes, with tags as keys.
	 */
	protected final Map classes = new HashMap();
	
	/** Tags, with classnames as keys.
	 */
	protected final Map tags = new HashMap();

	public TagMap()
		{
		super();
		}
	
	/** @throws IllegalArgumentException if the map already
		contains the specified tag, or if you pass in null value(s)
	*/
	public void add(Class clazz, String tag)
		{
		if(clazz==null || tag==null || tags.containsKey(tag))
			{
			throw new IllegalArgumentException();
			}
		classes.put(tag,clazz);
		tags.put(clazz.getName(),tag);
		}

	/** Returns null if the map does not contain the specified class.
	 */
	public String classToTag(String className)
		{
		return (String)tags.get(className);
		}

	/** Returns null if the map does not contain the specified class.
	 */
	public String classToTag(Class clazz)
		{
		return (String)classToTag(clazz.getName());
		}

	/** Returns null if the map does not contain the specified tag.
	 */
	public Class tagToClass(String tag)
		{
		return (Class)classes.get(tag);
		}

	}
