/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.xml;
import com.dautelle.util.Enumerate;
import java.io.InputStream;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.IOException;
import java.net.URL;
import java.net.MalformedURLException;
import org.xml.sax.*;
import java.util.HashMap;

/**
 * This class provides a minimalist parser to create objects from
 * their XML representation. Most of the SAX 2 features are not supported.
 * Nevertheless, this parser is guaranteed to work if the XML input source has
 * been formatted using an ObjectWriter.
 * Here is an example which illustrates the supported features:
 * <blockquote><pre>
 *   &lt;?xml version="1.0" encoding="UTF-8"?&gt;
 *   &lt;!--  Comments may appear anywhere in a document outside other markup --&gt;
 *   &lt;math:Matrix xmlns="java:com.dautelle.quantity"
 *                xmlns:math="java:com.dautelle.math"
 *                row='2' column='2' &gt;
 *     &lt;math:Real value="0.0"/&gt;
 *     &lt;math:Complex real="0.0" imaginary="1.0"/&gt;
 *     &lt;Mass value="1"  error="0.001" unit="kg"/&gt;
 *     &lt;Duration value="60"  error="0" unit="s"/&gt;
 *     &lt;Quantity value="1"  error="0"
 *         unit = "dummy unit containing &amp;apos; and &amp;quot;"/&gt;
 *         &lt;!--  dummy unit containing " and ' --&gt;
 *   &lt;/math:Matrix&gt;
 * </pre></blockquote>
 *
 * Note: This parser is extremely fast (optimized state machine).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     Constructor
 * @see     ObjectWriter
 */
public class LightParser implements XMLReader {

  /**
   * The content handler.
   */
  private ContentHandler contentHandler;

  /**
   * Current Tag Name.
   */
  private StringBuffer tagName = new StringBuffer();

  /**
   * Current Attribute Name.
   */
  private StringBuffer attributeName = new StringBuffer();

  /**
   * Current Attribute Value.
   */
  private StringBuffer attributeValue = new StringBuffer();

  /**
   * Current Character Data.
   */
  private StringBuffer data = new StringBuffer();

  /**
   * Current Attributes (excludes namespace associations).
   */
  private Attributes attributes = new Attributes();

  /**
   * Current Default Namespace.
   */
  private String defaultNamespace = "";

  /**
   * Current Namespace Mapping.
   */
  private HashMap namespaces = new HashMap();

  ///////////////////////////////////////////////
  // Partialy implemented interface XMLReader. //
  ///////////////////////////////////////////////

  /**
   * Allow an application to register a content event handler.
   *
   * <p>If the application does not register a content handler, all
   * content events reported by the SAX parser will be silently
   * ignored.</p>
   *
   * <p>Applications may register a new or different handler in the
   * middle of a parse, and the SAX parser must begin using the new
   * handler immediately.</p>
   *
   * @param handler The content handler.
   * @exception java.lang.NullPointerException If the handler
   *            argument is null.
   * @see #getContentHandler
   */
  public void setContentHandler (ContentHandler handler) {
    if (handler == null) throw new NullPointerException();
    contentHandler = handler;
  }

  /**
   * Return the current content handler.
   *
   * @return The current content handler, or null if none
   *         has been registered.
   * @see #setContentHandler
   */
  public ContentHandler getContentHandler () {
    return contentHandler;
  }

 /**
   * Parse an XML document.
   *
   * <p>The application can use this method to instruct the XML
   * reader to begin parsing an XML document from any valid input
   * source (a character stream, a byte stream, or a URI).</p>
   *
   * <p>Applications may not invoke this method while a parse is in
   * progress (they should create a new XMLReader instead for each
   * nested XML document).  Once a parse is complete, an
   * application may reuse the same XMLReader object, possibly with a
   * different input source.</p>
   *
   * <p>During the parse, the XMLReader will provide information
   * about the XML document through the registered event
   * handlers.</p>
   *
   * <p>This method is synchronous: it will not return until parsing
   * has ended.  If a client application wants to terminate
   * parsing early, it should throw an exception.</p>
   *
   * @param source The input source for the top-level of the
   *        XML document.
   * @exception org.xml.sax.SAXException Any SAX exception, possibly
   *            wrapping another exception.
   * @exception java.io.IOException An IO exception from the parser,
   *            possibly from a byte stream or character stream
   *            supplied by the application.
   * @see org.xml.sax.InputSource
   * @see #parse(java.lang.String)
   * @see #setEntityResolver
   * @see #setDTDHandler
   * @see #setContentHandler
   * @see #setErrorHandler
     */
  public void parse (InputSource input) throws IOException, SAXException {

    // Get a buffered reader from the input source.
    //
    Reader reader = input.getCharacterStream();
    if (reader == null) {
      InputStream inputStream = input.getByteStream();
      if (inputStream == null) {
        String systemId = input.getSystemId();
        if (systemId == null) throw new IOException("Input Source Unknown");
        try {
          URL url = new URL(systemId);
          inputStream = url.openStream();
        } catch (MalformedURLException e) {
          throw new SAXException(e);
        }
      }
      String encoding = input.getEncoding();
      if (encoding != null) reader = new InputStreamReader(inputStream, encoding);
      else reader = new InputStreamReader(inputStream);
    }
    BufferedReader bufferedReader = new BufferedReader(reader);

    // Clear local data.
    tagName.setLength(0);
    data.setLength(0);
    attributeName.setLength(0);
    attributeValue.setLength(0);
    attributes.clear();
    namespaces.clear();
    defaultNamespace = "";

    // Start.
    if (contentHandler != null) contentHandler.startDocument();

    // Parse the document.
    //
    State state = DEFAULT;
    int lineNbr = 1;
    boolean carriageReturn = false;
    for (int c = bufferedReader.read(); c != -1; c = bufferedReader.read()) {

      // Switch state.
      switch (state.pos()) {

        case 0: // DEFAULT
          if (c == '<') {
            char[] chars = replaceEscapes(data.toString()).toCharArray();
            contentHandler.characters(chars, 0, chars.length);
            data.setLength(0);
            state = READ_LESS;
          } else {
            data.append((char) c);
          }
          break;

        case 1: // READ_LESS
          if (c == '!') state = READ_LESS_EXCL;
          else if (c == '?') state = PI;
          else if (c == '/') state = END_TAG_NAME;
          else {
            tagName.append((char)c);
            state = START_TAG_NAME;
          }
          break;

        // Comments (ignored).
        case 2: // READ_LESS_EXCL
          if (c == '-') state = READ_LESS_EXCL_DASH;
          else throw new SAXException("Expected '-' at line " + lineNbr);
          break;
        case 3: // READ_LESS_EXCL_DASH
          if (c == '-') state = COMMENT;
          else throw new SAXException("Expected '-' at line " + lineNbr);
          break;
        case 4: // COMMENT
          if (c == '-') state = COMMENT_DASH;
          break;
        case 5: // COMMENT_DASH
          if (c == '-') state = COMMENT_DASH_DASH;
          else state = COMMENT;
          break;
        case 6: // COMMENT_DASH_DASH
          if (c == '>') state = DEFAULT;
          else state = COMMENT;
          break;

        // Processing Instructions (ignored).
        case 7: // PI
          if (c == '?') state = PI_QUES;
          break;
        case 8: // PI_QUES
          if (c == '>') state = DEFAULT;
          else state = PI;
          break;

        // Tags.
        case 9: // END_TAG_NAME
          if (c == '>') {
            processTag(false, true);
            state = DEFAULT;
          } else {
            tagName.append((char)c);
          }
          break;
        case 10: // START_TAG_NAME
          if (c == '/') state = EMPTY_ELEMENT_TAG;
          if (c == '>') {
            processTag(true, false);
            state = DEFAULT;
          } else if (Character.isWhitespace((char)c)) {
            state = ATTRIBUTE_LIST;
          } else tagName.append((char)c);
          break;
        case 11: // EMPTY_ELEMENT_TAG
          if (c != '>') throw new SAXException("Expected '>' at line " + lineNbr);
          processTag(true, true);
          state = DEFAULT;
          break;

        // Attributes
        case 12: // ATTRIBUTE_LIST
          if (!Character.isWhitespace((char)c)) {
            if (c == '/') state = EMPTY_ELEMENT_TAG;
            else if (c == '>') {
              processTag(true, false);
              state = DEFAULT;
            } else {
              attributeName.append((char)c);
              state = ATTRIBUTE_NAME;
            }
          }
          break;
        case 13: // ATTRIBUTE_NAME
          if (Character.isWhitespace((char)c)) state = ATTRIBUTE_NAME_SPACE;
          else if (c == '=') state = ATTRIBUTE_NAME_EQUAL;
          else attributeName.append((char)c);
          break;
        case 14: // ATTRIBUTE_NAME_SPACE
          if (!Character.isWhitespace((char)c)) {
            if (c != '=') throw  new SAXException("Expected '=' at line " + lineNbr);
            state = ATTRIBUTE_NAME_EQUAL;
          }
          break;
        case 15: // ATTRIBUTE_NAME_EQUAL
          if (!Character.isWhitespace((char)c)) {
            if ((c != '"') & (c != '\'')) throw  new SAXException("Quote(s) expected at line " + lineNbr);
            state = ATTRIBUTE_VALUE;
          }
          break;
        case 16: // ATTRIBUTE_VALUE
          if ((c == '"') | (c == '\'')) {
            String name = attributeName.toString();
            String value = replaceEscapes(attributeValue.toString());
            if (name.startsWith("xmlns:") | name.startsWith("XMLNS:")) {
              // Namespace association.
              namespaces.put(name.substring(6), value);
            } else if (name.equals("xmlns")) {
              // Default namespace
              defaultNamespace = value;
            } else {
              // Tag attribute.
              attributes.add(name, value);
            }
            attributeName.setLength(0);
            attributeValue.setLength(0);
            state = ATTRIBUTE_LIST;
          } else attributeValue.append((char)c);
          break;
        default:
          throw new InternalError("State Unknown");
      }

      // Count lines.
      if ((c == '\n') && (!carriageReturn)) lineNbr++;
      if (c == '\r') {
        lineNbr++;
        carriageReturn = true;
      } else {
        carriageReturn = false;
      }
    }

    // End.
    if (contentHandler != null) contentHandler.endDocument();
  }
  private static class State extends Enumerate {
    private State(String name) { super(name); }
  }
  private static State DEFAULT                     = new State("0");
  private static State READ_LESS                   = new State("1");
  private static State READ_LESS_EXCL              = new State("2");
  private static State READ_LESS_EXCL_DASH         = new State("3");
  private static State COMMENT                     = new State("4");
  private static State COMMENT_DASH                = new State("5");
  private static State COMMENT_DASH_DASH           = new State("6");
  private static State PI                          = new State("7");
  private static State PI_QUES                     = new State("8");
  private static State END_TAG_NAME                = new State("9");
  private static State START_TAG_NAME              = new State("10");
  private static State EMPTY_ELEMENT_TAG           = new State("11");
  private static State ATTRIBUTE_LIST              = new State("12");
  private static State ATTRIBUTE_NAME              = new State("13");
  private static State ATTRIBUTE_NAME_SPACE        = new State("14");
  private static State ATTRIBUTE_NAME_EQUAL        = new State("15");
  private static State ATTRIBUTE_VALUE             = new State("16");

  private void processTag(boolean isStart, boolean isEnd) throws SAXException {
    // Extract tag uri/name
    String qName = tagName.toString();
    String uri = defaultNamespace;
    int colonIndex = qName.indexOf(':');
    String localName = qName.substring(colonIndex + 1);
    if (colonIndex >= 0) {
      // Namespace specified.
      String prefix = qName.substring(0, colonIndex);
      uri = (String) namespaces.get(prefix);
      if (uri == null) throw new SAXException("Prefix " + prefix + " not mapped");
    }
    if ((isStart) & (contentHandler != null))
      contentHandler.startElement(uri, localName, qName, attributes);
    if ((isEnd) & (contentHandler != null))
        contentHandler.endElement(uri, localName, qName);
    // Clear current tag data.
    tagName.setLength(0);
    attributes.clear();
  }

  private String replaceEscapes(String str) {
    int start = 0;
    _result.setLength(0);
    while (start < str.length()) {
      int index = str.indexOf('&', start);
      if (index >= 0) {
        // Found '&'
        _result.append(str.substring(start, index));
        start = index + 1;
        if (str.startsWith("lt;", start)) {
          _result.append('<');
          start += 3;
        } else if (str.startsWith("gt;", start)) {
          _result.append('>');
          start += 3;
        } else if (str.startsWith("apos;", start)) {
          _result.append('\'');
          start += 5;
        } else if (str.startsWith("quot;", start)) {
          _result.append('\"');
          start += 5;
        } else if (str.startsWith("amp;", start)) {
          _result.append('&');
          start += 4;
        } else _result.append('&');
      } else {
        // Not found.
        if (start == 0) return str; // Optimization.
        _result.append(str.substring(start));
        start = str.length();
      }
    }
    return _result.toString();
  }
  private StringBuffer _result = new StringBuffer();

  /**
   * Parse an XML document from a system identifier (URI).
   *
   * <p>This method is a shortcut for the common case of reading a
   * document from a system identifier.  It is the exact
   * equivalent of the following:</p>
   *
   * <pre>
   * parse(new InputSource(systemId));
   * </pre>
   *
   * <p>If the system identifier is a URL, it must be fully resolved
   * by the application before it is passed to the parser.</p>
   *
   * @param systemId The system identifier (URI).
   * @exception org.xml.sax.SAXException Any SAX exception, possibly
   *            wrapping another exception.
   * @exception java.io.IOException An IO exception from the parser,
   *            possibly from a byte stream or character stream
   *            supplied by the application.
   * @see #parse(org.xml.sax.InputSource)
   */
  public void parse (String systemId) throws IOException, SAXException {
    parse(new InputSource(systemId));
  }

  //////////////////////
  // Not implemented. //
  //////////////////////

  /**
   * NOT IMPLEMENTED
   */
  public void setErrorHandler (ErrorHandler handler) {
    // Do nothing.
  }

  /**
   * NOT IMPLEMENTED
   */
  public ErrorHandler getErrorHandler () {
    return null;
  }

  /**
   * NOT IMPLEMENTED
   */
  public boolean getFeature (String name)
      throws SAXNotRecognizedException, SAXNotSupportedException {
    return false;
  }

  /**
   * NOT IMPLEMENTED
   */
  public void setFeature (String name, boolean value)
      throws SAXNotRecognizedException, SAXNotSupportedException {
    throw new SAXNotRecognizedException("Incomplete Parser");
  }

  /**
   * NOT IMPLEMENTED
   */
  public Object getProperty (String name)
      throws SAXNotRecognizedException, SAXNotSupportedException {
    throw new SAXNotRecognizedException("Incomplete Parser");
  }

  /**
   * NOT IMPLEMENTED
   */
  public void setProperty (String name, Object value)
      throws SAXNotRecognizedException, SAXNotSupportedException {
    throw new SAXNotRecognizedException("Incomplete Parser");
  }

  /**
   * NOT IMPLEMENTED
   */
  public void setEntityResolver (EntityResolver resolver) {
    // Do nothing.
  }

  /**
   * NOT IMPLEMENTED
   */
  public EntityResolver getEntityResolver () {
    return null;
  }

  /**
   * NOT IMPLEMENTED
   */
  public void setDTDHandler (DTDHandler handler) {
    // Do nothing.
  }

  /**
   * NOT IMPLEMENTED
   */
  public DTDHandler getDTDHandler () {
    return null;
  }

}