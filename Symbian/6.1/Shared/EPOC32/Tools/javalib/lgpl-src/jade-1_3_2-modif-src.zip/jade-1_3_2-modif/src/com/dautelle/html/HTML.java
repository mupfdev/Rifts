/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.html;
import com.dautelle.xml.*;
import java.util.Properties;
import java.io.StringWriter;
import java.io.IOException;


/**
 * <P> This class represents a HTML document.</P>
 * <P> The purpose of this class is to allow a Java program to read/write
 *     HTML documents using the Constructor/ObjectWriter classes.</P>
 * <P> HTML tags which are not XML compliant, i.e. &lt;BR&gt; are not supported
 *     (&lt;P&gt; &lt;/P&gt; should be used instead).
 * <P> Because this class is <code>Representable</code>, HTML documents
 *     may be embedded within others <code>Representable</code> java objects.
 * <P> The structure of the HTML document follows the
 *    <a href="http://www.w3.org/TR/REC-html40/">HTML 4.01 Specification</a></P>
 * <P> Deprecated element are not implemented (the same effect could be
 *     accomplished using style sheet).</P>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     com.dautelle.xml.Constructor
 * @see     com.dautelle.xml.ObjectWriter
 */
public class HTML implements Representable {

  /**
   * The document head.
   */
  public HEAD head;

  /**
   * The document body.
   */
  public BODY body;

  /**
   * Constructs a HTML document with a HEAD and a BODY.
   *
   * @param   head the HEAD element.
   * @param   body the BODY element.
   */
  public HTML(HEAD head, BODY body) {
    this.head = head;
    this.body = body;
  }

  /**
   * XML Constructor.
   *
   * @param  attributes none.
   * @param  content the HEAD and the BODY elements.
   * @see    com.dautelle.xml.Constructor
   */
  public HTML(Attributes attributes, Elements content) {
    head = (HEAD) content.get(0);
    body = (BODY) content.get(1);
  }

  /**
   * Returns the XML source for this HTML document. The source is HTML compliant
   * and can be used to display the document in <code>javax.swing.JEditorPane</code>.
   *
   * @return the XML source for this HTML document.
   */
  public String getSource() {
    Properties namespaces = new Properties();
    namespaces.setProperty("com.dautelle.html", ""); // Default namespace avoid
                                                     // package prefixes.
    ObjectWriter ow = new ObjectWriter(namespaces, "  ", false);
    StringWriter sw = new StringWriter();
    try {
      ow.write(this, sw);
    } catch (IOException e) {
      throw new InternalError();
    }
    return sw.toString();
  }

  // Implements Representable
  //

  public Attributes getAttributes() {
    return null;
  }

  public Representable[] getContent() {
    Representable[] content = new Representable[2];
    content[0] = head;
    content[1] = body;
    return content;
  }
}