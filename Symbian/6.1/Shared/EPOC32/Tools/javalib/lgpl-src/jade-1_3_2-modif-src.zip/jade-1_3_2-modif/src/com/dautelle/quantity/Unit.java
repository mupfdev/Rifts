/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import java.util.StringTokenizer;
import com.dautelle.util.Enumerate;

/**
 * This class represents a precisely specified quantity in terms of which
 * the magnitudes of other quantities of the same kind can be stated.
 * Because Unit objects are immutable they can be shared.
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 */
public class Unit implements java.io.Serializable {

  /**
   * This class represents the symbol associated to a measurement Unit.
   */
  private static class Symbol extends Enumerate {
    private Symbol(String name) { super(name);}
    private static Symbol all = new Symbol(null);
  }

  /**
   * Dividend of this Unit (ordered).
   */
  private final Symbol[] dividend;

  /**
   * Divisor of this Unit (ordered).
   */
  private final Symbol[] divisor;

  /**
   * Dimensionless Unit.
   */
  static public final Unit DIMENSIONLESS = new Unit("");

  /**
   * Unit constructor.&nbsp In order to successfully create
   * a new Unit, the unit's symbol shall not be used by any previously
   * defined Unit.&nbsp Dimensionless unit have no symbol (<code>""</code>).
   *
   * @param   symbol the Unit's symbol name
   * @throws  EnumerateException symbol name already used
   */
  public Unit(String symbol) {
    this.divisor = new Symbol[0];
    if (symbol.length() != 0) {
      this.dividend = new Symbol[1];
      this.dividend[0] = new Symbol(symbol);
    } else {
      // Dimensionless unit
      this.dividend = new Symbol[0];
    }
  }

  /**
   * Constructor from another Unit.
   *
   * @param   u the unit to duplicate
   */
  protected Unit(Unit u) {
    this.divisor = u.divisor;
    this.dividend = u.dividend;
  }

  /**
   * Constructor from a specified symbol.
   *
   * @param   symbol the symbol of the unit to create.
   */
  private Unit(Symbol s) {
    this.dividend = new Symbol[1];
    this.dividend[0] = s;
    this.divisor = new Symbol[0];
  }

  /**
   * Constructor from a dividend and a divisor.
   * Symbols common to both dividend and divisor are removed.
   *
   * @param   dividend the dividend of the Unit
   * @param   divisor the divisor of the Unit
   */
  private Unit(Symbol[] dividend, Symbol[] divisor) {
    int count = 0;
    int i1 = 0, i2 = 0;
    while ((i1 < dividend.length) & (i2 < divisor.length)) {
      if (dividend[i1] == divisor[i2]) {
        // Simplification
        dividend[i1++] = null;
        divisor[i2++] = null;
        count++;
      } else if (dividend[i1].getName().compareTo(divisor[i2].getName()) > 0) {
        i2++;
      } else {
        i1++;
      }
    }
    if (count == 0) {
      this.dividend = dividend;
      this.divisor = divisor;
    } else {
      this.dividend = new Symbol[dividend.length - count];
      this.divisor = new Symbol[divisor.length - count];
      i1 = 0;
      for (int i = 0; i < dividend.length; i++)
        if (dividend[i] != null)
          this.dividend[i1++] = dividend[i];
      i2 = 0;
      for (int i = 0; i < divisor.length; i++)
        if (divisor[i] != null)
          this.divisor[i2++] = divisor[i];
    }
  }

  /**
   * Returns the Unit resulting from the multiplication of this Unit
   * with the one specified.
   *
   * @param   u the multiplier Unit
   * @return  (this * u)
   */
  public Unit multiply(Unit u) {
    Symbol[] dividend = merge(this.dividend, u.dividend);
    Symbol[] divisor = merge(this.divisor, u.divisor);
    return new Unit(dividend, divisor);
  }

  /**
   * Returns the Unit resulting from the division of this Unit by the one
   * specified.
   *
   * @param   u the divisor Unit
   * @return  (this / unit)
   */
  public Unit divide(Unit u) {
    Symbol[] dividend = merge(this.dividend, u.divisor);
    Symbol[] divisor = merge(this.divisor, u.dividend);
    return new Unit(dividend, divisor);
  }

  /**
   * Returns the inverse of the specified Unit.
   *
   * @return  (1 / this)
   */
  public Unit inverse() {
    return new Unit(this.divisor, this.dividend);
  }

  /**
   * Returns the nth root of the specified Unit.
   *
   * @param   n root's order (n &gt;= 0)
   * @return  q such as <code>q.power(n).equals(this)</code>
   * @throws  UnitException resulting root is a fractional Unit
   */
  public Unit root(int n) {
    if (n == 0)
      return DIMENSIONLESS;
    Symbol[] dividend = new Symbol[this.dividend.length / n];
    Symbol[] divisor = new Symbol[this.divisor.length / n];
    for (int i = 0, k = 0; i < dividend.length; i++) {
      dividend[i] = this.dividend[k++];
      for (int j = 0; j < n - 1; j++)
        if (dividend[i] != this.dividend[k++])
          throw new UnitException("Resulting root is a fractional Unit");
    }
    for (int i = 0, k = 0; i < divisor.length; i++) {
      divisor[i] = this.divisor[k++];
      for (int j = 0; j < n - 1; j++)
        if (divisor[i] != this.divisor[k++])
          throw new UnitException("Resulting root is a fractional Unit");
    }
    return new Unit(dividend, divisor);
  }

  /**
   * Returns the nth power of the specified Unit.
   *
   * @param   n exponent
   * @return  this**n
   */
  public Unit power(int n) {
    Symbol[] dividend = new Symbol[this.dividend.length * n];
    Symbol[] divisor = new Symbol[this.divisor.length * n];
    for (int i = 0, k = 0; i < this.dividend.length; i++) {
      for (int j = 0; j < n; j++)
        dividend[k++] = this.dividend[i];
    }
    for (int i = 0, k = 0; i < this.divisor.length; i++) {
      for (int j = 0; j < n; j++)
        divisor[k++] = this.divisor[i];
    }
    return new Unit(dividend, divisor);
  }

  /**
   * Returns the String representation of this Unit
   * (1/s, m/s/s, A*mol*rad/ca/s, for example).
   *
   * @return   String representation of this Unit
   */
  public String toString() {
    StringBuffer result = new StringBuffer(32);
    for (int i = 0; i < this.dividend.length; i++) {
      if (result.length() != 0)
        result.append("*");
      result.append(this.dividend[i].getName());
    }
    for (int i = 0; i < this.divisor.length; i++) {
      if (result.length() == 0)
        result.append("1");
      result.append("/");
      result.append(this.divisor[i].getName());
    }
    return result.toString();
  }

  /**
   * Compares the specified Object with this Unit for equality.  Returns
   * <code>true</code> if and only if the specified Object is also a Unit,
   * both have the same dividend and divisor.
   *
   * @param   o the Object to be compared for equality with this Unit
   * @return  <code>true</code> if the specified Object is equal to this Unit
   */
  public boolean equals(Object o) {
    if (o == this)
      return true;
    if (!(o instanceof Unit))
      return false;
    Unit u = (Unit) o;
    return java.util.Arrays.equals(this.dividend, u.dividend) &&
            java.util.Arrays.equals(this.divisor, u.divisor);
  }

  /**
   * Parses the specified String in order to construct the corresponding
   * Unit.
   *
   * @param   str the string representation of the Unit to parse.
   * @return  the Unit with the specified String representation.
   * @throws  UnitException symbol unit does not exist
   * @see     #toString()
    */
  static Unit parse(String str ) {
    Unit result = DIMENSIONLESS;
    StringTokenizer st = new StringTokenizer(str, "*/", true);
    boolean isMultiplied = true;
    while (st.hasMoreTokens()) {
      String token = st.nextToken();
      if (token.equals("*")) isMultiplied = true;
      else if (token.equals("/")) isMultiplied = false;
      else if (!token.equals("1")) {
        // It is a unit.
        Symbol symbol = (Symbol) Symbol.all.get(token);
        if (symbol == null)
          throw new UnitException("Symbol " + token + " doesn't exist");
        if (isMultiplied) result = result.multiply(new Unit(symbol));
        else result = result.divide(new Unit(symbol));
      }
    }
    return result;
  }

  /**
   * Merges two arrays of Symbols and keeps them ordered.
   *
   * @param   left ordered array of Symbols
   * @param   right ordered array of Symbols
    */
  private static Symbol[] merge(Symbol[] left, Symbol[] right) {
    int size = left.length + right.length;
    Symbol[] result = new Symbol[size];

    int il = 0, ir = 0;
    for (int i = 0; i < size; i++) {
      if (il >= left.length) {
        // Left has been completely transfered.
        for (int j = ir; j < right.length; j++)
          result[i++] = right[j];
        return result;
      }
      if (ir >= right.length) {
        // Right has been completely transfered.
        for (int j = il; j < left.length; j++)
          result[i++] = left[j];
        return result;
      }
      if (left[il].getName().compareTo(right[ir].getName()) < 0) {
        result[i] = left[il++];
      } else {
        result[i] = right[ir++];
      }
    }
    return result;
  }
}