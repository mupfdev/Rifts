/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents the capacity of a physical system to do work.
 * The measurement Unit for this quantity is the Joule (Newton * Meter = kg*m*m/s/s).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #JOULE
 * @see     Force#NEWTON
 * @see     Length#METER
 */
public final class Energy extends Quantity {

  /**
   * This class represents Units of Energy.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toJoule;

    private Unit() { // Default Unit (Joule)
      super(Force.NEWTON.multiply(Length.METER));
      this.toJoule = 1.0;
    }

    /**
     * Constructs a fundamental Unit of Energy.
     *
     * @param   symbol the symbol of this Unit
     * @param   toJoule the multiplier coefficient to convert this
     *          Unit to Joule
     * @see     Energy#JOULE
     */
    public Unit(String symbol, double toJoule) {
      super(symbol);
      this.toJoule = toJoule;
    }

    /**
     * Constructs a derived Unit of Energy from a Force Unit multiplied with
     * a Length Unit.
     *
     * @param   forceUnit the Force Unit
     * @param   lengthUnit the Length Unit
     */
    public Unit(Force.Unit forceUnit, Length.Unit lengthUnit) {
      super(forceUnit.multiply(lengthUnit));
      Force force = new Force(1.0, forceUnit);
      Length length = new Length(1.0, lengthUnit);
      this.toJoule = force.doubleValue() * length.doubleValue();
    }
  }

  /**
   * Used to specify Joule Unit. One joule is the amount of work done when
   * an applied force of 1 newton moves through a distance of 1 metre in
   * the direction of the force. It is named after the English physicist
   * James Prescott Joule (1818-1889).
   */
  public static final Unit JOULE = new Unit();

  /**
   * Used to specify Kilojoule Unit.
   */
  public static final Unit KILOJOULE = new Unit("KiloJoule", 1000); // Exact.

  /**
   * Used to specify Megajoule Unit.
   */
  public static final Unit MEGAJOULE = new Unit("MegaJoule", 1e6); // Exact.

  /**
   * Used to specify British Thermal Units (International).
   */
  public static final Unit BTU = new Unit("Btu", 1055.056);

  /**
   * Used to specify British Thermal Units Thermochemical.
   */
  public static final Unit BTU_TH = new Unit("Btu_Th", 1054.350);

  /**
   * Used to specify British Thermal Units Mean.
   */
  public static final Unit BTU_MEAN = new Unit("Btu_Mean", 1055.87);

  /**
   * Used to specify Calorie Unit (International).
   */
  public static final Unit CALORIE = new Unit("Calorie", 4.1868); // Exact.

  /**
   * Used to specify KiloCalorie Unit (International).
   */
  public static final Unit KILOCALORIE =
          new Unit("KiloCalorie", 4186.8); // Exact.

  /**
   * Used to specify Calorie Thermochemical Unit.
   */
  public static final Unit CALORIE_TH = new Unit("Calorie_Th", 4.184);

  /**
   * Used to specify Calorie Mean Unit.
   */
  public static final Unit CALORIE_MEAN = new Unit("Calorie_Mean", 4.19002);

  /**
   * Used to specify Calorie 15 degrees Celsius Unit.
   */
  public static final Unit CALORIE_15C = new Unit("Calorie_15C", 4.18580);

  /**
   * Used to specify Calorie 20 degrees Celsius Unit.
   */
  public static final Unit CALORIE_20C = new Unit("Calorie_20C", 4.18190);

  /**
   * Used to specify Calorie Food Unit.
   */
  public static final Unit CALORIE_FOOD =
          new Unit("Calorie_Food", 4186); // Approximation.

  /**
   * Used to specify Centigrade Heat Unit.
   */
  public static final Unit CENTIGRADE_HEAT =
          new Unit("Centigrade_Heat", 1900.4);

  /**
   * Used to specify Erg Unit.
   */
  public static final Unit ERG = new Unit("Erg", 1e-7);

  /**
   * Used to specify ElectronVolt Unit (eV).
   */
  public static final Unit ELECTRON_VOLT =
          new Unit("ElectronVolt", 160.217733e-21);

  /**
   * Used to specify KiloElectronVolt Unit (KeV).
   */
  public static final Unit KILOELECTRON_VOLT = new Unit("KiloElectronVolt",
          (new Energy(1000, Energy.ELECTRON_VOLT)).doubleValue());

  /**
   * Used to specify MegaElectronVolt Unit (MeV).
   */
  public static final Unit MEGAELECTRON_VOLT = new Unit("MegaElectronVolt",
          (new Energy(1e6, Energy.ELECTRON_VOLT)).doubleValue());

  /**
   * Used to specify GigaElectronVolt Unit (GeV).
   */
  public static final Unit GIGAELECTRON_VOLT = new Unit("GigaElectronVolt",
          (new Energy(1e9, Energy.ELECTRON_VOLT)).doubleValue());

  /**
   * Used to specify Foot Pounds-Force Unit.
   */
  public static final Unit FOOT_POUND_FORCE =
          new Unit(Force.POUND_FORCE, Length.FOOT);

  /**
   * Used to specify Foot Poundal Unit.
   */
  public static final Unit FOOT_POUNDAL =
          new Unit(Force.POUNDAL, Length.FOOT);

  /**
   * Used to specify Kilogram-Force Meter Unit.
   */
  public static final Unit KILOGRAM_FORCE_METER =
          new Unit(Force.KILOGRAM_FORCE, Length.METER);

  /**
   * Equivalent {@link #KILOGRAM_FORCE_METER}
   */
  public static final Unit KILOGRAM_FORCE_METRE = KILOGRAM_FORCE_METER;

  /**
   * Used to specify Kilowatt Hour Unit.
   */
  public static final Unit KILOWATT_HOUR =
          new Unit("KiloWatt_Hour", 3600000); // Exact.

  /**
   * Used to specify Newton Meter Unit.
   */
  public static final Unit NEWTON_METER =
          new Unit(Force.NEWTON, Length.METER);

  /**
   * Equivalent {@link #NEWTON_METER}
   */
  public static final Unit NEWTON_METRE = NEWTON_METER;

  /**
   * Used to specify Therm Unit.
   */
  public static final Unit THERM = new Unit("Therm", 105.4804e6); // Approximation.

  /**
   * Used to specify Watt Second Unit.
   */
  public static final Unit WATT_SECOND = new Unit("Watt_Second", 1); // Exact.

  /**
   * Used to specify Watt Hour Unit.
   */
  public static final Unit WATT_HOUR = new Unit("Watt_Hour", 3600); // Exact.

  /**
   * Constructs an Energy in Joule from the specified energy
   * stated using the specified Unit.
   *
   * @param   value the energy stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public Energy(double value, Unit unit) {
    super(value * unit.toJoule,
          JOULE);
  }

  /**
   * Constructs an Energy in Joule from the specified energy
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the energy stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public Energy(double value, double error, Unit unit) {
    super(value * unit.toJoule,
          error * unit.toJoule,
          JOULE);
  }

  /**
   * Translates a Quantity in Joule to an Energy.
   *
   * @param   q the quantity in Joule
   * @throws  UnitException quantity is not in kg*m*m/s/s
   */
  public Energy(Quantity q) {
    super(q);
    if (!q.unit.equals(JOULE))
      throw new UnitException("Quantity is not in kg*m*m/s/s but in " +
              q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in kg*m*m/s/s
   */
  public Energy(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(JOULE))
      throw new UnitException("Quantity is not in kg*m*m/s/s but in " +
              this.unit);
  }

  /**
   * Returns a Quantity corresponding to this Energy in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toJoule,
                        this.absoluteError() / unit.toJoule,
                        unit);
  }

  /**
   * Sets the value for this Energy stated using the specified
   * measurement Unit.
   *
   * @param   value the Energy stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toJoule);
  }

  /**
   * Sets the value and the measurement error for this Energy both
   * stated using the specified measurement Unit.
   *
   * @param   value the Energy stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toJoule,
        error * unit.toJoule);
  }

  // Specific constructors.
  //

  /**
   * Translates a Mass to Energy according to Einstein's famous equation, E = mc2.
   *
   * @param   m the mass to convert
   */
  public Energy(Mass m) {
    this(m.multiply(new Velocity(1.0, Velocity.C)).multiply(
            new Velocity(1.0, Velocity.C)));
  }


  // Specific methods.
  //
}


