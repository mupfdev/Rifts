/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.html;
import com.dautelle.xml.*;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * <P> This is the the base class for all HTML block like elements
 *     (such as paragraphs and lists).</P>
 * <P> Valid block elements contain data, inline elements and other block-level
 *     elements.</P>
 * <P> By default, block-level elements are formatted differently than
 *     inline elements. Generally, block-level elements begin on new lines,
 *     inline elements do not.</P>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     Inline
 */
public abstract class Block extends ArrayList implements Representable {

  /**
   * The class attribute for this block element (default null).
   */
  public String classAttribute;

  /**
   * The id attribute for this block element (default null).
   */
  public String idAttribute;

  /**
   * The style attribute for this block element (default null).
   */
  public String styleAttribute;

  /**
   * Default constructor.
   */
  public Block() { super(); }

  /**
   * XML constructor.
   *
   * @param  attributes "class", "id", "style".
   * @param  content the content of this Block element.
   * @see    com.dautelle.xml.Constructor
   */
  public Block(Attributes attributes, Elements content) {
    super();
    classAttribute = attributes.get("class");
    idAttribute = attributes.get("id");
    styleAttribute = attributes.get("style");
    this.addAll(content);
  }

  /**
   * Indicates if this Block is a valid HTML Block.
   *
   * @return <code>true</code> if this Block is composed exclusively of
   *         character data, inline elements or other block elements;
   *         <code>false</code> otherwise.
   */
  public boolean isValid() {
    for (Iterator i = this.iterator() ; i.hasNext() ;) {
      Object o = i.next();
        if (    !(o instanceof Inline)
             && !(o instanceof CharData)
             && !(o instanceof Block) ) return false;
    }
    return true;
  }

  // Implements Representable
  //

  public Attributes getAttributes() {
    Attributes attributes = new Attributes();
    if (classAttribute != null) attributes.add("class", classAttribute);
    if (idAttribute != null) attributes.add("id", idAttribute);
    if (styleAttribute != null) attributes.add("style", styleAttribute);
    return attributes;
  }

  public Representable[] getContent() {
    Representable[] content = new Representable[this.size()];
    this.toArray(content);
    return content;
  }
}