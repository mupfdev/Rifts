/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents the moment of a force.
 * The measurement Unit for this quantity is the Newton Meter (kg*m*m/s/s).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #NEWTON_METER
 * @see     Force#NEWTON
 * @see     Length#METER
 */
public final class Torque extends Quantity {

  /**
   * This class represents Units of Torque.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toNewtonMeter;

    private Unit() { // Default Unit (Newton Meter)
      super((Force.NEWTON).multiply(Length.METER));
      this.toNewtonMeter = 1.0;
    }

    /**
     * Constructs a fundamental Unit of Torque.
     *
     * @param   symbol the symbol of this Unit
     * @param   toNewtonMeter the multiplier coefficient to convert this
     *          Unit to Newton Meter
     * @see     Torque#NEWTON_METER
     */
    public Unit(String symbol, double toNewtonMeter) {
      super(symbol);
      this.toNewtonMeter = toNewtonMeter;
    }

    /**
     * Constructs a derived Unit of Torque from a Force Unit multiplied with
     * a Length Unit.
     *
     * @param   forceUnit the Force Unit
     * @param   lengthUnit the Length Unit
     */
    public Unit(Force.Unit forceUnit, Length.Unit lengthUnit) {
      super(forceUnit.multiply(lengthUnit));
      Force force = new Force(1.0, forceUnit);
      Length length = new Length(1.0, lengthUnit);
      this.toNewtonMeter = force.doubleValue() * length.doubleValue();
    }
  }

  /**
   * Used to specify Newton Meter Unit.
   */
  public static final Unit NEWTON_METER = new Unit();

  /**
   * Equivalent {@link #NEWTON_METER}
   */
  public static final Unit NEWTON_METRE = NEWTON_METER;

  /**
   * Used to specify Dyne Centimeter Unit.
   * @ see    Force#DYNE
   * @ see    Length#CENTIMETER
   */
  public static final Unit DYNE_CENTIMETER =
          new Unit(Force.DYNE, Length.CENTIMETER);

  /**
   * Equivalent {@link #DYNE_CENTIMETER}
   */
  public static final Unit DYNE_CENTIMETRE = DYNE_CENTIMETER;

  /**
   * Used to specify Kilogram-Force Centimeter Unit.
   * @ see    Force.KILOGRAM_FORCE
   * @ see    Length.CENTIMETER
   */
  public static final Unit KILOGRAM_FORCE_CENTIMETER =
          new Unit(Force.KILOGRAM_FORCE, Length.CENTIMETER);

  /**
   * Equivalent {@link #KILOGRAM_FORCE_CENTIMETER}
   */
  public static final Unit KILOGRAM_FORCE_CENTIMETRE =
          KILOGRAM_FORCE_CENTIMETER;

  /**
   * Used to specify Kilogram-Force Meter Unit.
   * @ see    Force#KILOGRAM_FORCE
   * @ see    Length#METER
   */
  public static final Unit KILOGRAM_FORCE_METER =
          new Unit(Force.KILOGRAM_FORCE, Length.METER);

  /**
   * Equivalent {@link #KILOGRAM_FORCE_METER}
   */
  public static final Unit KILOGRAM_FORCE_METRE = KILOGRAM_FORCE_METER;

  /**
   * Used to specify Newton Centimeter Unit.
   * @ see    Force#NEWTON
   * @ see    Length#CENTIMETER
   */
  public static final Unit NEWTON_CENTIMETER =
          new Unit(Force.NEWTON, Length.CENTIMETER);

  /**
   * Equivalent {@link #NEWTON_CENTIMETER}
   */
  public static final Unit NEWTON_CENTIMETRE = NEWTON_CENTIMETER;

  /**
   * Used to specify Pound-Force Inch Unit.
   * @ see    Force#POUND_FORCE
   * @ see    Length#INCH
   */
  public static final Unit POUND_FORCE_INCH =
          new Unit(Force.POUND_FORCE, Length.INCH);

  /**
   * Used to specify Pound-Force Foot Unit.
   * @ see    Force#POUND_FORCE
   * @ see    Length#FOOT
   */
  public static final Unit POUND_FORCE_FOOT =
          new Unit(Force.POUND_FORCE, Length.INCH);

  /**
   * Used to specify Poundal Foot Unit.
   * @ see    Force#POUNDAL
   * @ see    Length#FOOT
   */
  public static final Unit POUNDAL_FOOT =
          new Unit(Force.POUNDAL, Length.FOOT);

  /**
   * Used to specify Ton-Force Foot (U.K.) Unit.
   * @ see    Force#TON_FORCE_UK
   * @ see    Length#FOOT
   */
  public static final Unit TON_FORCE_FOOT_UK =
          new Unit(Force.TON_FORCE_UK, Length.FOOT);

  /**
   * Used to specify Ton-Force Foot (U.S.) Unit.
   * @ see    Force#TON_FORCE_US
   * @ see    Length#FOOT
   */
  public static final Unit TON_FORCE_FOOT_US =
          new Unit(Force.TON_FORCE_US, Length.FOOT);

  /**
   * Used to specify Tonne-Force Meter Unit.
   * @ see    Force#TONNE_FORCE
   * @ see    Length#METER
   */
  public static final Unit TONNE_FORCE_METER =
          new Unit(Force.TONNE_FORCE, Length.METER);

  /**
   * Equivalent {@link #TONNE_FORCE_METER}
   */
  public static final Unit TONNE_FORCE_METRE = TONNE_FORCE_METER;

  /**
   * Constructs a Torque in Newton Meter from the specified torque
   * stated using the specified Unit.
   *
   * @param   value the torque stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public Torque(double value, Unit unit) {
    super(value * unit.toNewtonMeter,
          NEWTON_METER);
  }

  /**
   * Constructs a Torque in Newton Meter from the specified torque
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the torque stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public Torque(double value, double error, Unit unit) {
    super(value * unit.toNewtonMeter,
          error * unit.toNewtonMeter,
          NEWTON_METER);
  }

  /**
   * Translates a Quantity in Newton Meter to a Torque.
   *
   * @param   q the quantity in Newton Meter
   * @throws  UnitException quantity is not in kg*m*m/s/s
   */
  public Torque(Quantity q) {
    super(q);
    if (!q.unit.equals(NEWTON_METER))
      throw new UnitException("Quantity is not in kg*m*m/s/s but in " +
              q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in kg*m*m/s/s
   */
  public Torque(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(NEWTON_METER))
      throw new UnitException("Quantity is not in kg*m*m/s/s but in " +
              this.unit);
  }

  /**
   * Returns a Quantity corresponding to this Torque in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toNewtonMeter,
                        this.absoluteError() / unit.toNewtonMeter,
                        unit);
  }

  /**
   * Sets the value for this Torque stated using the specified
   * measurement Unit.
   *
   * @param   value the Torque stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toNewtonMeter);
  }

  /**
   * Sets the value and the measurement error for this Torque both
   * stated using the specified measurement Unit.
   *
   * @param   value the Torque stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toNewtonMeter,
        error * unit.toNewtonMeter);
  }

  // Specific constructors.
  //


  // Specific methods.
  //
}